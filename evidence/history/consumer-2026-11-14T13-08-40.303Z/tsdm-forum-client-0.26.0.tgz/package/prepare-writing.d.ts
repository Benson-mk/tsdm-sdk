import type { HostResponse, PrepareWritingResult, PreparedWriting, ReplyTarget } from "./types.js";
type Decoded = PrepareWritingResult extends infer R ? R extends PrepareWritingResult ? Omit<R, "generation"> : never : never;
export declare function decodeWriting(response: HostResponse, requested: string, boardId: string, edit?: {
    threadId: string;
    postId: string;
}, reply?: ReplyTarget): Decoded;
/** Source IDs without a known uploaded reference; this does not establish server ownership. */
export declare function unresolvedWritingAttachments(writing: {
    source: string;
    uploadedReferences: readonly string[];
}): string[];
export declare function draftVersion(writing: PreparedWriting): string;
/** Remove only the verified file from the original saved-version conflict token. */
export declare function draftWithoutAttachment(draft: import("./types.js").DraftIdentity, id: string): import("./types.js").DraftIdentity;
export {};
