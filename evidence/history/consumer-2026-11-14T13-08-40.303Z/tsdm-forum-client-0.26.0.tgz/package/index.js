//#region node_modules/parse5/dist/common/unicode.js
var e = /* @__PURE__ */ new Set([
	65534,
	65535,
	131070,
	131071,
	196606,
	196607,
	262142,
	262143,
	327678,
	327679,
	393214,
	393215,
	458750,
	458751,
	524286,
	524287,
	589822,
	589823,
	655358,
	655359,
	720894,
	720895,
	786430,
	786431,
	851966,
	851967,
	917502,
	917503,
	983038,
	983039,
	1048574,
	1048575,
	1114110,
	1114111
]), t;
(function(e) {
	e[e.EOF = -1] = "EOF", e[e.NULL = 0] = "NULL", e[e.TABULATION = 9] = "TABULATION", e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN", e[e.LINE_FEED = 10] = "LINE_FEED", e[e.FORM_FEED = 12] = "FORM_FEED", e[e.SPACE = 32] = "SPACE", e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK", e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK", e[e.AMPERSAND = 38] = "AMPERSAND", e[e.APOSTROPHE = 39] = "APOSTROPHE", e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS", e[e.SOLIDUS = 47] = "SOLIDUS", e[e.DIGIT_0 = 48] = "DIGIT_0", e[e.DIGIT_9 = 57] = "DIGIT_9", e[e.SEMICOLON = 59] = "SEMICOLON", e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN", e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN", e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN", e[e.QUESTION_MARK = 63] = "QUESTION_MARK", e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A", e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z", e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET", e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT", e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A", e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z";
})(t ||= {});
var n = {
	DASH_DASH: "--",
	CDATA_START: "[CDATA[",
	DOCTYPE: "doctype",
	SCRIPT: "script",
	PUBLIC: "public",
	SYSTEM: "system"
};
function r(e) {
	return e >= 55296 && e <= 57343;
}
function i(e) {
	return e >= 56320 && e <= 57343;
}
function a(e, t) {
	return (e - 55296) * 1024 + 9216 + t;
}
function o(e) {
	return e !== 32 && e !== 10 && e !== 13 && e !== 9 && e !== 12 && e >= 1 && e <= 31 || e >= 127 && e <= 159;
}
function s(t) {
	return t >= 64976 && t <= 65007 || e.has(t);
}
//#endregion
//#region node_modules/parse5/dist/common/error-codes.js
var c;
(function(e) {
	e.controlCharacterInInputStream = "control-character-in-input-stream", e.noncharacterInInputStream = "noncharacter-in-input-stream", e.surrogateInInputStream = "surrogate-in-input-stream", e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus", e.endTagWithAttributes = "end-tag-with-attributes", e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus", e.unexpectedSolidusInTag = "unexpected-solidus-in-tag", e.unexpectedNullCharacter = "unexpected-null-character", e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name", e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name", e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name", e.missingEndTagName = "missing-end-tag-name", e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name", e.unknownNamedCharacterReference = "unknown-named-character-reference", e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference", e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier", e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value", e.eofBeforeTagName = "eof-before-tag-name", e.eofInTag = "eof-in-tag", e.missingAttributeValue = "missing-attribute-value", e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes", e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword", e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers", e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword", e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier", e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier", e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier", e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier", e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier", e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier", e.cdataInHtmlContent = "cdata-in-html-content", e.incorrectlyOpenedComment = "incorrectly-opened-comment", e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text", e.eofInDoctype = "eof-in-doctype", e.nestedComment = "nested-comment", e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment", e.eofInComment = "eof-in-comment", e.incorrectlyClosedComment = "incorrectly-closed-comment", e.eofInCdata = "eof-in-cdata", e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference", e.nullCharacterReference = "null-character-reference", e.surrogateCharacterReference = "surrogate-character-reference", e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range", e.controlCharacterReference = "control-character-reference", e.noncharacterCharacterReference = "noncharacter-character-reference", e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name", e.missingDoctypeName = "missing-doctype-name", e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name", e.duplicateAttribute = "duplicate-attribute", e.nonConformingDoctype = "non-conforming-doctype", e.missingDoctype = "missing-doctype", e.misplacedDoctype = "misplaced-doctype", e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element", e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements", e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head", e.openElementsLeftAfterEof = "open-elements-left-after-eof", e.abandonedHeadElementChild = "abandoned-head-element-child", e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element", e.nestedNoscriptInHead = "nested-noscript-in-head", e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text";
})(c ||= {});
//#endregion
//#region node_modules/parse5/dist/tokenizer/preprocessor.js
var l = 65536, u = class {
	constructor(e) {
		this.handler = e, this.html = "", this.pos = -1, this.lastGapPos = -2, this.gapStack = [], this.skipNextNewLine = !1, this.lastChunkWritten = !1, this.endOfChunkHit = !1, this.bufferWaterline = l, this.isEol = !1, this.lineStartPos = 0, this.droppedBufferSize = 0, this.line = 1, this.lastErrOffset = -1;
	}
	get col() {
		return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
	}
	get offset() {
		return this.droppedBufferSize + this.pos;
	}
	getError(e, t) {
		let { line: n, col: r, offset: i } = this, a = r + t, o = i + t;
		return {
			code: e,
			startLine: n,
			endLine: n,
			startCol: a,
			endCol: a,
			startOffset: o,
			endOffset: o
		};
	}
	_err(e) {
		this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(e, 0)));
	}
	_addGap() {
		this.gapStack.push(this.lastGapPos), this.lastGapPos = this.pos;
	}
	_processSurrogate(e) {
		if (this.pos !== this.html.length - 1) {
			let t = this.html.charCodeAt(this.pos + 1);
			if (i(t)) return this.pos++, this._addGap(), a(e, t);
		} else if (!this.lastChunkWritten) return this.endOfChunkHit = !0, t.EOF;
		return this._err(c.surrogateInInputStream), e;
	}
	willDropParsedChunk() {
		return this.pos > this.bufferWaterline;
	}
	dropParsedChunk() {
		this.willDropParsedChunk() && (this.html = this.html.substring(this.pos), this.lineStartPos -= this.pos, this.droppedBufferSize += this.pos, this.pos = 0, this.lastGapPos = -2, this.gapStack.length = 0);
	}
	write(e, t) {
		this.html.length > 0 ? this.html += e : this.html = e, this.endOfChunkHit = !1, this.lastChunkWritten = t;
	}
	insertHtmlAtCurrentPos(e) {
		this.html = this.html.substring(0, this.pos + 1) + e + this.html.substring(this.pos + 1), this.endOfChunkHit = !1;
	}
	startsWith(e, t) {
		if (this.pos + e.length > this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, !1;
		if (t) return this.html.startsWith(e, this.pos);
		for (let t = 0; t < e.length; t++) if ((this.html.charCodeAt(this.pos + t) | 32) !== e.charCodeAt(t)) return !1;
		return !0;
	}
	peek(e) {
		let n = this.pos + e;
		if (n >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, t.EOF;
		let r = this.html.charCodeAt(n);
		return r === t.CARRIAGE_RETURN ? t.LINE_FEED : r;
	}
	advance() {
		if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, t.EOF;
		let e = this.html.charCodeAt(this.pos);
		return e === t.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, t.LINE_FEED) : e === t.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, r(e) && (e = this._processSurrogate(e)), this.handler.onParseError === null || e > 31 && e < 127 || e === t.LINE_FEED || e === t.CARRIAGE_RETURN || e > 159 && e < 64976 || this._checkForProblematicCharacters(e), e);
	}
	_checkForProblematicCharacters(e) {
		o(e) ? this._err(c.controlCharacterInInputStream) : s(e) && this._err(c.noncharacterInInputStream);
	}
	retreat(e) {
		for (this.pos -= e; this.pos < this.lastGapPos;) this.lastGapPos = this.gapStack.pop(), this.pos--;
		this.isEol = !1;
	}
}, d;
(function(e) {
	e[e.CHARACTER = 0] = "CHARACTER", e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER", e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER", e[e.START_TAG = 3] = "START_TAG", e[e.END_TAG = 4] = "END_TAG", e[e.COMMENT = 5] = "COMMENT", e[e.DOCTYPE = 6] = "DOCTYPE", e[e.EOF = 7] = "EOF", e[e.HIBERNATION = 8] = "HIBERNATION";
})(d ||= {});
function f(e, t) {
	for (let n = e.attrs.length - 1; n >= 0; n--) if (e.attrs[n].name === t) return e.attrs[n].value;
	return null;
}
//#endregion
//#region node_modules/entities/dist/decode-codepoint.js
var p = [
	8364,
	0,
	8218,
	402,
	8222,
	8230,
	8224,
	8225,
	710,
	8240,
	352,
	8249,
	338,
	0,
	381,
	0,
	0,
	8216,
	8217,
	8220,
	8221,
	8226,
	8211,
	8212,
	732,
	8482,
	353,
	8250,
	339,
	0,
	382,
	376
];
function m(e) {
	return e === 0 || e >= 55296 && e <= 57343 || e > 1114111;
}
function h(e) {
	return m(e) ? 65533 : e >= 128 && e <= 159 && p[e - 128] || e;
}
function g(e) {
	return m(e) ? 65533 : e;
}
//#endregion
//#region node_modules/entities/dist/internal/decode-shared.js
var _ = /* #__PURE__ */ (() => {
	let e = /* @__PURE__ */ new Uint8Array(127), t = 0;
	for (let n = 33; n <= 126; n++) n !== 34 && n !== 36 && n !== 92 && (e[n] = t++);
	return e;
})();
function v(e, t, n, r, i, a) {
	let o = e.length, s = a * 90, c = 0, l = () => {
		let t = _[e.charCodeAt(c++)];
		return t < a ? t : t * 91 - s + _[e.charCodeAt(c++)];
	}, u = n - r, d = n + i, f = new Int32Array(d);
	f.fill(-1, r, a), f.fill(-1, a + u, d);
	let p = new Int32Array(d), m = new Int32Array(d);
	function h(t, n) {
		let r = 0, i = n, a = n + t;
		for (; i < a;) {
			let t = _[e.charCodeAt(c++)];
			if (t < 89) r += t, f[i++] = r;
			else if (t === 89) {
				let t = _[e.charCodeAt(c++)] + 2;
				for (; t--;) f[i++] = ++r;
			} else {
				let t = _[e.charCodeAt(c++)];
				r += 89 + (t < 90 ? t * 91 + _[e.charCodeAt(c++)] : _[e.charCodeAt(c++)] * 8281 + _[e.charCodeAt(c++)] * 91 + _[e.charCodeAt(c++)]), f[i++] = r;
			}
		}
	}
	h(r, 0), h(u, a);
	let g = new Int32Array(i * 2), v = 0, y = 0;
	function b(e, t) {
		for (let n = 0; n < e; n++) {
			let e = t + n, r = l(), i = l();
			g[y * 2] = r, g[y * 2 + 1] = i, y += 1, p[e] = v;
			let a = (f[r] < 0 ? m[r] : 1) + (f[i] < 0 ? m[i] : 1);
			m[e] = a, v += a;
		}
	}
	b(i - a + r, a + u), b(a - r, r);
	let x = new Uint16Array(v), S = 0;
	for (let e = 0; e < y; e++) for (let t = 0; t < 2; t++) {
		let n = g[e * 2 + t], r = f[n];
		if (r < 0) {
			let e = p[n], t = e + m[n];
			for (; e < t;) x[S++] = x[e++];
		} else x[S++] = r;
	}
	let C = new Uint16Array(t), w = 0;
	for (; c < o;) {
		let t = _[e.charCodeAt(c++)];
		t >= a && (t = t * 91 - s + _[e.charCodeAt(c++)]);
		let n = f[t];
		if (n < 0) {
			let e = p[t], n = e + m[t];
			for (; e < n;) C[w++] = x[e++];
		} else C[w++] = n;
	}
	return C;
}
//#endregion
//#region node_modules/entities/dist/generated/decode-data-html.js
var y = /* #__PURE__ */ v("!}.&u%}'&}*'~!6*)%&,~!J~!J~%L~y<~!R,~~%Lu~~#GD~~#|)1#%}^%}2%+#.##%##%}&%##%'#%##&%#%#'%#&#%#&#'#%%#&#%##%#)%''%&%#%#'%#%%#%%}%%%#%#&(23#%%#&-%0%('1#(##%#'##+%'*.:1}#%#6-+(%'%%#%%%}#L'2351&('%}&/N'(0(/*-%(%%}#'+&T%7.2}#&%&#%#36/5##%&%%#&#%%#))2%%##%&&'0~!#*+&'%1~!%).'3q?&%'1~!.##%6(~!+%%%(Gw'rT~!E#<nA%#jZ~!H%(~!42##~!*31&~!G%U~#)5~#`3~!J~!Z~%]~%Y~%C~!q~!u~#kz~%#~!6'~!D~!U~!?~#T~!c%~!G#'~%7|~!G~!J~!G&~#pb~(Df}#%}*&}#%##%##%##&#-}&'#'&%#.++}%mI,#,@&(}*%}*'%&##&#%##%}&0}#.},U},%}+%}&%}#%##&}B%(}(%}+%)})%##%#&}&%##%&}<%}>%#%&}*%}(%}9%}/%})%}*%}*%}?&}&%}3%}&*#%})%#%#)}#&#-#+*%E%%'%'#%}#*V##&##I}#&&##%&%#&&Qf%%))w/0+&%#(#.%-''''++++7}>%4'',##1,#%#&%##&#'##&#*#9)%&%}#*}%,#+P(%A&%#'&##wSD',9E00#y#@}(+}&%&>~!#~!X}#*}(&&}(&}(,%}%&#+&}#&}I%#%}%)#(},'%#*}4%%#%}(''}#/##(##),%-##%%)#&}(.}&%#&}%%}*&#%},&&}&%}#%*'#%})%}D&}&%}-&}6&#&}-,%}#%})-(~+`~,=?~I9'9%~!,#%})%})%}@%}?%}(~!?~#<~#pP~#BG~#=1#%K+~#?#~%;)~#A~#mF1~#A'~'X%'~#lR~#N~'N~#r~#m#-~#i'?%#'%~#B%##%,%#~#_%#0%~#]732~,w~2+#:&#%&'0%&>%}#>##F+)#%&&#(+_}4&}-%}(&}@&}O7Fdf0@+/v4}&WU##&/0#&'('B#%}.%}'+#%}#%%&#&%#%##+#&#)#6#'#.},%}c%},%#%##%&#&%#&~#>'*-.%##%##%}#%%}%'~#)D1}#%*&~#_%%'(~#S2%'.}#~#=##*'*-%}&'%'##&&~'E%.#&~#M4}%%##&'%#~#O1##%&#'+~#<B%##%%'%+~#;#@%}#&%#&&%#(~#H1}'%'##&&~#?A}&'~#D#%32}'&&&&~#[}'(#%}'~#;C})&}%%#%~#=&%,3}%'(#%%~#^'#&&)#%'~#Y%-~#d-%'~#^%%&#&&&}#~#b~2t*&'~&(~&@~0%~e~3}%*''0})&}+~!9##-}#%-hD*)1fC#%/&/fB#40~!+#)*4~!+~!K'&:~!/*7~!.#~!H~!L':~%x&~!H#~!*~%1~!I#~!+A~#p'~!F~~#-#~,,(~.Z~!V~%;'B'mq-W~!N~%I%#&&#&}#%},%%}'%}+X#%}#&}(%}'%}<%}#%}%%'}'%}:~![)9@~%>~#UA%-%##&~!C%~!-.9:~!1~!-^2/:a~!y,D*J#-5)/4~%23,~#G~!L1~!0X3`~!2+~!!0-~&E~!W~!o,>Y&]~%cZx_&~#O*9#A#'#+I'%#)~!0B*-5A+-((F&*M#)(-7-5+'-3a5Vi~!Y~!?+[)%3),ERHm~!+:D,VG.+)?fB%%*(%)'(#&80%1'8`K8?`+'Z#&O&'H5#*9)A%%5&3))0%39+.*7#()&&*=4@**L)<'_&*+..;(#*+)./&0#3)%')-8(4ixD(&.}%,('aI:,)%,k2231T)I'#/-W7,/'Q#.'Y24+h')37</31&83##&0#),H(?'&?/1##%#&&#%''-%&&&#(&''&#.-'%#%%(,')*'&#&#'##%(%(#%('#&##%%%%('%#%#%%#%#&%##h>w+v<ayvyvcg.uuhKr}g/v|g>u9i[~>g5uI~=RvdwEg;v/g;uk!!TTSx]@RT!U!#!@VBRUU!'UTe-d0c`e&gSdicedFcrdTaqb.kYcAohdYd@a3e+d}dMdtd.aJ#bqcK`dle/e.e'dwdPdodddjbEb}ogd^ofdpduc6j?l%d{drdqc)d7bacOdQ%T#Y)X.sR[yH>6Vyv3[xwLu>vo'!*.[yBacahoj>6Rew3[xqdZa#!a&#^(X-[yG>6Vyu3[xvg3sEr|g.u/Ri9db0T#^(Xa)!-[y;>6Vylg4wKs{JwNZt3@3r=c4Z([xlg;wKt!cpq's@v7A'*a(a+!-a#[y<3Dt?3Dt'>6Vym3[xmg9rxsNJwLZt4~?r?db1T#`-!(Xa,!0[yS>6Vz%NuQs.g4wKtnJwNZtS@3r>c4Z([y%g;wKtrdga8!a(!#&T*Y-Xa#!a0<or[yc3Dtq>6Vz43[y3JwNZtf@3s!Ju}!%Dti:pm3c_%X#tjB5pkd6q!r]u?voC'*-a.a2!0a&a+[yI3DtI3Ds~3DtH>6Vyw3[xx;:s#~<5pKJwNZtE@3r~d`a)!a2T#a.(!+U.X1[yT3Dt`3Dtv>6Vz&3[y&g9rxwzcxstPu.<rAJwLZtT~?r@dZa%!a.&^*Za(/Reu[ya>6Vz23[y1g3sEr}wkg{NuQRg{ci(U#5@b`~,cg#U(2WnH5wugcRh7dX#T(Y,a'Ta!!a,[yZ<]mj>6Vz,3[y+Pv#5ReZKu+=,%!H}7ABwkaS?Rh:BcW(X#<]mrj:ubv/ARekdg%!(!a.*Ta(Y.X1!#sP>Rl*Dt6[y>>6Vyo3Wf*jOvuumvuRgRJuq*!:9<B@bX~3jVv&v@s@5Re[d/rQt{uAvo&a&a*)a2!,0Wf!3Dt0=Bs'>6Re}3[xy~<5s%JwJZt1~Gs)c;&!#2sJkNuXvzq7rxu,Re8dka4!a8(aEZ+a@Y.X1Xa)[yd=Bs(3DtP>6Vz53[y4cX#X&Re:avRe9~<5s&JwJZtQ~Gs*i^rzvdRg+Jv{%!2sbB@bX}kdga,!Za?&^*T1/!a'Dt+[y6>6Vyf3Wf%g/u;s4hGu6?Rh-JvZ,!c%#&RoX54Rivj7uyvf8RgTKvZB%*!2sGh<vu5Rgq<=C::9bb~#dZ#T&Ta6Y.X*Dt>[y93Wf)coZ(T,6VyifluvRgC@95@B@bX~/hFu34cC#T,k/unq8w8Q5RkUklwQuzunq8w8Q5Rk8d/rJu?v8w9)-&!a0a;a&aIWejg3sEr/h1s<DtDJvyZqY5aws3Jvy!&Wei~Hr1:au5@Bag>23E~5c:Z&bX};kKv?w&unuVu5Rjc;>bs)#~@:Rh.=ay<a]C;b`}Vd6s/t{uAvoaxa()!a,a7%-a#a2Dt,[yF2Wo[>6Vyt3[xuNuPRi&NuPwpi#RoWh?vf8Ri%Jv]!%Ri:KvxD!.'2WeAjZu`q9rxu,Re7woeAg-unLq(qA_/*2Wg_g3u5q^9:4E}/jTrxrzv=Wkkd~0UX#^^Xa-a1a5T&a=U1a'*aEa]!a*aPaA-adok[y54Rn>;:p3~Dp5g9rpsFNvZqjg3uJp4~<5p0Pw;5qlJwNZt*@3p1Pw:5p/Ou!5p2JvG'!6Vye=<qnJvh_[xhg3v,Rh3kOwOw-sDuev/Re^dha[a%!%!a+#Ta7)-5TaCaO!aka!a)sf[yb2>Rl!9ARiq5E}Qg=ucRkBE|oJrJ_@Wk~@Wk{JrJ_@Wk|@WkyJrJ_@Wk}@WkzJvO_[y2g-vMRmiKuYC!)&>Ri;>Ri<@3RkNc](X#@9Rk=g5vuRmhKvDB!+'=]meg3u4Rmgd)#Y'Vz3CARmfd`a+!%T'!+#Ta1Ta6TaM-sTDt9[yA9sYd'%Y#s[[xpj:ueunaXRgEjRq,v-vuqdd2'`#6Rev<32@5>:2<E}5xIo9a*X#Y(;5RePJvD_g>vyRgNj8w)v8<wggs:RgXiZt|vjx,hSq3ah!-(~@:Ro/Ou!5RhWj^v(pyw8unRhUdx-UY#^Ua.a3a70!)%UX1TaDa)'omRiRRhE[y:3Dsz=Br,>6Vyj3[xkg6ruwjcqsrPw;5r*Ku]D'Zt-@3r(~?r.i[vwv]dU1a--U#`a4(g/vsRhPOu!5RhLj:rmu9Wo!~@:wdh@g/vsRiTjXuvvNr}:RhBj^v(pyw8unRn]dz1UYa'a+^Y(!aETZalaRY.Ta?a4[yDJw1!#qLsW>6Vyrfzq-pLflpwRe|Js>%!Dt@3Dt&Jvy_[xs~HrnjMuwpsw'RecKu+D#'!t<~Grl~?rjg5u-x,gwp{ah!-(~@:Rg~Ou!5Rh'jXuvvNr}:Rh#cW#X/c;&!#2sLi[v7u7RgpJv)(!iLrxu,Re6j7v@s@5Se[e7d`aW!Za(a`T.a#!a3!&aDa-!9)Dt_=6s+3[x~~DR|h~DS6avhGun5RkZj3w)v-]mkKunB!&*]kb97R|i<ARk<c:Z(6Vy}Juh'!wziMRoS:F|vkLuauJv5vtvQRh1d='T+Y#VyO~DR|jcF#T'7R|g97R|kJv3'!ay<Rj,Jvh&!:ReXcsa6*a+#a#_aIRf9aLRf?c,Z&Rf5Rf7c.Z&Rf;Rf>cQ#%T'p-Rf8Rf=ct#%'(*!,p,Rf4p+Rf6Rf:Rf<d~'Ua%U*^UYa(!a,-!#a4YaTalaEX0a8a<Weo3Dt/3Dsx=Br93Wen~Dr;~<5p<JwNZt2@3p=Pw:5p;Ou!5r3c7&!#:p>3Ds}KvGB)_6Vyk2sM=<r7x'eovA(!hFu1ARf}cV#X&@r5j6rvwQa^Rf3c=Za'wkghJv__g;unRggA53B9=b^}%j6uduo5Jq;!(hIv%2Re`Ou4ARe_e%a#^^^Xa&!a*a2!&a6YaP!*ad!#a:aE/5Rn?[y@>6Vyp;:pE~DrY~<5pBJwNZt8@3pCh=rt3rWPw:5pAJup_[xoNuPpF9c!#'45pD5ARn)d8#X'X*3@rU72s]h>v<<sSjJpqvewOJq/(!hNw'5ReBk0s2u3w/w'5ReE5@Jq.!a+JQ!&WeU23d(#Y&RjG5]jBk!u7w&u0udARjEe#+^^^Ub#!a2/a`Z(agT1!a-a;|@TaG!aS[yV=Re~fow'RguNuPRe?bz#'>RoUWeL>:Cbb|?JwPZtVg6ruRmzJvD'!6Vz(g/vmRh~Jvy_[y(g9voRgyx*cy(#2>Ri2B9b]~9kIw9u7rluJu3Rg]dI#a%UY'@=p%CAx.gQZ&RhwwygtRm{x5g_Z'+ABqR9Woa=Bp&dV#^*Xa'!&@o{g4v]Rk;Jv{!%Rk[wkkiA5RkiwwfUB=x,fUuqC&*!>RfTg8v0RfV~ARfSd;rJsAuAv9wR'ae+/aO!a@aza/a#[yQ@Wg!2Wemg3sEr0JvB_g>uvReWg2v+Re=KupB_+[y!2AbY~-~Hr2AJwD!(h<~El>h<~El?Kun@+_:9b`}Kg-v/Ri3g;vtwyk_9]k_d=&T#*U.6qh@Ab`|K9:H|CJv[!&3Dtex'fDwC%!Rf[9WlMd[(^X,!a%Z06Vz!@WgBg=v~Rgvg,QRe@awd,#Y+jTv|Q~EfWj]uNr|~FRfXdy#Y&^Ua%!aO.!(a)Ua;=!a@aKap!a-,a!Ta]a[rSa]p?[y82sK=Bq~;:p:~<5p8Pw:5p7d'#Y'Wf(;RnRi[u4w&RgJJvG'!6Vyh=<r#ijuuv/sIKuYD'ZtG@3p9~Gr&d2#`(g<vtRgFj`u5w&rqpxRf2CJuY!+:wfnTOu!5Rg}jNs1ucv&RfwJvA!&3@q|BDcC#T,k/unq8w8Q5RkTklwQuzunq8w8Q5Rk9dga#!a'!a=#a0!:+Tb*b@aO.a4!aba8aFJv^}?!VyR~Dr<g;u%Rn.~<5p[x'e`wNZtR@3p]Pw:5pZhNvjBp.woe_g5u-r4JwF!%DtO3:ooc7&!#:p^3DtpLuGw(!+%)Dtk6Vz#2sd=<r8d'#Y([y#<x3gJt`w@!)%}MRiowzikRij=]ilxAf3,U(#B2Rf#g0v-Rm[ck{`U#]giKv3>)!&6Ri154s,KuGB_%@r68r:dJ|t`#X(9<E|u2@H|rx3gJu?w'!+'1Nu7Reg4=H~+9<wxgY95Rm]xLggZ-`(X}U2:Ri4h<uOawRmsJv__5@bb{jbV~3dka#a'a]!,#a+U=a>b6a3b%!/aKa/)!arwve^VyJ;:pR~DpTg3uJpS~<5pOPw;5qmPw:5pNOu!5pQJvG'!6Vyx=<qoJvA!{~Jup!%@qk7Rn/KvyD!}''[xz;>wkh'?Rh,x8gyt`w5D!&),(SgyccRgztJ@3pPB5p#d'(Y#<]mmifubw&RgoJvE&!82s^JvF&!8Rf,ADb]~;x=h'rNu]vK!,%'*0RnORh)4Rh*AqQg-vaRnNg;wHwkh'ba~4cE#Ta*x3gctyw@'!+%RnFRnD<4Rn@hFvK5RnCxWg[#`&a0Ua()`1Rm75Rg[c]%X#qi8Rg^NvdRj>BwzgZauwji7Rm6A4wgg]d1#&(*,.0a#Rm;Rm<Rm=Rm>Rm?Rm@RmARmBe%#^^^Xaea?aC/b+(,!a+a#!a/!>a&Ta<aKbD!2wphBRnk[yPw}hE|.=Br-3Dtm>6Vy~g6urRf.x,hPrNav!%'RnqRo%Ro#Nu;q[Pw;5r+JwNZtM@3r)d'#Y'Weh;xChL#`&RnmRnoKu}>%(!Rne~Bs-;2wjcussJv+'!aYSO}6@B<5?ba~8LrNvj!.%*ROwungw~ng~:9;Ri^>wtnig;wHRnixDh@|(UZ.x1h@|)!#:2<H|*xHn]#-UX'3Ro)z=iT}6ARns=Bwsn_wpnaRncw]aR(#UXa&Ua*a/=]iPd'#Y&Ro'WnXf{QRm2hNvj]nZd`'T~&1`{|`#9b]{}c:'!#Wl{>@=be}]?cl{{U#:5Abb}Jds#^YaF!a*b4a#a3aPa>&Tb!bH!*a_!Eau?/a&RjY<]gj>6Vz*;:pe~DrZg,QRj1JwNZtX@wihspcJvZ&!VyX9WmOJu|!|N2WmHJvh&!]ht~Bpbcn&T(!#RmQ<s7Nu;padH#X'`+WmJ@>RmKCARhnKup=!)&Wf+:RhqNuPpf9c!#'45pd5AwghpARn(Ls@w!%,)!RmP@Wfe<E|IJva!&WmNg8vsRmLd`*.`#Y'Xa!axRn*]hrA8Rhug5s@rXg8u!RmMd8#X'X*3@rV72smdI*#UY&RmICARho~GsgxVgd)Ta'U-Y&Xa!T#RnEWnA@Wffg1uDRi0hFvK5RnBxGnG&#`%owp)@wsf+bX}Ze-*1!a*^^^Ua|!#a.aq&Ya2!a>.a6!a:aO`aJDtL[y`@Wg#>6Vz12@wzoYRoZNuPRi!NuPRhzg=ucRi,@=b`{Yg=ucRi-ACJvB!&Sh[ebSh]ebi`wUuFRm4Jw2_[y0JvB!.<Ju(!&SoG}6Shd}6<Ju(!&SoH}6She}6Kur@._g5vHRieJvx!{L2G{Kx6gd'T#?Rh82Wi5cZ#X(g1w)Rm5dW-Y(Ta#!a)!#aYa=wnfE=su2>>bU{0j9udv:<svj8uQv-7RgHdE%#^'sq9sp=>Bb_{TJv`!&g/r|snj6v(us5d,#Y(56H}[978H}]Jw5!&g1rushJvB!+j;v{u5?zDhd}6}bj;v{u5?zDhe}6}ce*#`(^^^a[aea!=!a6a*aoXb1a.!aAbL!b>,b'aL!aV@Wf|2Wlg3[y/JwNZt^@3piPw:5pgJunZou3@rsJva&!Vy_g<v~Rm#JvG'!6Vz0=<r{Ju{%!:pj@WfsiXuJu3Rm:JvZ&!WfA~Bph@c4Z&Dtwax5rubx(#:awRk1@d,#Y&RfjRfid1#,Y(@Wfp2Wlrg5s@ryKu[@!,'=]ig9wlk?Rk>g5u-rqJvy'!@9RkQcH(T#=>Ri~@<wkj(Wj(KuZB*!&<7rw@9RkRcH(T#=>Ri}@<wkj)Wj)dg(Ta2Xa9X#`-!a*CARhg@@=I}d9x;c~#X%so=<sj>2@@=aybb}XjWv0Q~EfEj3vLv;<d,#Y(56H}`978H}_dgaPaFa'a/!#a3Y0a_a;a|!1(a7-[yE3[xt;:pJNvZrrg3uJrvJwNZt=@3pIh=rt3rxPw:5pGOu!5rpJvG'!6Vys=<rz@c4Z&Dt(ax5rtJvZ!&~BpH@wsfNg-vaRlNci*U#=<wei<F}a5@Jq.!a*JQ!%@qZ23d(#Y&RjH5]jCk!u7w&u0udARjFd/prq=tyvpaEa(a:.!a1aZ(@@=I}:9wpd%=<sX55w_h}@@=I{t=ay<aU@@=I}T=ay<2@@=I})?C9:9au@9Cb]}DP~=x-fAZ(2Wl1=ay<aU@@=I}>5@d##Y+jTv|vV~EfFj]uNpn~FRfGdgaK!Z2&!a8a-Tb({E!acTbM*!a(DtY[yYd'%Y#sl[y*hHvh>Re5x2c{Z}.j4uCvcawRiMd+#X+_x&d!},<5RkX;2Hzw@x,gavfB-!{CcF&T#Roe;RodwWbBg5urRgaKvHC*_6Vz+<4opieuew&Rmq@d]&Y)X,T#X0Rh}<BqP=4qS9:ReMg/ujReNJw0!/<Jui%!bd{kawwnemRelAxUa?a3#*.&UX(Ya+a/RhvRnQ<o}9Wmtd-#Y&RgSRmw9;Rmxay=Rmyg-vaRmuxEhSrNu,v-voC!%(aR.a(a7+1Ro1>Ro5CE{A9b]{@;5x#eO{:g;urRi+KrNA!%(Ro3>Ro79;Ri_Ku@>{;&!x%gX|{KunA_+g5QRj/g3u5Rj#g>uERj%wio/xRhS&!,!#^1U}wba{8>>@=be}qC@:D5ba{7Ku+A&!}x?ba}t>>@=be}se(aA^^^Uat!b0#{pa+awUazbGa#aLb9bgaWac'a5TbS=Br!d1#`%scp_Jvl!#rT>Re0JvX&!VyN=H{Fcm#U&:pY=ReaJv2&!]h0=]nUJvG'!6Vy|=<r%JrM_=]h2@Wlud'#)U'Wf'b]{i=]h/Jvh!&~BpWg=v]RnMx+ny#'Nu;pVwjnu=]nwxJnx,T#`&Reqwjnt=]nvieu9vrRjLLuYwP(#+!th@wih5pX~Gr'g5v/Rh4KunA'!-CARnP@wwiN:Rm_9x'cvw>!|l=<saKvAA!0&3@q}>w^e1bp#&Re2Re3BDx7gH#T|f5H|eKuZ>!%(:qNAH{]Jv6!+3B2B9=b^{X<5<B92:E{ZLvhwA(a;a%!igQuyRmad+#Y}m@3Rh5d8#X'X*:AqUAHzmaxwbh<aXRnVcF}RT#Nw&cj#U(BWnug/vsRntdka)(a3+.Zb7aYYan1!bVa@Xa}[y^@b[{G=H{+hFu73Rj&Pv#5ReQcK%T#sig1v{Rj'Ku+D#'!t]~Grm~?rkKuMB!01d5#`'Vy.ta3Dtu~Hroc8#'{^45s85AwZbP&!#Rn!wghxWn#KvEA!)&2RlA2RlBx:h|#(T,=]j09Wobz>x]z/@awRoTd+#Y(az]hFhCrm4d,#Y+jTv|Q~EfMj]uNr|~FRfOdCa!Xa9_X#@<plJvf!%b`{(9;Rgwc;.!#2x7cw#T|UDb]|T5Ju={(!=@E{&Jv)&!Ab`{'awJvf!~*>>@=be{#KuY>!+&4Ezyi[ugv&RjIdea+T)#UXa&T-T&a!Rh9auRmW=]kLg5vuRn+g3u4Rn-Ow6ARn,hHus5xNk?#UX(U~)/g8v0RkD~AwkkF?Ri.OuNBwkkA?Ri/d|a2`a*^UYa.!aBTZaTa'Xa;!(!2!-a#b2[yC>6Vyq3[xr2Wi?g1rusVh%s?DtF~<5rbJs;%!DtBfswKtCj[uvuSsEu3RgVx3o:u+wN'*Zt;@3rd~Grh~?rfg8w)Lq)qE&-a%!>bI|`jWv0vV~EfCjTv|vV~Ef@j]uNpn~FRfBcK#T']gWNu7x,k7q4ai(0!hHv8<RhmkMu9vrsBuev/RhlCJvB!,g<v{wchh~@:Rhji[vrv{wchi~@:RhkdS&a5UY#Ta!RgPwwiI5BwciI~@:Rh`x'iJvj'!5]iJPu8Bwch]~@:Rhach)U#h3rp]gLh@t|Ax,hTq3ah!-(~@:Ro0Ou!5RhXj^v(pyw8unRhVd|)`,^UYas!a?/a2Z'a^Ta{Tb7Ta(a#!a,Wf&9sZ3DtAadamov=Bqt3[xig8vsRm~>waiL2b`{QJv*_Ouv2qgj<v]v2BqfdR'X*X#Y-@3qr~Gqv~?p6hHv-]glPup5Lq+q?_%*b_{qF{n9b^{rOu4ARhpKvCD!+&~Bqp:5Dbb}nwoiKl&unuTuBv]v+ueunaXRf0=Jvh!0nKufu8v1w&w7q%w&uHrz:Rgnj5w,uxDJq/(!hNw'5ReCk0s2u3w/w'5ReFd>Za&!*UaA=<wkgsRnSJv^!%Refifw3vyRgOKu_B'!,<]gkiiu:w&Rh<=C@a^<B57@2F{[<B5@aW:=3away9A5aW=<B=C@a^<B57@2F{Ie-#`(^^^bCara.b8aza6!/bZ,!adTbnTbOb+aFaS!aAT9@Wf~2Wli3Dtl2@d,#Y&RfnRfmJwJZtN~GqyJva&!VyMg<v~Rm%iXuJu3Rm9Jv[_=]ih9wlkDRkCd1#`(@Wg>2Wls3cH#T(@<Rj*=>Ri|b~'#23s9h<~El.d'#Y&Dtxi^rzvdRl#d*#U%(o|B2s`hJwSaxRmDKv4B&!1:Rmdd5#`'Vx}to~Hq{x'f1v3(!BA5ba|bJv_&!Wfug1v]ReIdO+U/Y#&G}-8wze=Rh{g1v]ReHg/uQRf/by#)ibQwERl/cH#T(@<Rj+=>Ri{cNu+vlax-!(#a0qa9<Rii2;;bU{H;x<i=&X#Rk`<4wwi=C9H~8xAI(Y#<azRi@45wXI<B9;5bb~7dL(X#Xa(+!aL6Vy{g5QqOau:5au2@ay547EzbxOcU(UX-T#Ta#:Cbb|A?wjh/b_|SOw6ARgtihr}u7Rhy<d1#T)X1@@=I|~=ay<2@@=aybb}Sj3vLv;<d,#Y(56H}A978H}@dGpvs@uAu`vcw9*!aFa+ai%(b!aXa8.a?a[ozWey=sU2@G}Nch&U#Rf_WexKu+D#'!t:~Gr`~?r^j]uNr|~FRg*j^psurwJt|RmcKv)@&!)7Rkv~Br[@wxfO:Rl3co#U'6Rezj_q#vIuavjRltwzeyh@vr5JqD0!>aY?C9:9au@9Cb]}9cl#U*5;5<H||jbuus1ucv&Rfvg1v~d/pppzqFr^a--a~!aMat1(hFv;Wiz@@=Izoj5uuv-7Rix~Cw`fk2WlVcZ#X,k)u3vWs@u2]ktg;wEx'fBq(_2Wg/jTv|vV~EfoJv]!15x'hzqG!(P~EfU~CRl_j6v(us5x4i-#T(2WmZ?C2F|d>Kq<aj1!*jTqIsBv=Wl`~Cw`fi2WlWj`v0u*~>RlR=c>Z,k#u3vWs@u2]kr<c1Z+jTqIsBv=Wla~Cw`fm2WlXdmb3!a{(arZa`bkTa%TbQTa-a9+c'!aM!/[yL=Bqug.w'RifhFvyDRj.g>vgwyk^9]k^Jv3_@WfbAARkhJw2_[x|JvB_wkoIRoKwkoJRoLd'(Y#<]gm=<9<H|yd'%_X#skDtb3awwqkgNulRkgdB#^',9:p'hJwSaxRmEBwVb8@4=H|qLu+w50&!)@3qs~?pU>Awwn;;Rn=c:Z'ARn<=<qwKvC@!/&~BqqJv6!&]eVb^z^xRge'/a%+^`#Sge}6<4Rn3=]n0Pw2>Rn8Jw0!&>Rn:>Rn6cY#a7+!a&=<wkaNw~h3z_c5Z{=wjh#=]nLKv^D!&)Vyz=bW|swYb<WetcG#T(2wxa@qVx@gD#Y&b^|V5JwG&!5bb|pg/w&RgD@x=kHs=uAvn!a%%/'+RmSRh694Ro`g-vaRmRhHv-]mlxCcS#`&ba~.5cD#Ta)P~=d,#Y(56H{>978H{Dd_#{2^Y%_+qbbb{6g3sERhsbU{?dfa.,`a(Xa<!aiX#(55RiG54RiHcI#T'WiU3RiVNvdwtfcRlKNvdd,#Y&RlHRlExQgf.1*^T'X#Sgf}6Wn4=]hfPrk>Rn7Jw0!&>Rn5>Rn9Lunw?&a2!,5<oq@@wqfdRlJj5Q~=d,#Y(~ARfcOuN]fdDKw;ay(}i!547E}j?cI#T(@5bV}iCbV}hdv(^^Tb?a40,b##Tbo!a*bR!a<b|a/!aKai!aU[yK=]o^g:v>ReGJwPZtK<7Rh+h<~El,Pv#5ReR@awwxjCg,ulRjDJv6&!]j!z?aQeeg>w=Sh<eeJw;!&axEzOg,Qosc!#*:wkeJ]eJ>x'h-u(!%Ro.w~h.zPdNZ(X,Ya![x{;9ReY;wkgxRiF:x?ap#Y&RmUg<s2Rkod]+UY0TZ'!a&A9sw<=bczLNvuw{gqzNhJwSaxRmCKuLay!#&s_Rf-55b^{uJvZa!!c%#(55Ri654wmiu5RiuawLu,vp!+}^%b_}Y9;wkgxba}o>A9:=b^}zKuh=a''!3awRk3c*'!#aHRk6c+Z&Rk5Rk4Jv)&!awRjSawd9*`#0?C2@EzMj8u<uJ5RmbjQrquJu3x,k>uq@_+=ayb^|W~ARkEOuN]k@7dhzV^X/X&a-#zRzSb`zXcJzTT#2WkVKvDBzW!%FzY9;5bbzWjQrquJu3Jw3%!b`zU=ayb^zQd:#X(T-a!6Vyywxh}=b]{Jg=u1RiAdGp~qHtzv!w(wA+a+a;<!aJaYai'anasb(=azRmV:Cbb{MLq2vb!%')RjuRjrRjtRjqx3jnqCw3!%')Rk(Rk+Rk&Rk)Lq2vb!%')Rj{RjxRjzRjwLq2vb!%')RjsRjpRjfRjex3jcqCw3!%')Rk'Rk*RjkRjl9<CbbzfOu4ARhxLq2vb!%')RjyRjvRjhRjgx=joq*uKvb!%')+-Rk.Rk%Rj~Rk-Rk#Rj}x=jdq*uKvb!%')+-Rk,Rk!Rj|RjmRjjRjidAq&qKs@uAv8Aa.'*-a@a&0!aM@a5[y73Dsy3Ds|3Dt):wxgI2sHJwJZt.~Gqxwsf0ikrzt}Rl0Jvy_[xj~HqzKv_A|D!&WfP8axRoVcf,U#k(v]v+ueunaXRf1Ju}'!g8u#Ri=jQw!sCunLprq>!,')~<5qeGzq9F{W=c##%s5au:5aU3CBE|;d4#X(D!a&6Vygx(b;#(=]ed?C2F{N<capoq2r[a&!aPa9,'Pw;5s:@@=I|,55w_h|@@=IzcP~=x'fCqB_2Wl2>aU@@=I|1OuNBc1Z+jTqIsBv=Wlc~Cw`fl2WlZ~AcTa%!Z+jTqIsBv=Wlb~Cw`fh2WlYk+uNqJsBv=WlSg,u3dca3#UXaMYa)TaB-=cM|7T#<bI}l5@B932:aV2G{BOuNBJq:|M!5Ezt=<B=C@a^<B57@2F{v>cB{/T#=ay<bI{3Jv6!a.6BKq0ah&+!5E}HP~Ef{978BaU@@=Iza<7d#.Y#978BaU@@=IzH~AJq0!(@@=IzG978BaU@@=IzFe,aU*Y&^^^bvJb,b:bFad!a,c2Ta>aL.bo6!a#CbTa'T#Re{2Wlh2@G{yg6t~Ro_NvdRfticuRQRllJv3&!x&c|zs@Jw3!%RflwpfkRlpKuL;%(!Re<@G|C2GzdhIvuBwgjAg-u0RjAKQB%!(GzZ@G|5NuuRl7d='T+Y#Vy[g<v~Rm!==G|>JvA!)@wma=]m1ifuaw&RmnLs@vT'!|/+[y,g:v>ReTJw1!#qX=x!eC{bLu+wT&)ZtZauq_~Graci&U#F|89:r_Lupvq!.)&2RlG8RfaC=x!eF{_h?rpWlmd&'!#X|&]k::xJey#`'T|+<E|&2@H|%dE#(^,g;u.RiEg6vjRiC9xCkA{O|zY#g=ucRmXKs0@!&*@G|m@awRknJuh!,3d(}gY}eJvj!%Rm):Jw3!%Rm+Rm-Ls0w(&!a(a#@b[|6cZ#X'7RkxWgAOu4ARn'dH'U#Y*Vz-Wm'CARm}d]*#a%^a*T'aK!a<9bV{PC=p*Jw4!&SgxcbB5r]idw(wBRmF7xFkt#&`(Rm/Rm8E|!JuY_9:Rl5=wrgr2:bbxd@xXfB(a*#T+!.X0X1Ta/a'T&RlDRfL>RlyARl9b[z[>RfZ:RlL:RfRwlg/ARl;9;RlxKv,A/!%7s69<74=BA5ba{-8Bde#`a<XaKYa1,a'P~=wxfB2bZ}}?C972@@=I}r8@55B9;5bb}G978B2@@=aybb}3j3vLv;<Jw3&!>Rfk=ayb^}4~Ad1#`*@@=aybb{w2@>==<bbz]dx+UY#^UaF!a9!bB'Ya1.!ajXa#%olRhD[y=3Dt#Ov5BrHKuMB%!(Rf^Wep~HrJwkiQjKr|~FRg)Ku+D#'!t5~GrF~?rDdV)UY,Z/_7RkuG{<~BrBg,rlsO:235B@bX}|d?a1!#`(6Vyn5@d##Y+jTv|vV~EfIj]uNpn~FRfH7Lq2vb1!a9-978BaU@@=Iz9978BbU}#~AJq0!(@@=Iz8978BaU@@=Iz7~AJQ|}!978BbU}!JvkaK!AdUa21-U#`a+(g/vsRn~Ou!5RPj:rmu9WhOjXuvvNr}:RhAj^v(pyw8unRn[kPr}p|u7vwv]RiSBd;pppzq@qHQa?(b.!a.a`@.|xa(hFv;Wiyj5uuv-7Riw~Cw`fg2WlU978BbU|wOuNBJqG!(P~EfD~CRlQcZ#X,k)u3vWs@u2]ksg;wEx'f@q1_2Wg.j]uNpn~FRfqJv]!15x'h{qG!(@@=IzK~CRl^j6v(us5x4i,#T(2WmY?C2F{1>Kq<aj1!*jTqIsBv=Wld~Cw`fj2Wl[j`v0u*~>RlT=c>Z,k#u3vWs@u2]kq<c1Z+jTqIsBv=Wle~Cw`fn2Wl]dn1#c(a(b^a2!b/bAT(bj!aDa7bu,a_a{c0!2T0g:v>ReD2@G{42@G{5~DpM~<5rc=Bx6i>{RT#RnI@zCx]y]z:2Jv[!zr5Awyk]9]k]dD(Y+X#6Vz.g=wKtgwhaCwgmTWj2Lu,w%_+/[y-B;b^xeg3u3Rj-2@bX{*KrJ<!+'@Wg(g?QRlC@Jv`!%b[zIwsfII}8JQ_@w|kW|=Jv(%!AqcOuNBJvEzh!bYzjLs@wP#(0!oy@>RkdJwMZtc3Dtd@BcG#T'9bWxg2@2Fznd*#Y+;2x'c}w<zizixNgwa#Z'U+!/!a'!a+w~g~z6wcn{Rn}wcnzRn|5Rh%=]nJg5vuRmvNvdRlvcprJu}w*az*a#!%.a.'Bot9qT]kj@Wg'ay2Gzv@Jv`!%b[zEwsfHI}1;ck#Ux`<Cbbx_Lu+w!a&0*!wko*wwo,So,}6Juqxf!E}PigQuyRm`d3(`#8>Rn%:A5B;bZ~%KvhCa!a2!x>k7#Uxb@b{#xaRk7Jw0!)>wwhlShl}6>wwhmShm}6CJvB!.x'hhvj{!!5Bwkhhbaz}x'hivjz~!5Bwkhibaz|xEhTrNu,v-vpD!a%&/)a3a.,%Ro2t[CE{)@3re9b]{%wjo09:rgc:Z&Ro6=<riifuaw&RmoKrNA!%(Ro4>Ro89;Ri`dSaL'UYzxZb)7Rka3xRhT&!,!#^1U}vbaz{>>@=be}yC@:D5bazzKu+A&!}{?ba}y>>@=be}wxBh[t`u~vJvr!%a!a()a,a0a4RoC=]o;Ju(!%RoGRhdwjh`=]oAg>w#Ro?g5vuRo=NvdRl|Ku]C.!&;RoEJvB!%RoORoMBx'h[v+_?w~h`}~5?w~hd~!xKh]oiptu-utv.vp!#%&a30a@a'a+(a/aOp(o~p!RoDJu(!%RoHRhewjha=]oBNvdRl}g>w#Ro@g5vuRo>c[#X']o<CauRoRAd-#Y':RkpauRoQKu]C.!&;RoFJvB!%RoNRoPBx'h]v+_?w~ha}t5?w~he}ue!/UbhYacXaW^Tc&a;b:a-c/#b&aja1(!cL+!bKbt!bmcRc9aIc?8[yW3Dtt94Rg`Jv}!&SiRMzBhEebShEMNuPRe>x7gL#TzuwjirRipc<Z&>on;>z=h-MSh.Mwqczx'a7vj&!>Re4@=ResJt__NuPRi*NuPRi)j]uNr|~FRfzKrJ>_+@Wfy@Wf]2WocKrJ<!+'@Wg%g/QRl@@Jv`!&awRl<wsfFIzgLu(w*!.*&ShBMwvhIRhI9;RhNx1hK'!#Sn]Mx1hK~0!#:2<H~7cNu+w7D*'1ZtW>Rn1~?rOc:Z&Rn2=<rQ<7wjh&=BSnLMc]#X(6Vz)w[b=a!U#9wzgMc3#&(RgMRitRis<x,gKt`ax!&+SioM=BSilMc3#&(RgKRinRimKurB,!&SiQMzBhDebShDM6BJQ!(P~Efx978B2@@=I}WLrJw!!,a*&@G}O@9wkibRid@@x'fKwC!&SlDMSfLMjUv~Q~EfKKv3@a+!(hFv-]mpx/hYZ(C5RiWz<o/MwkhY?So/M@x,gbvfB*&!SgEM:SoeeehFu3:Rgbda(,^TZa)X/7Sg[eb:2RgI~BrMC@wgkc:wwkcRerx3h(uUvK!&*,SnOM4Sh*MArRg;wHRh(x=h;rJvPwI!a4',a'0@Wg&=BSh/Mg>w=Rh=g3w*wwgGRgGcW(X#;Sg}M2Gzk@Jv`!&awRl=wsfGIz`dKZ*T'Y-:RhR7RhQg5u-p`j6v(us5d,#Y+~Awkia?RicOuNBwkibba}Ld6p~tyu_vbAa'a+!a/'a3aEa8a!>Sh,ebJv{!&Sh@ebSaReb9;SgwebNuPRi(NvdRl)NuPRi'hHu^<Rm^Jvv_@Wl(g;u1Si/ebKu'B&!*Sh?eb@Wl'z@aPeb95Si.ebcpputyvjB)!,&a+0a%ShAMWeK@G}C@WfJ9;RhMwvhH9w{ia}ix,hJvRA1(!zAn[MRhHx1hJ~*!#hFv(BSn[MBJQ!(@@=I~'978B2@@=I}2db.Ua<'X}+T#a0XaG2G}E;wkg|wuh!Rh!x,hZu,@)!&So0MVy)C5RiXACJvB!&5RiY5RiZg8w)cG}*T#2@bU}=KsA>(!a.3wkhZba~(x,h^u(A!&(SoCMRhb5Bz=h[eb?w~hb~6x,h_u(A!&(SoDMRhc5Bz=h]eb?w~hc~6e)aA1T#T,^^^c-bMb&blcPaP(a/!0!bA=b5c@a(!bfbrc#2afwmhARnjwchORnp2Wlf3DtsNvdRl-2@wpa<]m0bx(#:awRk2@Jw3!%RfhwpfgRlnKQB%!(G{V@G|'NuuRl6d='T+Y#VyUg<v~Rl~==G|<Jv+'!aYShC}6@B<5?ba~8@Jw3'!g2QRljhLrpWlOd+#Y'g.w'rIg>w*wgj@g-u0Rj@Lu+wT&)ZtUauq]~GrGci&U#F|39:rELrNvj!.%*RhCwunfw~nf~:9;Ri]>wtnhg;wHRnhx3hDs@v~!/+'@Wfr@9RkSNu&Rlo=@<5GzoKs0@_+@Wl+@awRkmJuh!-3d(}pY#qWJvj!%Rm(:Jw3!%Rm,Rm*de&!1U-U#`)Re;@G|.@9Ri82@wjfvRlq=@<5GzpLvOvr!).&2RlF8Rf`C=x!eE{.Jw3_g2QRlkhLrpWlPde(!#U{s,UXa*Ta'[y'g:v>ReS;x0PZ&RnlRnn~HrKJw1}f!=x!eB|2w]aP(#Xa&a*Ta.Ua2a7=]iOd'#Y&Ro&WnWg;u.RiDg6vjRiBNvdRlzhNvj]nYJuW_2Wm3x)kFze{9d])!a.!,Y01!#&aC!a3RndC=ox~BrC@2b^{pg,rlse7x'ksuq!%Rm.E{xidw(wBRmGx9o+)X#wwo-So-}69:Rl4@xSf@a#XZ'X)X,Ta(/ARl8b[xc>RfY:RlI:RfQwlg.ARl:9;Rlwdn'#^XafaQa1X1TaHTa)@b[{zcZ#X'7RkwWg@Ou4ARn&x)kG#{,g7u/RkGdH'U#Y*Vz'Wm&CARm|bx#(A]gUbUzJj9Q~=d,#Y(56H}l978H{U7d,0#U*2>ABb_xZ978BbU{e~AJQ{g!978BbU{hxMh?ad{oUYZ.x1h?{l!#:2<H{mx3n[t{vl!,&a%3Ro(z=iS}6ARnr=Bwsn^wvn`Rnbd`*T}B0!#^X'BG{c9b]{a>>@=be}F?JvS!&BG{d7BG}(Bde#`a1X,Ya@!a'P~=wxf@2bZ}I56B2@@=aybb}08@55B9;5bb}<j3vLv;<Jw3&!>Rfg=ayb^}&OuNBKuLA!)a!P~=x#fD{f2@>==<bbzl?C972@@=Ix^d6rSu,v7w*C(0a)a6#B+a%!sQ[y?3Dt%3[xn~<5rLOu!5p@Ku+D#'!t7~GrP~?rNKvlaya7'!h+v-5qMg=t|cd,U#5AAaa5Abb{S@52B5@a[@52B5Gx[iXueu;d<#`a(!/549C;ag>23ExY5@Dah89b^~689Jv)!~2b[~1Lv'w(%*!a#bX|aPrmawRe]keu7uhv-q6rxu,q`xTo]/a5aU!bNaDXbi!b-!ao!b<bwA!#5@B932:aV2G|:d-)Y#hJrL>RhG<7@C5<H|_=Cau:5aj5@B932:bJ|ng>vIbs)#?C2F|9jPv0w.vISh-MKvUaz(.!9ABbb|[5;5<H|Eg>unwfh;9:4E|YjQsBt|vjx'hYq3!(?C2F|J:2<BaY?C2F|GOu!5x,g|p{ah!-(?C2F|c9:4E|OjXuvvNr}:Rh&i[w*t|cd+U#jJvsu)vsSn~Mkfrmu9p}u7vwv]So!McW#Xa!ax5@A5aY:5;5<H|>kJv~vYrquJu3x4ib#T)2@SmZM?C2F|Bj:rmu9@xPhI(a*a#U#`a3-5Abb|L~@:RhK9:4E|0@52B5G|#C::aY?C2F|-:2<BaY?C2F|.5Jvk!a)javYrquJu3x4ia#T)2@SmYM?C2F|HAxPhH(!a#U#`a*-5Abb|4~@:RhJ9:4E|R@52B5G|F:2<BaY?C2F|Sc^#Xa2j=Qq5CJvB!-g<v{z;hhM?C2F|Zi[vrv{z;hiM?C2F|XKsA>!a)-g<v{z;h[eb?C2F|]i[vrv{z;h]eb?C2F|^iZu.vix,hZq3ah!.(?C2F|QOu!5ShXM:2<BaY?C2F|P", 13494, 2713, 49, 25, 61), b = /* #__PURE__ */ new Uint16Array([
	512,
	26465,
	29036,
	7,
	0,
	2,
	4,
	116,
	24638,
	116,
	24636,
	8693,
	29807,
	24610,
	621,
	1,
	0,
	0,
	3,
	112,
	24614,
	111,
	115,
	24615
]), x;
(function(e) {
	e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.FLAG13 = 8192] = "FLAG13", e[e.BRANCH_LENGTH = 8064] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE", e[e.VALUE_MASK = 8191] = "VALUE_MASK";
})(x ||= {});
//#endregion
//#region node_modules/entities/dist/decode.js
var S;
(function(e) {
	e[e.AMP = 38] = "AMP", e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.EQUALS = 61] = "EQUALS", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_X = 120] = "LOWER_X";
})(S ||= {});
var C = 32;
function w(e) {
	return e - S.ZERO >>> 0 <= 9;
}
function T(e) {
	return (e | C) - S.LOWER_A >>> 0 <= 5;
}
function ee(e) {
	return (e | C) - S.LOWER_A >>> 0 <= 25;
}
function te(e) {
	return e === S.EQUALS || ee(e) || w(e);
}
var E;
(function(e) {
	e[e.EntityStart = 0] = "EntityStart", e[e.NumericStart = 1] = "NumericStart", e[e.NumericDecimal = 2] = "NumericDecimal", e[e.NumericHex = 3] = "NumericHex", e[e.NamedEntity = 4] = "NamedEntity";
})(E ||= {});
var D;
(function(e) {
	e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict", e[e.Attribute = 2] = "Attribute";
})(D ||= {});
var ne = class {
	decodeTree;
	emitCodePoint;
	errors;
	state = E.EntityStart;
	consumed = 1;
	result = 0;
	treeIndex = 0;
	excess = 1;
	decodeMode = D.Strict;
	runConsumed = 0;
	constructor(e, t, n) {
		this.decodeTree = e, this.emitCodePoint = t, this.errors = n;
	}
	startEntity(e) {
		this.decodeMode = e, this.state = E.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1, this.runConsumed = 0;
	}
	write(e, t) {
		switch (this.state) {
			case E.EntityStart: return e.charCodeAt(t) === S.NUM ? (this.state = E.NumericStart, this.consumed += 1, this.stateNumericStart(e, t + 1)) : (this.state = E.NamedEntity, this.stateNamedEntity(e, t));
			case E.NumericStart: return this.stateNumericStart(e, t);
			case E.NumericDecimal: return this.stateNumericDecimal(e, t);
			case E.NumericHex: return this.stateNumericHex(e, t);
			default: return this.stateNamedEntity(e, t);
		}
	}
	stateNumericStart(e, t) {
		return t >= e.length ? -1 : (e.charCodeAt(t) | C) === S.LOWER_X ? (this.state = E.NumericHex, this.consumed += 1, this.stateNumericHex(e, t + 1)) : (this.state = E.NumericDecimal, this.stateNumericDecimal(e, t));
	}
	stateNumericHex(e, t) {
		let n = e.length, { result: r } = this, { consumed: i } = this;
		for (; t < n;) {
			let n = e.charCodeAt(t);
			if (w(n) || T(n)) {
				let e = n <= S.NINE ? n - S.ZERO : (n | C) - S.LOWER_A + 10;
				r = r * 16 + e, i += 1, t += 1;
			} else return this.result = r, this.consumed = i, this.emitNumericEntity(n, 3);
		}
		return this.result = r, this.consumed = i, -1;
	}
	stateNumericDecimal(e, t) {
		let n = e.length, { result: r } = this, { consumed: i } = this;
		for (; t < n;) {
			let n = e.charCodeAt(t) - S.ZERO;
			if (n >>> 0 > 9) return this.result = r, this.consumed = i, this.emitNumericEntity(n + S.ZERO, 2);
			r = r * 10 + n, i += 1, t += 1;
		}
		return this.result = r, this.consumed = i, -1;
	}
	emitNumericEntity(e, t) {
		if (this.consumed <= t) return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
		if (e === S.SEMI) this.consumed += 1;
		else if (this.decodeMode === D.Strict) return 0;
		return this.emitCodePoint((this.decodeTree === b ? g : h)(this.result), this.consumed), this.errors && (e !== S.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
	}
	flushAndEmitLegacyOrReject(e, t, n, r) {
		return this.consumed = e, this.excess = t, this.result === 0 || this.decodeMode === D.Attribute && (r === 0 || t > 1 || te(n)) ? 0 : this.emitNotTerminatedNamedEntity();
	}
	stateNamedEntity(e, t) {
		let { decodeTree: n } = this, r = e.length, i = this.decodeMode === D.Strict, { treeIndex: a } = this, { excess: o } = this, { consumed: s } = this, c = n[a];
		for (; t < r;) {
			for (; (c & (x.VALUE_LENGTH | x.FLAG13)) === 0 && (c & x.JUMP_TABLE) !== 0;) {
				let i = e.charCodeAt(t), l = c & x.JUMP_TABLE, u = (c & x.BRANCH_LENGTH) >> 7;
				if (u === 0) {
					if (i !== l) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					a += 1;
				} else {
					let e = i - l;
					if (e >>> 0 >= u) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					let t = n[a + 1 + e];
					if (t === 0) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					a = a + u + t & 65535;
				}
				if (c = n[a], t += 1, o += 1, t >= r) break;
			}
			if (t >= r) break;
			if ((c & (x.VALUE_LENGTH | x.FLAG13)) === x.FLAG13) {
				let i = (c & x.BRANCH_LENGTH) >> 7, { runConsumed: l } = this;
				if (l === 0) {
					let n = e.charCodeAt(t);
					if (n !== (c & x.JUMP_TABLE)) return this.flushAndEmitLegacyOrReject(s, o, n, 0);
					t += 1, o += 1, l = 1;
				}
				for (; l < i;) {
					if (t >= r) return this.treeIndex = a, this.excess = o, this.consumed = s, this.runConsumed = l, -1;
					let i = l - 1, c = n[a + 1 + (i >> 1)] >> ((i & 1) << 3) & 255, u = e.charCodeAt(t);
					if (u !== c) return this.runConsumed = 0, this.flushAndEmitLegacyOrReject(s, o, u, 0);
					t += 1, o += 1, l += 1;
				}
				this.runConsumed = 0, a += 1 + (i >> 1), c = n[a];
				continue;
			}
			let l = c >>> 14, u = e.charCodeAt(t);
			if (l !== 0) {
				if (!i && (c & x.FLAG13) === 0 && (this.result = a, s += o - 1, o = 1), u === S.SEMI) return this.emitNamedEntityData(a, l, s + o);
				if (l === 1) return this.flushAndEmitLegacyOrReject(s, o, u, l);
			}
			let d = re(n, c, a + (l || 1), u);
			if (d < 0) return this.flushAndEmitLegacyOrReject(s, o, u, l);
			a = d, c = n[a], t += 1, o += 1;
		}
		return !i && c >>> 14 && (c & x.FLAG13) === 0 && (this.result = a, s += o - 1, o = 1), this.treeIndex = a, this.excess = o, this.consumed = s, -1;
	}
	emitNotTerminatedNamedEntity() {
		let { result: e, decodeTree: t } = this, n = t[e] >>> 14;
		return this.emitNamedEntityData(e, n, this.consumed), this.errors?.missingSemicolonAfterCharacterReference(), this.consumed;
	}
	emitNamedEntityData(e, t, n) {
		let { decodeTree: r } = this;
		return this.emitCodePoint(t === 1 ? r[e] & x.VALUE_MASK : r[e + 1], n), t === 3 && this.emitCodePoint(r[e + 2], n), n;
	}
	end() {
		switch (this.state) {
			case E.NamedEntity: return this.result !== 0 && (this.decodeMode !== D.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
			case E.NumericDecimal: return this.emitNumericEntity(0, 2);
			case E.NumericHex: return this.emitNumericEntity(0, 3);
			case E.NumericStart: return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
			default: return 0;
		}
	}
};
function re(e, t, n, r) {
	let i = (t & x.BRANCH_LENGTH) >> 7, a = t & x.JUMP_TABLE;
	if (a) {
		if (i === 0) return r === a ? n : -1;
		let t = r - a;
		if (t >>> 0 >= i) return -1;
		let o = e[n + t];
		return o === 0 ? -1 : n + i + o - 1 & 65535;
	}
	if (i === 0) return -1;
	let o = i + 1 >> 1, s = n + o + i;
	for (let t = 0; t < i; t++) {
		let i = e[n + (t >> 1)] >> ((t & 1) << 3) & 255;
		if (i === r) return s + e[n + o + t] & 65535;
		if (i > r) return -1;
	}
	return -1;
}
//#endregion
//#region node_modules/parse5/dist/common/html.js
var O;
(function(e) {
	e.HTML = "http://www.w3.org/1999/xhtml", e.MATHML = "http://www.w3.org/1998/Math/MathML", e.SVG = "http://www.w3.org/2000/svg", e.XLINK = "http://www.w3.org/1999/xlink", e.XML = "http://www.w3.org/XML/1998/namespace", e.XMLNS = "http://www.w3.org/2000/xmlns/";
})(O ||= {});
var ie;
(function(e) {
	e.TYPE = "type", e.ACTION = "action", e.ENCODING = "encoding", e.PROMPT = "prompt", e.NAME = "name", e.COLOR = "color", e.FACE = "face", e.SIZE = "size";
})(ie ||= {});
var k;
(function(e) {
	e.NO_QUIRKS = "no-quirks", e.QUIRKS = "quirks", e.LIMITED_QUIRKS = "limited-quirks";
})(k ||= {});
var A;
(function(e) {
	e.A = "a", e.ADDRESS = "address", e.ANNOTATION_XML = "annotation-xml", e.APPLET = "applet", e.AREA = "area", e.ARTICLE = "article", e.ASIDE = "aside", e.B = "b", e.BASE = "base", e.BASEFONT = "basefont", e.BGSOUND = "bgsound", e.BIG = "big", e.BLOCKQUOTE = "blockquote", e.BODY = "body", e.BR = "br", e.BUTTON = "button", e.CAPTION = "caption", e.CENTER = "center", e.CODE = "code", e.COL = "col", e.COLGROUP = "colgroup", e.DD = "dd", e.DESC = "desc", e.DETAILS = "details", e.DIALOG = "dialog", e.DIR = "dir", e.DIV = "div", e.DL = "dl", e.DT = "dt", e.EM = "em", e.EMBED = "embed", e.FIELDSET = "fieldset", e.FIGCAPTION = "figcaption", e.FIGURE = "figure", e.FONT = "font", e.FOOTER = "footer", e.FOREIGN_OBJECT = "foreignObject", e.FORM = "form", e.FRAME = "frame", e.FRAMESET = "frameset", e.H1 = "h1", e.H2 = "h2", e.H3 = "h3", e.H4 = "h4", e.H5 = "h5", e.H6 = "h6", e.HEAD = "head", e.HEADER = "header", e.HGROUP = "hgroup", e.HR = "hr", e.HTML = "html", e.I = "i", e.IMG = "img", e.IMAGE = "image", e.INPUT = "input", e.IFRAME = "iframe", e.KEYGEN = "keygen", e.LABEL = "label", e.LI = "li", e.LINK = "link", e.LISTING = "listing", e.MAIN = "main", e.MALIGNMARK = "malignmark", e.MARQUEE = "marquee", e.MATH = "math", e.MENU = "menu", e.META = "meta", e.MGLYPH = "mglyph", e.MI = "mi", e.MO = "mo", e.MN = "mn", e.MS = "ms", e.MTEXT = "mtext", e.NAV = "nav", e.NOBR = "nobr", e.NOFRAMES = "noframes", e.NOEMBED = "noembed", e.NOSCRIPT = "noscript", e.OBJECT = "object", e.OL = "ol", e.OPTGROUP = "optgroup", e.OPTION = "option", e.P = "p", e.PARAM = "param", e.PLAINTEXT = "plaintext", e.PRE = "pre", e.RB = "rb", e.RP = "rp", e.RT = "rt", e.RTC = "rtc", e.RUBY = "ruby", e.S = "s", e.SCRIPT = "script", e.SEARCH = "search", e.SECTION = "section", e.SELECT = "select", e.SOURCE = "source", e.SMALL = "small", e.SPAN = "span", e.STRIKE = "strike", e.STRONG = "strong", e.STYLE = "style", e.SUB = "sub", e.SUMMARY = "summary", e.SUP = "sup", e.TABLE = "table", e.TBODY = "tbody", e.TEMPLATE = "template", e.TEXTAREA = "textarea", e.TFOOT = "tfoot", e.TD = "td", e.TH = "th", e.THEAD = "thead", e.TITLE = "title", e.TR = "tr", e.TRACK = "track", e.TT = "tt", e.U = "u", e.UL = "ul", e.SVG = "svg", e.VAR = "var", e.WBR = "wbr", e.XMP = "xmp";
})(A ||= {});
var j;
(function(e) {
	e[e.UNKNOWN = 0] = "UNKNOWN", e[e.A = 1] = "A", e[e.ADDRESS = 2] = "ADDRESS", e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML", e[e.APPLET = 4] = "APPLET", e[e.AREA = 5] = "AREA", e[e.ARTICLE = 6] = "ARTICLE", e[e.ASIDE = 7] = "ASIDE", e[e.B = 8] = "B", e[e.BASE = 9] = "BASE", e[e.BASEFONT = 10] = "BASEFONT", e[e.BGSOUND = 11] = "BGSOUND", e[e.BIG = 12] = "BIG", e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE", e[e.BODY = 14] = "BODY", e[e.BR = 15] = "BR", e[e.BUTTON = 16] = "BUTTON", e[e.CAPTION = 17] = "CAPTION", e[e.CENTER = 18] = "CENTER", e[e.CODE = 19] = "CODE", e[e.COL = 20] = "COL", e[e.COLGROUP = 21] = "COLGROUP", e[e.DD = 22] = "DD", e[e.DESC = 23] = "DESC", e[e.DETAILS = 24] = "DETAILS", e[e.DIALOG = 25] = "DIALOG", e[e.DIR = 26] = "DIR", e[e.DIV = 27] = "DIV", e[e.DL = 28] = "DL", e[e.DT = 29] = "DT", e[e.EM = 30] = "EM", e[e.EMBED = 31] = "EMBED", e[e.FIELDSET = 32] = "FIELDSET", e[e.FIGCAPTION = 33] = "FIGCAPTION", e[e.FIGURE = 34] = "FIGURE", e[e.FONT = 35] = "FONT", e[e.FOOTER = 36] = "FOOTER", e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT", e[e.FORM = 38] = "FORM", e[e.FRAME = 39] = "FRAME", e[e.FRAMESET = 40] = "FRAMESET", e[e.H1 = 41] = "H1", e[e.H2 = 42] = "H2", e[e.H3 = 43] = "H3", e[e.H4 = 44] = "H4", e[e.H5 = 45] = "H5", e[e.H6 = 46] = "H6", e[e.HEAD = 47] = "HEAD", e[e.HEADER = 48] = "HEADER", e[e.HGROUP = 49] = "HGROUP", e[e.HR = 50] = "HR", e[e.HTML = 51] = "HTML", e[e.I = 52] = "I", e[e.IMG = 53] = "IMG", e[e.IMAGE = 54] = "IMAGE", e[e.INPUT = 55] = "INPUT", e[e.IFRAME = 56] = "IFRAME", e[e.KEYGEN = 57] = "KEYGEN", e[e.LABEL = 58] = "LABEL", e[e.LI = 59] = "LI", e[e.LINK = 60] = "LINK", e[e.LISTING = 61] = "LISTING", e[e.MAIN = 62] = "MAIN", e[e.MALIGNMARK = 63] = "MALIGNMARK", e[e.MARQUEE = 64] = "MARQUEE", e[e.MATH = 65] = "MATH", e[e.MENU = 66] = "MENU", e[e.META = 67] = "META", e[e.MGLYPH = 68] = "MGLYPH", e[e.MI = 69] = "MI", e[e.MO = 70] = "MO", e[e.MN = 71] = "MN", e[e.MS = 72] = "MS", e[e.MTEXT = 73] = "MTEXT", e[e.NAV = 74] = "NAV", e[e.NOBR = 75] = "NOBR", e[e.NOFRAMES = 76] = "NOFRAMES", e[e.NOEMBED = 77] = "NOEMBED", e[e.NOSCRIPT = 78] = "NOSCRIPT", e[e.OBJECT = 79] = "OBJECT", e[e.OL = 80] = "OL", e[e.OPTGROUP = 81] = "OPTGROUP", e[e.OPTION = 82] = "OPTION", e[e.P = 83] = "P", e[e.PARAM = 84] = "PARAM", e[e.PLAINTEXT = 85] = "PLAINTEXT", e[e.PRE = 86] = "PRE", e[e.RB = 87] = "RB", e[e.RP = 88] = "RP", e[e.RT = 89] = "RT", e[e.RTC = 90] = "RTC", e[e.RUBY = 91] = "RUBY", e[e.S = 92] = "S", e[e.SCRIPT = 93] = "SCRIPT", e[e.SEARCH = 94] = "SEARCH", e[e.SECTION = 95] = "SECTION", e[e.SELECT = 96] = "SELECT", e[e.SOURCE = 97] = "SOURCE", e[e.SMALL = 98] = "SMALL", e[e.SPAN = 99] = "SPAN", e[e.STRIKE = 100] = "STRIKE", e[e.STRONG = 101] = "STRONG", e[e.STYLE = 102] = "STYLE", e[e.SUB = 103] = "SUB", e[e.SUMMARY = 104] = "SUMMARY", e[e.SUP = 105] = "SUP", e[e.TABLE = 106] = "TABLE", e[e.TBODY = 107] = "TBODY", e[e.TEMPLATE = 108] = "TEMPLATE", e[e.TEXTAREA = 109] = "TEXTAREA", e[e.TFOOT = 110] = "TFOOT", e[e.TD = 111] = "TD", e[e.TH = 112] = "TH", e[e.THEAD = 113] = "THEAD", e[e.TITLE = 114] = "TITLE", e[e.TR = 115] = "TR", e[e.TRACK = 116] = "TRACK", e[e.TT = 117] = "TT", e[e.U = 118] = "U", e[e.UL = 119] = "UL", e[e.SVG = 120] = "SVG", e[e.VAR = 121] = "VAR", e[e.WBR = 122] = "WBR", e[e.XMP = 123] = "XMP";
})(j ||= {});
var ae = /* @__PURE__ */ new Map([
	[A.A, j.A],
	[A.ADDRESS, j.ADDRESS],
	[A.ANNOTATION_XML, j.ANNOTATION_XML],
	[A.APPLET, j.APPLET],
	[A.AREA, j.AREA],
	[A.ARTICLE, j.ARTICLE],
	[A.ASIDE, j.ASIDE],
	[A.B, j.B],
	[A.BASE, j.BASE],
	[A.BASEFONT, j.BASEFONT],
	[A.BGSOUND, j.BGSOUND],
	[A.BIG, j.BIG],
	[A.BLOCKQUOTE, j.BLOCKQUOTE],
	[A.BODY, j.BODY],
	[A.BR, j.BR],
	[A.BUTTON, j.BUTTON],
	[A.CAPTION, j.CAPTION],
	[A.CENTER, j.CENTER],
	[A.CODE, j.CODE],
	[A.COL, j.COL],
	[A.COLGROUP, j.COLGROUP],
	[A.DD, j.DD],
	[A.DESC, j.DESC],
	[A.DETAILS, j.DETAILS],
	[A.DIALOG, j.DIALOG],
	[A.DIR, j.DIR],
	[A.DIV, j.DIV],
	[A.DL, j.DL],
	[A.DT, j.DT],
	[A.EM, j.EM],
	[A.EMBED, j.EMBED],
	[A.FIELDSET, j.FIELDSET],
	[A.FIGCAPTION, j.FIGCAPTION],
	[A.FIGURE, j.FIGURE],
	[A.FONT, j.FONT],
	[A.FOOTER, j.FOOTER],
	[A.FOREIGN_OBJECT, j.FOREIGN_OBJECT],
	[A.FORM, j.FORM],
	[A.FRAME, j.FRAME],
	[A.FRAMESET, j.FRAMESET],
	[A.H1, j.H1],
	[A.H2, j.H2],
	[A.H3, j.H3],
	[A.H4, j.H4],
	[A.H5, j.H5],
	[A.H6, j.H6],
	[A.HEAD, j.HEAD],
	[A.HEADER, j.HEADER],
	[A.HGROUP, j.HGROUP],
	[A.HR, j.HR],
	[A.HTML, j.HTML],
	[A.I, j.I],
	[A.IMG, j.IMG],
	[A.IMAGE, j.IMAGE],
	[A.INPUT, j.INPUT],
	[A.IFRAME, j.IFRAME],
	[A.KEYGEN, j.KEYGEN],
	[A.LABEL, j.LABEL],
	[A.LI, j.LI],
	[A.LINK, j.LINK],
	[A.LISTING, j.LISTING],
	[A.MAIN, j.MAIN],
	[A.MALIGNMARK, j.MALIGNMARK],
	[A.MARQUEE, j.MARQUEE],
	[A.MATH, j.MATH],
	[A.MENU, j.MENU],
	[A.META, j.META],
	[A.MGLYPH, j.MGLYPH],
	[A.MI, j.MI],
	[A.MO, j.MO],
	[A.MN, j.MN],
	[A.MS, j.MS],
	[A.MTEXT, j.MTEXT],
	[A.NAV, j.NAV],
	[A.NOBR, j.NOBR],
	[A.NOFRAMES, j.NOFRAMES],
	[A.NOEMBED, j.NOEMBED],
	[A.NOSCRIPT, j.NOSCRIPT],
	[A.OBJECT, j.OBJECT],
	[A.OL, j.OL],
	[A.OPTGROUP, j.OPTGROUP],
	[A.OPTION, j.OPTION],
	[A.P, j.P],
	[A.PARAM, j.PARAM],
	[A.PLAINTEXT, j.PLAINTEXT],
	[A.PRE, j.PRE],
	[A.RB, j.RB],
	[A.RP, j.RP],
	[A.RT, j.RT],
	[A.RTC, j.RTC],
	[A.RUBY, j.RUBY],
	[A.S, j.S],
	[A.SCRIPT, j.SCRIPT],
	[A.SEARCH, j.SEARCH],
	[A.SECTION, j.SECTION],
	[A.SELECT, j.SELECT],
	[A.SOURCE, j.SOURCE],
	[A.SMALL, j.SMALL],
	[A.SPAN, j.SPAN],
	[A.STRIKE, j.STRIKE],
	[A.STRONG, j.STRONG],
	[A.STYLE, j.STYLE],
	[A.SUB, j.SUB],
	[A.SUMMARY, j.SUMMARY],
	[A.SUP, j.SUP],
	[A.TABLE, j.TABLE],
	[A.TBODY, j.TBODY],
	[A.TEMPLATE, j.TEMPLATE],
	[A.TEXTAREA, j.TEXTAREA],
	[A.TFOOT, j.TFOOT],
	[A.TD, j.TD],
	[A.TH, j.TH],
	[A.THEAD, j.THEAD],
	[A.TITLE, j.TITLE],
	[A.TR, j.TR],
	[A.TRACK, j.TRACK],
	[A.TT, j.TT],
	[A.U, j.U],
	[A.UL, j.UL],
	[A.SVG, j.SVG],
	[A.VAR, j.VAR],
	[A.WBR, j.WBR],
	[A.XMP, j.XMP]
]);
function oe(e) {
	return ae.get(e) ?? j.UNKNOWN;
}
var M = j, se = {
	[O.HTML]: /* @__PURE__ */ new Set([
		M.ADDRESS,
		M.APPLET,
		M.AREA,
		M.ARTICLE,
		M.ASIDE,
		M.BASE,
		M.BASEFONT,
		M.BGSOUND,
		M.BLOCKQUOTE,
		M.BODY,
		M.BR,
		M.BUTTON,
		M.CAPTION,
		M.CENTER,
		M.COL,
		M.COLGROUP,
		M.DD,
		M.DETAILS,
		M.DIR,
		M.DIV,
		M.DL,
		M.DT,
		M.EMBED,
		M.FIELDSET,
		M.FIGCAPTION,
		M.FIGURE,
		M.FOOTER,
		M.FORM,
		M.FRAME,
		M.FRAMESET,
		M.H1,
		M.H2,
		M.H3,
		M.H4,
		M.H5,
		M.H6,
		M.HEAD,
		M.HEADER,
		M.HGROUP,
		M.HR,
		M.HTML,
		M.IFRAME,
		M.IMG,
		M.INPUT,
		M.LI,
		M.LINK,
		M.LISTING,
		M.MAIN,
		M.MARQUEE,
		M.MENU,
		M.META,
		M.NAV,
		M.NOEMBED,
		M.NOFRAMES,
		M.NOSCRIPT,
		M.OBJECT,
		M.OL,
		M.P,
		M.PARAM,
		M.PLAINTEXT,
		M.PRE,
		M.SCRIPT,
		M.SECTION,
		M.SELECT,
		M.SOURCE,
		M.STYLE,
		M.SUMMARY,
		M.TABLE,
		M.TBODY,
		M.TD,
		M.TEMPLATE,
		M.TEXTAREA,
		M.TFOOT,
		M.TH,
		M.THEAD,
		M.TITLE,
		M.TR,
		M.TRACK,
		M.UL,
		M.WBR,
		M.XMP
	]),
	[O.MATHML]: /* @__PURE__ */ new Set([
		M.MI,
		M.MO,
		M.MN,
		M.MS,
		M.MTEXT,
		M.ANNOTATION_XML
	]),
	[O.SVG]: /* @__PURE__ */ new Set([
		M.TITLE,
		M.FOREIGN_OBJECT,
		M.DESC
	]),
	[O.XLINK]: /* @__PURE__ */ new Set(),
	[O.XML]: /* @__PURE__ */ new Set(),
	[O.XMLNS]: /* @__PURE__ */ new Set()
}, ce = /* @__PURE__ */ new Set([
	M.H1,
	M.H2,
	M.H3,
	M.H4,
	M.H5,
	M.H6
]);
A.STYLE, A.SCRIPT, A.XMP, A.IFRAME, A.NOEMBED, A.NOFRAMES, A.PLAINTEXT;
//#endregion
//#region node_modules/parse5/dist/tokenizer/index.js
var N;
(function(e) {
	e[e.DATA = 0] = "DATA", e[e.RCDATA = 1] = "RCDATA", e[e.RAWTEXT = 2] = "RAWTEXT", e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA", e[e.PLAINTEXT = 4] = "PLAINTEXT", e[e.TAG_OPEN = 5] = "TAG_OPEN", e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN", e[e.TAG_NAME = 7] = "TAG_NAME", e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN", e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN", e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME", e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN", e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN", e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME", e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN", e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN", e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME", e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START", e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH", e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED", e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH", e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START", e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END", e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME", e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME", e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME", e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE", e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED", e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED", e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED", e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED", e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG", e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT", e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN", e[e.COMMENT_START = 42] = "COMMENT_START", e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH", e[e.COMMENT = 44] = "COMMENT", e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN", e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH", e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH", e[e.COMMENT_END = 50] = "COMMENT_END", e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG", e[e.DOCTYPE = 52] = "DOCTYPE", e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME", e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME", e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME", e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD", e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER", e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER", e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS", e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD", e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER", e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER", e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE", e[e.CDATA_SECTION = 68] = "CDATA_SECTION", e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET", e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END", e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE", e[e.AMBIGUOUS_AMPERSAND = 72] = "AMBIGUOUS_AMPERSAND";
})(N ||= {});
var P = {
	DATA: N.DATA,
	RCDATA: N.RCDATA,
	RAWTEXT: N.RAWTEXT,
	SCRIPT_DATA: N.SCRIPT_DATA,
	PLAINTEXT: N.PLAINTEXT,
	CDATA_SECTION: N.CDATA_SECTION
};
function le(e) {
	return e >= t.DIGIT_0 && e <= t.DIGIT_9;
}
function ue(e) {
	return e >= t.LATIN_CAPITAL_A && e <= t.LATIN_CAPITAL_Z;
}
function de(e) {
	return e >= t.LATIN_SMALL_A && e <= t.LATIN_SMALL_Z;
}
function fe(e) {
	return de(e) || ue(e);
}
function pe(e) {
	return fe(e) || le(e);
}
function me(e) {
	return e + 32;
}
function he(e) {
	return e === t.SPACE || e === t.LINE_FEED || e === t.TABULATION || e === t.FORM_FEED;
}
function ge(e) {
	return he(e) || e === t.SOLIDUS || e === t.GREATER_THAN_SIGN;
}
function _e(e) {
	return e === t.NULL ? c.nullCharacterReference : e > 1114111 ? c.characterReferenceOutsideUnicodeRange : r(e) ? c.surrogateCharacterReference : s(e) ? c.noncharacterCharacterReference : o(e) || e === t.CARRIAGE_RETURN ? c.controlCharacterReference : null;
}
var ve = class {
	constructor(e, t) {
		this.options = e, this.handler = t, this.paused = !1, this.inLoop = !1, this.inForeignNode = !1, this.lastStartTagName = "", this.active = !1, this.state = N.DATA, this.returnState = N.DATA, this.entityStartPos = 0, this.consumedAfterSnapshot = -1, this.currentCharacterToken = null, this.currentToken = null, this.currentAttr = {
			name: "",
			value: ""
		}, this.preprocessor = new u(t), this.currentLocation = this.getCurrentLocation(-1), this.entityDecoder = new ne(y, (e, t) => {
			this.preprocessor.pos = this.entityStartPos + t - 1, this._flushCodePointConsumedAsCharacterReference(e);
		}, t.onParseError ? {
			missingSemicolonAfterCharacterReference: () => {
				this._err(c.missingSemicolonAfterCharacterReference, 1);
			},
			absenceOfDigitsInNumericCharacterReference: (e) => {
				this._err(c.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + e);
			},
			validateNumericCharacterReference: (e) => {
				let t = _e(e);
				t && this._err(t, 1);
			}
		} : void 0);
	}
	_err(e, t = 0) {
		var n, r;
		(r = (n = this.handler).onParseError) == null || r.call(n, this.preprocessor.getError(e, t));
	}
	getCurrentLocation(e) {
		return this.options.sourceCodeLocationInfo ? {
			startLine: this.preprocessor.line,
			startCol: this.preprocessor.col - e,
			startOffset: this.preprocessor.offset - e,
			endLine: -1,
			endCol: -1,
			endOffset: -1
		} : null;
	}
	_runParsingLoop() {
		if (!this.inLoop) {
			for (this.inLoop = !0; this.active && !this.paused;) {
				this.consumedAfterSnapshot = 0;
				let e = this._consume();
				this._ensureHibernation() || this._callState(e);
			}
			this.inLoop = !1;
		}
	}
	pause() {
		this.paused = !0;
	}
	resume(e) {
		if (!this.paused) throw Error("Parser was already resumed");
		this.paused = !1, !this.inLoop && (this._runParsingLoop(), this.paused || e?.());
	}
	write(e, t, n) {
		this.active = !0, this.preprocessor.write(e, t), this._runParsingLoop(), this.paused || n?.();
	}
	insertHtmlAtCurrentPos(e) {
		this.active = !0, this.preprocessor.insertHtmlAtCurrentPos(e), this._runParsingLoop();
	}
	_ensureHibernation() {
		return this.preprocessor.endOfChunkHit ? (this.preprocessor.retreat(this.consumedAfterSnapshot), this.consumedAfterSnapshot = 0, this.active = !1, !0) : !1;
	}
	_consume() {
		return this.consumedAfterSnapshot++, this.preprocessor.advance();
	}
	_advanceBy(e) {
		this.consumedAfterSnapshot += e;
		for (let t = 0; t < e; t++) this.preprocessor.advance();
	}
	_consumeSequenceIfMatch(e, t) {
		return this.preprocessor.startsWith(e, t) ? (this._advanceBy(e.length - 1), !0) : !1;
	}
	_createStartTagToken() {
		this.currentToken = {
			type: d.START_TAG,
			tagName: "",
			tagID: j.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(1)
		};
	}
	_createEndTagToken() {
		this.currentToken = {
			type: d.END_TAG,
			tagName: "",
			tagID: j.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(2)
		};
	}
	_createCommentToken(e) {
		this.currentToken = {
			type: d.COMMENT,
			data: "",
			location: this.getCurrentLocation(e)
		};
	}
	_createDoctypeToken(e) {
		this.currentToken = {
			type: d.DOCTYPE,
			name: e,
			forceQuirks: !1,
			publicId: null,
			systemId: null,
			location: this.currentLocation
		};
	}
	_createCharacterToken(e, t) {
		this.currentCharacterToken = {
			type: e,
			chars: t,
			location: this.currentLocation
		};
	}
	_createAttr(e) {
		this.currentAttr = {
			name: e,
			value: ""
		}, this.currentLocation = this.getCurrentLocation(0);
	}
	_leaveAttrName() {
		var e;
		let t = this.currentToken;
		if (f(t, this.currentAttr.name) === null) {
			if (t.attrs.push(this.currentAttr), t.location && this.currentLocation) {
				let n = (e = t.location).attrs ?? (e.attrs = Object.create(null));
				n[this.currentAttr.name] = this.currentLocation, this._leaveAttrValue();
			}
		} else this._err(c.duplicateAttribute);
	}
	_leaveAttrValue() {
		this.currentLocation && (this.currentLocation.endLine = this.preprocessor.line, this.currentLocation.endCol = this.preprocessor.col, this.currentLocation.endOffset = this.preprocessor.offset);
	}
	prepareToken(e) {
		this._emitCurrentCharacterToken(e.location), this.currentToken = null, e.location && (e.location.endLine = this.preprocessor.line, e.location.endCol = this.preprocessor.col + 1, e.location.endOffset = this.preprocessor.offset + 1), this.currentLocation = this.getCurrentLocation(-1);
	}
	emitCurrentTagToken() {
		let e = this.currentToken;
		this.prepareToken(e), e.tagID = oe(e.tagName), e.type === d.START_TAG ? (this.lastStartTagName = e.tagName, this.handler.onStartTag(e)) : (e.attrs.length > 0 && this._err(c.endTagWithAttributes), e.selfClosing && this._err(c.endTagWithTrailingSolidus), this.handler.onEndTag(e)), this.preprocessor.dropParsedChunk();
	}
	emitCurrentComment(e) {
		this.prepareToken(e), this.handler.onComment(e), this.preprocessor.dropParsedChunk();
	}
	emitCurrentDoctype(e) {
		this.prepareToken(e), this.handler.onDoctype(e), this.preprocessor.dropParsedChunk();
	}
	_emitCurrentCharacterToken(e) {
		if (this.currentCharacterToken) {
			switch (e && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = e.startLine, this.currentCharacterToken.location.endCol = e.startCol, this.currentCharacterToken.location.endOffset = e.startOffset), this.currentCharacterToken.type) {
				case d.CHARACTER:
					this.handler.onCharacter(this.currentCharacterToken);
					break;
				case d.NULL_CHARACTER:
					this.handler.onNullCharacter(this.currentCharacterToken);
					break;
				case d.WHITESPACE_CHARACTER: this.handler.onWhitespaceCharacter(this.currentCharacterToken);
			}
			this.currentCharacterToken = null;
		}
	}
	_emitEOFToken() {
		let e = this.getCurrentLocation(0);
		e && (e.endLine = e.startLine, e.endCol = e.startCol, e.endOffset = e.startOffset), this._emitCurrentCharacterToken(e), this.handler.onEof({
			type: d.EOF,
			location: e
		}), this.active = !1;
	}
	_appendCharToCurrentCharacterToken(e, t) {
		if (this.currentCharacterToken) {
			if (this.currentCharacterToken.type === e) {
				this.currentCharacterToken.chars += t;
				return;
			}
			this.currentLocation = this.getCurrentLocation(0), this._emitCurrentCharacterToken(this.currentLocation), this.preprocessor.dropParsedChunk();
		}
		this._createCharacterToken(e, t);
	}
	_emitCodePoint(e) {
		let n = he(e) ? d.WHITESPACE_CHARACTER : e === t.NULL ? d.NULL_CHARACTER : d.CHARACTER;
		this._appendCharToCurrentCharacterToken(n, e < 65536 ? String.fromCharCode(e) : String.fromCodePoint(e));
	}
	_emitChars(e) {
		this._appendCharToCurrentCharacterToken(d.CHARACTER, e);
	}
	_startCharacterReference() {
		this.returnState = this.state, this.state = N.CHARACTER_REFERENCE, this.entityStartPos = this.preprocessor.pos, this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? D.Attribute : D.Legacy);
	}
	_isCharacterReferenceInAttribute() {
		return this.returnState === N.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === N.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === N.ATTRIBUTE_VALUE_UNQUOTED;
	}
	_flushCodePointConsumedAsCharacterReference(e) {
		this._isCharacterReferenceInAttribute() ? this.currentAttr.value += String.fromCodePoint(e) : this._emitCodePoint(e);
	}
	_callState(e) {
		switch (this.state) {
			case N.DATA:
				this._stateData(e);
				break;
			case N.RCDATA:
				this._stateRcdata(e);
				break;
			case N.RAWTEXT:
				this._stateRawtext(e);
				break;
			case N.SCRIPT_DATA:
				this._stateScriptData(e);
				break;
			case N.PLAINTEXT:
				this._statePlaintext(e);
				break;
			case N.TAG_OPEN:
				this._stateTagOpen(e);
				break;
			case N.END_TAG_OPEN:
				this._stateEndTagOpen(e);
				break;
			case N.TAG_NAME:
				this._stateTagName(e);
				break;
			case N.RCDATA_LESS_THAN_SIGN:
				this._stateRcdataLessThanSign(e);
				break;
			case N.RCDATA_END_TAG_OPEN:
				this._stateRcdataEndTagOpen(e);
				break;
			case N.RCDATA_END_TAG_NAME:
				this._stateRcdataEndTagName(e);
				break;
			case N.RAWTEXT_LESS_THAN_SIGN:
				this._stateRawtextLessThanSign(e);
				break;
			case N.RAWTEXT_END_TAG_OPEN:
				this._stateRawtextEndTagOpen(e);
				break;
			case N.RAWTEXT_END_TAG_NAME:
				this._stateRawtextEndTagName(e);
				break;
			case N.SCRIPT_DATA_LESS_THAN_SIGN:
				this._stateScriptDataLessThanSign(e);
				break;
			case N.SCRIPT_DATA_END_TAG_OPEN:
				this._stateScriptDataEndTagOpen(e);
				break;
			case N.SCRIPT_DATA_END_TAG_NAME:
				this._stateScriptDataEndTagName(e);
				break;
			case N.SCRIPT_DATA_ESCAPE_START:
				this._stateScriptDataEscapeStart(e);
				break;
			case N.SCRIPT_DATA_ESCAPE_START_DASH:
				this._stateScriptDataEscapeStartDash(e);
				break;
			case N.SCRIPT_DATA_ESCAPED:
				this._stateScriptDataEscaped(e);
				break;
			case N.SCRIPT_DATA_ESCAPED_DASH:
				this._stateScriptDataEscapedDash(e);
				break;
			case N.SCRIPT_DATA_ESCAPED_DASH_DASH:
				this._stateScriptDataEscapedDashDash(e);
				break;
			case N.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataEscapedLessThanSign(e);
				break;
			case N.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
				this._stateScriptDataEscapedEndTagOpen(e);
				break;
			case N.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
				this._stateScriptDataEscapedEndTagName(e);
				break;
			case N.SCRIPT_DATA_DOUBLE_ESCAPE_START:
				this._stateScriptDataDoubleEscapeStart(e);
				break;
			case N.SCRIPT_DATA_DOUBLE_ESCAPED:
				this._stateScriptDataDoubleEscaped(e);
				break;
			case N.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:
				this._stateScriptDataDoubleEscapedDash(e);
				break;
			case N.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:
				this._stateScriptDataDoubleEscapedDashDash(e);
				break;
			case N.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataDoubleEscapedLessThanSign(e);
				break;
			case N.SCRIPT_DATA_DOUBLE_ESCAPE_END:
				this._stateScriptDataDoubleEscapeEnd(e);
				break;
			case N.BEFORE_ATTRIBUTE_NAME:
				this._stateBeforeAttributeName(e);
				break;
			case N.ATTRIBUTE_NAME:
				this._stateAttributeName(e);
				break;
			case N.AFTER_ATTRIBUTE_NAME:
				this._stateAfterAttributeName(e);
				break;
			case N.BEFORE_ATTRIBUTE_VALUE:
				this._stateBeforeAttributeValue(e);
				break;
			case N.ATTRIBUTE_VALUE_DOUBLE_QUOTED:
				this._stateAttributeValueDoubleQuoted(e);
				break;
			case N.ATTRIBUTE_VALUE_SINGLE_QUOTED:
				this._stateAttributeValueSingleQuoted(e);
				break;
			case N.ATTRIBUTE_VALUE_UNQUOTED:
				this._stateAttributeValueUnquoted(e);
				break;
			case N.AFTER_ATTRIBUTE_VALUE_QUOTED:
				this._stateAfterAttributeValueQuoted(e);
				break;
			case N.SELF_CLOSING_START_TAG:
				this._stateSelfClosingStartTag(e);
				break;
			case N.BOGUS_COMMENT:
				this._stateBogusComment(e);
				break;
			case N.MARKUP_DECLARATION_OPEN:
				this._stateMarkupDeclarationOpen(e);
				break;
			case N.COMMENT_START:
				this._stateCommentStart(e);
				break;
			case N.COMMENT_START_DASH:
				this._stateCommentStartDash(e);
				break;
			case N.COMMENT:
				this._stateComment(e);
				break;
			case N.COMMENT_LESS_THAN_SIGN:
				this._stateCommentLessThanSign(e);
				break;
			case N.COMMENT_LESS_THAN_SIGN_BANG:
				this._stateCommentLessThanSignBang(e);
				break;
			case N.COMMENT_LESS_THAN_SIGN_BANG_DASH:
				this._stateCommentLessThanSignBangDash(e);
				break;
			case N.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:
				this._stateCommentLessThanSignBangDashDash(e);
				break;
			case N.COMMENT_END_DASH:
				this._stateCommentEndDash(e);
				break;
			case N.COMMENT_END:
				this._stateCommentEnd(e);
				break;
			case N.COMMENT_END_BANG:
				this._stateCommentEndBang(e);
				break;
			case N.DOCTYPE:
				this._stateDoctype(e);
				break;
			case N.BEFORE_DOCTYPE_NAME:
				this._stateBeforeDoctypeName(e);
				break;
			case N.DOCTYPE_NAME:
				this._stateDoctypeName(e);
				break;
			case N.AFTER_DOCTYPE_NAME:
				this._stateAfterDoctypeName(e);
				break;
			case N.AFTER_DOCTYPE_PUBLIC_KEYWORD:
				this._stateAfterDoctypePublicKeyword(e);
				break;
			case N.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateBeforeDoctypePublicIdentifier(e);
				break;
			case N.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypePublicIdentifierDoubleQuoted(e);
				break;
			case N.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypePublicIdentifierSingleQuoted(e);
				break;
			case N.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateAfterDoctypePublicIdentifier(e);
				break;
			case N.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:
				this._stateBetweenDoctypePublicAndSystemIdentifiers(e);
				break;
			case N.AFTER_DOCTYPE_SYSTEM_KEYWORD:
				this._stateAfterDoctypeSystemKeyword(e);
				break;
			case N.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateBeforeDoctypeSystemIdentifier(e);
				break;
			case N.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypeSystemIdentifierDoubleQuoted(e);
				break;
			case N.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypeSystemIdentifierSingleQuoted(e);
				break;
			case N.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateAfterDoctypeSystemIdentifier(e);
				break;
			case N.BOGUS_DOCTYPE:
				this._stateBogusDoctype(e);
				break;
			case N.CDATA_SECTION:
				this._stateCdataSection(e);
				break;
			case N.CDATA_SECTION_BRACKET:
				this._stateCdataSectionBracket(e);
				break;
			case N.CDATA_SECTION_END:
				this._stateCdataSectionEnd(e);
				break;
			case N.CHARACTER_REFERENCE:
				this._stateCharacterReference();
				break;
			case N.AMBIGUOUS_AMPERSAND:
				this._stateAmbiguousAmpersand(e);
				break;
			default: throw Error("Unknown state");
		}
	}
	_stateData(e) {
		switch (e) {
			case t.LESS_THAN_SIGN:
				this.state = N.TAG_OPEN;
				break;
			case t.AMPERSAND:
				this._startCharacterReference();
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitCodePoint(e);
				break;
			case t.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRcdata(e) {
		switch (e) {
			case t.AMPERSAND:
				this._startCharacterReference();
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.RCDATA_LESS_THAN_SIGN;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitChars("�");
				break;
			case t.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRawtext(e) {
		switch (e) {
			case t.LESS_THAN_SIGN:
				this.state = N.RAWTEXT_LESS_THAN_SIGN;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitChars("�");
				break;
			case t.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptData(e) {
		switch (e) {
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_LESS_THAN_SIGN;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitChars("�");
				break;
			case t.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_statePlaintext(e) {
		switch (e) {
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitChars("�");
				break;
			case t.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateTagOpen(e) {
		if (fe(e)) this._createStartTagToken(), this.state = N.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case t.EXCLAMATION_MARK:
				this.state = N.MARKUP_DECLARATION_OPEN;
				break;
			case t.SOLIDUS:
				this.state = N.END_TAG_OPEN;
				break;
			case t.QUESTION_MARK:
				this._err(c.unexpectedQuestionMarkInsteadOfTagName), this._createCommentToken(1), this.state = N.BOGUS_COMMENT, this._stateBogusComment(e);
				break;
			case t.EOF:
				this._err(c.eofBeforeTagName), this._emitChars("<"), this._emitEOFToken();
				break;
			default: this._err(c.invalidFirstCharacterOfTagName), this._emitChars("<"), this.state = N.DATA, this._stateData(e);
		}
	}
	_stateEndTagOpen(e) {
		if (fe(e)) this._createEndTagToken(), this.state = N.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case t.GREATER_THAN_SIGN:
				this._err(c.missingEndTagName), this.state = N.DATA;
				break;
			case t.EOF:
				this._err(c.eofBeforeTagName), this._emitChars("</"), this._emitEOFToken();
				break;
			default: this._err(c.invalidFirstCharacterOfTagName), this._createCommentToken(2), this.state = N.BOGUS_COMMENT, this._stateBogusComment(e);
		}
	}
	_stateTagName(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this.state = N.BEFORE_ATTRIBUTE_NAME;
				break;
			case t.SOLIDUS:
				this.state = N.SELF_CLOSING_START_TAG;
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentTagToken();
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.tagName += "�";
				break;
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: n.tagName += String.fromCodePoint(ue(e) ? me(e) : e);
		}
	}
	_stateRcdataLessThanSign(e) {
		e === t.SOLIDUS ? this.state = N.RCDATA_END_TAG_OPEN : (this._emitChars("<"), this.state = N.RCDATA, this._stateRcdata(e));
	}
	_stateRcdataEndTagOpen(e) {
		fe(e) ? (this.state = N.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(e)) : (this._emitChars("</"), this.state = N.RCDATA, this._stateRcdata(e));
	}
	handleSpecialEndTag(e) {
		if (!this.preprocessor.startsWith(this.lastStartTagName, !1)) return !this._ensureHibernation();
		this._createEndTagToken();
		let n = this.currentToken;
		switch (n.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: return this._advanceBy(this.lastStartTagName.length), this.state = N.BEFORE_ATTRIBUTE_NAME, !1;
			case t.SOLIDUS: return this._advanceBy(this.lastStartTagName.length), this.state = N.SELF_CLOSING_START_TAG, !1;
			case t.GREATER_THAN_SIGN: return this._advanceBy(this.lastStartTagName.length), this.emitCurrentTagToken(), this.state = N.DATA, !1;
			default: return !this._ensureHibernation();
		}
	}
	_stateRcdataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = N.RCDATA, this._stateRcdata(e));
	}
	_stateRawtextLessThanSign(e) {
		e === t.SOLIDUS ? this.state = N.RAWTEXT_END_TAG_OPEN : (this._emitChars("<"), this.state = N.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagOpen(e) {
		fe(e) ? (this.state = N.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(e)) : (this._emitChars("</"), this.state = N.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = N.RAWTEXT, this._stateRawtext(e));
	}
	_stateScriptDataLessThanSign(e) {
		switch (e) {
			case t.SOLIDUS:
				this.state = N.SCRIPT_DATA_END_TAG_OPEN;
				break;
			case t.EXCLAMATION_MARK:
				this.state = N.SCRIPT_DATA_ESCAPE_START, this._emitChars("<!");
				break;
			default: this._emitChars("<"), this.state = N.SCRIPT_DATA, this._stateScriptData(e);
		}
	}
	_stateScriptDataEndTagOpen(e) {
		fe(e) ? (this.state = N.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(e)) : (this._emitChars("</"), this.state = N.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = N.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStart(e) {
		e === t.HYPHEN_MINUS ? (this.state = N.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = N.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStartDash(e) {
		e === t.HYPHEN_MINUS ? (this.state = N.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = N.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscaped(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.SCRIPT_DATA_ESCAPED_DASH, this._emitChars("-");
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitChars("�");
				break;
			case t.EOF:
				this._err(c.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDash(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.state = N.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case t.EOF:
				this._err(c.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = N.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDashDash(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.SCRIPT_DATA, this._emitChars(">");
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.state = N.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case t.EOF:
				this._err(c.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = N.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedLessThanSign(e) {
		e === t.SOLIDUS ? this.state = N.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : fe(e) ? (this._emitChars("<"), this.state = N.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(e)) : (this._emitChars("<"), this.state = N.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagOpen(e) {
		fe(e) ? (this.state = N.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(e)) : (this._emitChars("</"), this.state = N.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = N.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscapeStart(e) {
		if (this.preprocessor.startsWith(n.SCRIPT, !1) && ge(this.preprocessor.peek(n.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < n.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED;
		} else this._ensureHibernation() || (this.state = N.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscaped(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED_DASH, this._emitChars("-");
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._emitChars("�");
				break;
			case t.EOF:
				this._err(c.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDash(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case t.EOF:
				this._err(c.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDashDash(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case t.LESS_THAN_SIGN:
				this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.SCRIPT_DATA, this._emitChars(">");
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case t.EOF:
				this._err(c.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedLessThanSign(e) {
		e === t.SOLIDUS ? (this.state = N.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateScriptDataDoubleEscapeEnd(e) {
		if (this.preprocessor.startsWith(n.SCRIPT, !1) && ge(this.preprocessor.peek(n.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < n.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = N.SCRIPT_DATA_ESCAPED;
		} else this._ensureHibernation() || (this.state = N.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateBeforeAttributeName(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.SOLIDUS:
			case t.GREATER_THAN_SIGN:
			case t.EOF:
				this.state = N.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case t.EQUALS_SIGN:
				this._err(c.unexpectedEqualsSignBeforeAttributeName), this._createAttr("="), this.state = N.ATTRIBUTE_NAME;
				break;
			default: this._createAttr(""), this.state = N.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateAttributeName(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
			case t.SOLIDUS:
			case t.GREATER_THAN_SIGN:
			case t.EOF:
				this._leaveAttrName(), this.state = N.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case t.EQUALS_SIGN:
				this._leaveAttrName(), this.state = N.BEFORE_ATTRIBUTE_VALUE;
				break;
			case t.QUOTATION_MARK:
			case t.APOSTROPHE:
			case t.LESS_THAN_SIGN:
				this._err(c.unexpectedCharacterInAttributeName), this.currentAttr.name += String.fromCodePoint(e);
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.currentAttr.name += "�";
				break;
			default: this.currentAttr.name += String.fromCodePoint(ue(e) ? me(e) : e);
		}
	}
	_stateAfterAttributeName(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.SOLIDUS:
				this.state = N.SELF_CLOSING_START_TAG;
				break;
			case t.EQUALS_SIGN:
				this.state = N.BEFORE_ATTRIBUTE_VALUE;
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentTagToken();
				break;
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: this._createAttr(""), this.state = N.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateBeforeAttributeValue(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.QUOTATION_MARK:
				this.state = N.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				this.state = N.ATTRIBUTE_VALUE_SINGLE_QUOTED;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.missingAttributeValue), this.state = N.DATA, this.emitCurrentTagToken();
				break;
			default: this.state = N.ATTRIBUTE_VALUE_UNQUOTED, this._stateAttributeValueUnquoted(e);
		}
	}
	_stateAttributeValueDoubleQuoted(e) {
		switch (e) {
			case t.QUOTATION_MARK:
				this.state = N.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case t.AMPERSAND:
				this._startCharacterReference();
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAttributeValueSingleQuoted(e) {
		switch (e) {
			case t.APOSTROPHE:
				this.state = N.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case t.AMPERSAND:
				this._startCharacterReference();
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAttributeValueUnquoted(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this._leaveAttrValue(), this.state = N.BEFORE_ATTRIBUTE_NAME;
				break;
			case t.AMPERSAND:
				this._startCharacterReference();
				break;
			case t.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = N.DATA, this.emitCurrentTagToken();
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case t.QUOTATION_MARK:
			case t.APOSTROPHE:
			case t.LESS_THAN_SIGN:
			case t.EQUALS_SIGN:
			case t.GRAVE_ACCENT:
				this._err(c.unexpectedCharacterInUnquotedAttributeValue), this.currentAttr.value += String.fromCodePoint(e);
				break;
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAfterAttributeValueQuoted(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this._leaveAttrValue(), this.state = N.BEFORE_ATTRIBUTE_NAME;
				break;
			case t.SOLIDUS:
				this._leaveAttrValue(), this.state = N.SELF_CLOSING_START_TAG;
				break;
			case t.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = N.DATA, this.emitCurrentTagToken();
				break;
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: this._err(c.missingWhitespaceBetweenAttributes), this.state = N.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateSelfClosingStartTag(e) {
		switch (e) {
			case t.GREATER_THAN_SIGN: {
				let e = this.currentToken;
				e.selfClosing = !0, this.state = N.DATA, this.emitCurrentTagToken();
				break;
			}
			case t.EOF:
				this._err(c.eofInTag), this._emitEOFToken();
				break;
			default: this._err(c.unexpectedSolidusInTag), this.state = N.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateBogusComment(e) {
		let n = this.currentToken;
		switch (e) {
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentComment(n);
				break;
			case t.EOF:
				this.emitCurrentComment(n), this._emitEOFToken();
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.data += "�";
				break;
			default: n.data += String.fromCodePoint(e);
		}
	}
	_stateMarkupDeclarationOpen(e) {
		this._consumeSequenceIfMatch(n.DASH_DASH, !0) ? (this._createCommentToken(n.DASH_DASH.length + 1), this.state = N.COMMENT_START) : this._consumeSequenceIfMatch(n.DOCTYPE, !1) ? (this.currentLocation = this.getCurrentLocation(n.DOCTYPE.length + 1), this.state = N.DOCTYPE) : this._consumeSequenceIfMatch(n.CDATA_START, !0) ? this.inForeignNode ? this.state = N.CDATA_SECTION : (this._err(c.cdataInHtmlContent), this._createCommentToken(n.CDATA_START.length + 1), this.currentToken.data = "[CDATA[", this.state = N.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(c.incorrectlyOpenedComment), this._createCommentToken(2), this.state = N.BOGUS_COMMENT, this._stateBogusComment(e));
	}
	_stateCommentStart(e) {
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.COMMENT_START_DASH;
				break;
			case t.GREATER_THAN_SIGN: {
				this._err(c.abruptClosingOfEmptyComment), this.state = N.DATA;
				let e = this.currentToken;
				this.emitCurrentComment(e);
				break;
			}
			default: this.state = N.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentStartDash(e) {
		let n = this.currentToken;
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.COMMENT_END;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.abruptClosingOfEmptyComment), this.state = N.DATA, this.emitCurrentComment(n);
				break;
			case t.EOF:
				this._err(c.eofInComment), this.emitCurrentComment(n), this._emitEOFToken();
				break;
			default: n.data += "-", this.state = N.COMMENT, this._stateComment(e);
		}
	}
	_stateComment(e) {
		let n = this.currentToken;
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.COMMENT_END_DASH;
				break;
			case t.LESS_THAN_SIGN:
				n.data += "<", this.state = N.COMMENT_LESS_THAN_SIGN;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.data += "�";
				break;
			case t.EOF:
				this._err(c.eofInComment), this.emitCurrentComment(n), this._emitEOFToken();
				break;
			default: n.data += String.fromCodePoint(e);
		}
	}
	_stateCommentLessThanSign(e) {
		let n = this.currentToken;
		switch (e) {
			case t.EXCLAMATION_MARK:
				n.data += "!", this.state = N.COMMENT_LESS_THAN_SIGN_BANG;
				break;
			case t.LESS_THAN_SIGN:
				n.data += "<";
				break;
			default: this.state = N.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentLessThanSignBang(e) {
		e === t.HYPHEN_MINUS ? this.state = N.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = N.COMMENT, this._stateComment(e));
	}
	_stateCommentLessThanSignBangDash(e) {
		e === t.HYPHEN_MINUS ? this.state = N.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = N.COMMENT_END_DASH, this._stateCommentEndDash(e));
	}
	_stateCommentLessThanSignBangDashDash(e) {
		e !== t.GREATER_THAN_SIGN && e !== t.EOF && this._err(c.nestedComment), this.state = N.COMMENT_END, this._stateCommentEnd(e);
	}
	_stateCommentEndDash(e) {
		let n = this.currentToken;
		switch (e) {
			case t.HYPHEN_MINUS:
				this.state = N.COMMENT_END;
				break;
			case t.EOF:
				this._err(c.eofInComment), this.emitCurrentComment(n), this._emitEOFToken();
				break;
			default: n.data += "-", this.state = N.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEnd(e) {
		let n = this.currentToken;
		switch (e) {
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentComment(n);
				break;
			case t.EXCLAMATION_MARK:
				this.state = N.COMMENT_END_BANG;
				break;
			case t.HYPHEN_MINUS:
				n.data += "-";
				break;
			case t.EOF:
				this._err(c.eofInComment), this.emitCurrentComment(n), this._emitEOFToken();
				break;
			default: n.data += "--", this.state = N.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEndBang(e) {
		let n = this.currentToken;
		switch (e) {
			case t.HYPHEN_MINUS:
				n.data += "--!", this.state = N.COMMENT_END_DASH;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.incorrectlyClosedComment), this.state = N.DATA, this.emitCurrentComment(n);
				break;
			case t.EOF:
				this._err(c.eofInComment), this.emitCurrentComment(n), this._emitEOFToken();
				break;
			default: n.data += "--!", this.state = N.COMMENT, this._stateComment(e);
		}
	}
	_stateDoctype(e) {
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this.state = N.BEFORE_DOCTYPE_NAME;
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
				break;
			case t.EOF: {
				this._err(c.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._err(c.missingWhitespaceBeforeDoctypeName), this.state = N.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
		}
	}
	_stateBeforeDoctypeName(e) {
		if (ue(e)) this._createDoctypeToken(String.fromCharCode(me(e))), this.state = N.DOCTYPE_NAME;
		else switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), this._createDoctypeToken("�"), this.state = N.DOCTYPE_NAME;
				break;
			case t.GREATER_THAN_SIGN: {
				this._err(c.missingDoctypeName), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this.state = N.DATA;
				break;
			}
			case t.EOF: {
				this._err(c.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._createDoctypeToken(String.fromCodePoint(e)), this.state = N.DOCTYPE_NAME;
		}
	}
	_stateDoctypeName(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this.state = N.AFTER_DOCTYPE_NAME;
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentDoctype(n);
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.name += "�";
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: n.name += String.fromCodePoint(ue(e) ? me(e) : e);
		}
	}
	_stateAfterDoctypeName(e) {
		let r = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentDoctype(r);
				break;
			case t.EOF:
				this._err(c.eofInDoctype), r.forceQuirks = !0, this.emitCurrentDoctype(r), this._emitEOFToken();
				break;
			default: this._consumeSequenceIfMatch(n.PUBLIC, !1) ? this.state = N.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch(n.SYSTEM, !1) ? this.state = N.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(c.invalidCharacterSequenceAfterDoctypeName), r.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e));
		}
	}
	_stateAfterDoctypePublicKeyword(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this.state = N.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case t.QUOTATION_MARK:
				this._err(c.missingWhitespaceAfterDoctypePublicKeyword), n.publicId = "", this.state = N.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				this._err(c.missingWhitespaceAfterDoctypePublicKeyword), n.publicId = "", this.state = N.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.missingDoctypePublicIdentifier), n.forceQuirks = !0, this.state = N.DATA, this.emitCurrentDoctype(n);
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.missingQuoteBeforeDoctypePublicIdentifier), n.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypePublicIdentifier(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.QUOTATION_MARK:
				n.publicId = "", this.state = N.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				n.publicId = "", this.state = N.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.missingDoctypePublicIdentifier), n.forceQuirks = !0, this.state = N.DATA, this.emitCurrentDoctype(n);
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.missingQuoteBeforeDoctypePublicIdentifier), n.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypePublicIdentifierDoubleQuoted(e) {
		let n = this.currentToken;
		switch (e) {
			case t.QUOTATION_MARK:
				this.state = N.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.publicId += "�";
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.abruptDoctypePublicIdentifier), n.forceQuirks = !0, this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: n.publicId += String.fromCodePoint(e);
		}
	}
	_stateDoctypePublicIdentifierSingleQuoted(e) {
		let n = this.currentToken;
		switch (e) {
			case t.APOSTROPHE:
				this.state = N.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.publicId += "�";
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.abruptDoctypePublicIdentifier), n.forceQuirks = !0, this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: n.publicId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypePublicIdentifier(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this.state = N.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
				break;
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA, this.emitCurrentDoctype(n);
				break;
			case t.QUOTATION_MARK:
				this._err(c.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				this._err(c.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.missingQuoteBeforeDoctypeSystemIdentifier), n.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBetweenDoctypePublicAndSystemIdentifiers(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.QUOTATION_MARK:
				n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.missingQuoteBeforeDoctypeSystemIdentifier), n.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateAfterDoctypeSystemKeyword(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED:
				this.state = N.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case t.QUOTATION_MARK:
				this._err(c.missingWhitespaceAfterDoctypeSystemKeyword), n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				this._err(c.missingWhitespaceAfterDoctypeSystemKeyword), n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.missingDoctypeSystemIdentifier), n.forceQuirks = !0, this.state = N.DATA, this.emitCurrentDoctype(n);
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.missingQuoteBeforeDoctypeSystemIdentifier), n.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypeSystemIdentifier(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.QUOTATION_MARK:
				n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case t.APOSTROPHE:
				n.systemId = "", this.state = N.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.missingDoctypeSystemIdentifier), n.forceQuirks = !0, this.state = N.DATA, this.emitCurrentDoctype(n);
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.missingQuoteBeforeDoctypeSystemIdentifier), n.forceQuirks = !0, this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypeSystemIdentifierDoubleQuoted(e) {
		let n = this.currentToken;
		switch (e) {
			case t.QUOTATION_MARK:
				this.state = N.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.systemId += "�";
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.abruptDoctypeSystemIdentifier), n.forceQuirks = !0, this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: n.systemId += String.fromCodePoint(e);
		}
	}
	_stateDoctypeSystemIdentifierSingleQuoted(e) {
		let n = this.currentToken;
		switch (e) {
			case t.APOSTROPHE:
				this.state = N.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter), n.systemId += "�";
				break;
			case t.GREATER_THAN_SIGN:
				this._err(c.abruptDoctypeSystemIdentifier), n.forceQuirks = !0, this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: n.systemId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypeSystemIdentifier(e) {
		let n = this.currentToken;
		switch (e) {
			case t.SPACE:
			case t.LINE_FEED:
			case t.TABULATION:
			case t.FORM_FEED: break;
			case t.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.EOF:
				this._err(c.eofInDoctype), n.forceQuirks = !0, this.emitCurrentDoctype(n), this._emitEOFToken();
				break;
			default: this._err(c.unexpectedCharacterAfterDoctypeSystemIdentifier), this.state = N.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBogusDoctype(e) {
		let n = this.currentToken;
		switch (e) {
			case t.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(n), this.state = N.DATA;
				break;
			case t.NULL:
				this._err(c.unexpectedNullCharacter);
				break;
			case t.EOF: this.emitCurrentDoctype(n), this._emitEOFToken();
		}
	}
	_stateCdataSection(e) {
		switch (e) {
			case t.RIGHT_SQUARE_BRACKET:
				this.state = N.CDATA_SECTION_BRACKET;
				break;
			case t.EOF:
				this._err(c.eofInCdata), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateCdataSectionBracket(e) {
		e === t.RIGHT_SQUARE_BRACKET ? this.state = N.CDATA_SECTION_END : (this._emitChars("]"), this.state = N.CDATA_SECTION, this._stateCdataSection(e));
	}
	_stateCdataSectionEnd(e) {
		switch (e) {
			case t.GREATER_THAN_SIGN:
				this.state = N.DATA;
				break;
			case t.RIGHT_SQUARE_BRACKET:
				this._emitChars("]");
				break;
			default: this._emitChars("]]"), this.state = N.CDATA_SECTION, this._stateCdataSection(e);
		}
	}
	_stateCharacterReference() {
		let e = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
		if (e < 0) {
			if (this.preprocessor.lastChunkWritten) e = this.entityDecoder.end();
			else {
				this.active = !1, this.preprocessor.pos = this.preprocessor.html.length - 1, this.consumedAfterSnapshot = 0, this.preprocessor.endOfChunkHit = !0;
				return;
			}
		}
		e === 0 ? (this.preprocessor.pos = this.entityStartPos, this._flushCodePointConsumedAsCharacterReference(t.AMPERSAND), this.state = !this._isCharacterReferenceInAttribute() && pe(this.preprocessor.peek(1)) ? N.AMBIGUOUS_AMPERSAND : this.returnState) : this.state = this.returnState;
	}
	_stateAmbiguousAmpersand(e) {
		pe(e) ? this._flushCodePointConsumedAsCharacterReference(e) : (e === t.SEMICOLON && this._err(c.unknownNamedCharacterReference), this.state = this.returnState, this._callState(e));
	}
}, ye = /* @__PURE__ */ new Set([
	j.DD,
	j.DT,
	j.LI,
	j.OPTGROUP,
	j.OPTION,
	j.P,
	j.RB,
	j.RP,
	j.RT,
	j.RTC
]), be = /* @__PURE__ */ new Set([
	...ye,
	j.CAPTION,
	j.COLGROUP,
	j.TBODY,
	j.TD,
	j.TFOOT,
	j.TH,
	j.THEAD,
	j.TR
]), xe = /* @__PURE__ */ new Set([
	j.APPLET,
	j.CAPTION,
	j.HTML,
	j.MARQUEE,
	j.OBJECT,
	j.TABLE,
	j.TD,
	j.TEMPLATE,
	j.TH
]), Se = /* @__PURE__ */ new Set([
	...xe,
	j.OL,
	j.UL
]), Ce = /* @__PURE__ */ new Set([...xe, j.BUTTON]), we = /* @__PURE__ */ new Set([
	j.ANNOTATION_XML,
	j.MI,
	j.MN,
	j.MO,
	j.MS,
	j.MTEXT
]), Te = /* @__PURE__ */ new Set([
	j.DESC,
	j.FOREIGN_OBJECT,
	j.TITLE
]), Ee = /* @__PURE__ */ new Set([
	j.TR,
	j.TEMPLATE,
	j.HTML
]), De = /* @__PURE__ */ new Set([
	j.TBODY,
	j.TFOOT,
	j.THEAD,
	j.TEMPLATE,
	j.HTML
]), Oe = /* @__PURE__ */ new Set([
	j.TABLE,
	j.TEMPLATE,
	j.HTML
]), ke = /* @__PURE__ */ new Set([j.TD, j.TH]), Ae = class {
	get currentTmplContentOrNode() {
		return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
	}
	constructor(e, t, n) {
		this.treeAdapter = t, this.handler = n, this.items = [], this.tagIDs = [], this.stackTop = -1, this.tmplCount = 0, this.currentTagId = j.UNKNOWN, this.current = e;
	}
	_indexOf(e) {
		return this.items.lastIndexOf(e, this.stackTop);
	}
	_isInTemplate() {
		return this.currentTagId === j.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === O.HTML;
	}
	_updateCurrentElement() {
		this.current = this.items[this.stackTop], this.currentTagId = this.tagIDs[this.stackTop];
	}
	push(e, t) {
		this.stackTop++, this.items[this.stackTop] = e, this.current = e, this.tagIDs[this.stackTop] = t, this.currentTagId = t, this._isInTemplate() && this.tmplCount++, this.handler.onItemPush(e, t, !0);
	}
	pop() {
		let e = this.current;
		this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !0);
	}
	replace(e, t) {
		let n = this._indexOf(e);
		this.items[n] = t, n === this.stackTop && (this.current = t);
	}
	insertAfter(e, t, n) {
		let r = this._indexOf(e) + 1;
		this.items.splice(r, 0, t), this.tagIDs.splice(r, 0, n), this.stackTop++, r === this.stackTop && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, r === this.stackTop);
	}
	popUntilTagNamePopped(e) {
		let t = this.stackTop + 1;
		do
			t = this.tagIDs.lastIndexOf(e, t - 1);
		while (t > 0 && this.treeAdapter.getNamespaceURI(this.items[t]) !== O.HTML);
		this.shortenToLength(Math.max(t, 0));
	}
	shortenToLength(e) {
		for (; this.stackTop >= e;) {
			let t = this.current;
			this.tmplCount > 0 && this._isInTemplate() && --this.tmplCount, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, this.stackTop < e);
		}
	}
	popUntilElementPopped(e) {
		let t = this._indexOf(e);
		this.shortenToLength(Math.max(t, 0));
	}
	popUntilPopped(e, t) {
		let n = this._indexOfTagNames(e, t);
		this.shortenToLength(Math.max(n, 0));
	}
	popUntilNumberedHeaderPopped() {
		this.popUntilPopped(ce, O.HTML);
	}
	popUntilTableCellPopped() {
		this.popUntilPopped(ke, O.HTML);
	}
	popAllUpToHtmlElement() {
		this.tmplCount = 0, this.shortenToLength(1);
	}
	_indexOfTagNames(e, t) {
		for (let n = this.stackTop; n >= 0; n--) if (e.has(this.tagIDs[n]) && this.treeAdapter.getNamespaceURI(this.items[n]) === t) return n;
		return -1;
	}
	clearBackTo(e, t) {
		let n = this._indexOfTagNames(e, t);
		this.shortenToLength(n + 1);
	}
	clearBackToTableContext() {
		this.clearBackTo(Oe, O.HTML);
	}
	clearBackToTableBodyContext() {
		this.clearBackTo(De, O.HTML);
	}
	clearBackToTableRowContext() {
		this.clearBackTo(Ee, O.HTML);
	}
	remove(e) {
		let t = this._indexOf(e);
		t >= 0 && (t === this.stackTop ? this.pop() : (this.items.splice(t, 1), this.tagIDs.splice(t, 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !1)));
	}
	tryPeekProperlyNestedBodyElement() {
		return this.stackTop >= 1 && this.tagIDs[1] === j.BODY ? this.items[1] : null;
	}
	contains(e) {
		return this._indexOf(e) > -1;
	}
	getCommonAncestor(e) {
		let t = this._indexOf(e) - 1;
		return t >= 0 ? this.items[t] : null;
	}
	isRootHtmlElementCurrent() {
		return this.stackTop === 0 && this.tagIDs[0] === j.HTML;
	}
	hasInDynamicScope(e, t) {
		for (let n = this.stackTop; n >= 0; n--) {
			let r = this.tagIDs[n];
			switch (this.treeAdapter.getNamespaceURI(this.items[n])) {
				case O.HTML:
					if (r === e) return !0;
					if (t.has(r)) return !1;
					break;
				case O.SVG:
					if (Te.has(r)) return !1;
					break;
				case O.MATHML: if (we.has(r)) return !1;
			}
		}
		return !0;
	}
	hasInScope(e) {
		return this.hasInDynamicScope(e, xe);
	}
	hasInListItemScope(e) {
		return this.hasInDynamicScope(e, Se);
	}
	hasInButtonScope(e) {
		return this.hasInDynamicScope(e, Ce);
	}
	hasNumberedHeaderInScope() {
		for (let e = this.stackTop; e >= 0; e--) {
			let t = this.tagIDs[e];
			switch (this.treeAdapter.getNamespaceURI(this.items[e])) {
				case O.HTML:
					if (ce.has(t)) return !0;
					if (xe.has(t)) return !1;
					break;
				case O.SVG:
					if (Te.has(t)) return !1;
					break;
				case O.MATHML: if (we.has(t)) return !1;
			}
		}
		return !0;
	}
	hasInTableScope(e) {
		for (let t = this.stackTop; t >= 0; t--) if (this.treeAdapter.getNamespaceURI(this.items[t]) === O.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case j.TABLE:
			case j.HTML: return !1;
		}
		return !0;
	}
	hasTableBodyContextInTableScope() {
		for (let e = this.stackTop; e >= 0; e--) if (this.treeAdapter.getNamespaceURI(this.items[e]) === O.HTML) switch (this.tagIDs[e]) {
			case j.TBODY:
			case j.THEAD:
			case j.TFOOT: return !0;
			case j.TABLE:
			case j.HTML: return !1;
		}
		return !0;
	}
	hasInSelectScope(e) {
		for (let t = this.stackTop; t >= 0; t--) if (this.treeAdapter.getNamespaceURI(this.items[t]) === O.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case j.OPTION:
			case j.OPTGROUP: break;
			default: return !1;
		}
		return !0;
	}
	generateImpliedEndTags() {
		for (; this.currentTagId !== void 0 && ye.has(this.currentTagId);) this.pop();
	}
	generateImpliedEndTagsThoroughly() {
		for (; this.currentTagId !== void 0 && be.has(this.currentTagId);) this.pop();
	}
	generateImpliedEndTagsWithExclusion(e) {
		for (; this.currentTagId !== void 0 && this.currentTagId !== e && be.has(this.currentTagId);) this.pop();
	}
}, je = 3, Me;
(function(e) {
	e[e.Marker = 0] = "Marker", e[e.Element = 1] = "Element";
})(Me ||= {});
var Ne = { type: Me.Marker }, Pe = class {
	constructor(e) {
		this.treeAdapter = e, this.entries = [], this.bookmark = null;
	}
	_getNoahArkConditionCandidates(e, t) {
		let n = [], r = t.length, i = this.treeAdapter.getTagName(e), a = this.treeAdapter.getNamespaceURI(e);
		for (let e = 0; e < this.entries.length; e++) {
			let t = this.entries[e];
			if (t.type === Me.Marker) break;
			let { element: o } = t;
			if (this.treeAdapter.getTagName(o) === i && this.treeAdapter.getNamespaceURI(o) === a) {
				let t = this.treeAdapter.getAttrList(o);
				t.length === r && n.push({
					idx: e,
					attrs: t
				});
			}
		}
		return n;
	}
	_ensureNoahArkCondition(e) {
		if (this.entries.length < je) return;
		let t = this.treeAdapter.getAttrList(e), n = this._getNoahArkConditionCandidates(e, t);
		if (n.length < je) return;
		let r = new Map(t.map((e) => [e.name, e.value])), i = 0;
		for (let e = 0; e < n.length; e++) {
			let t = n[e];
			t.attrs.every((e) => r.get(e.name) === e.value) && (i += 1, i >= je && this.entries.splice(t.idx, 1));
		}
	}
	insertMarker() {
		this.entries.unshift(Ne);
	}
	pushElement(e, t) {
		this._ensureNoahArkCondition(e), this.entries.unshift({
			type: Me.Element,
			element: e,
			token: t
		});
	}
	insertElementAfterBookmark(e, t) {
		let n = this.entries.indexOf(this.bookmark);
		this.entries.splice(n, 0, {
			type: Me.Element,
			element: e,
			token: t
		});
	}
	removeEntry(e) {
		let t = this.entries.indexOf(e);
		t !== -1 && this.entries.splice(t, 1);
	}
	clearToLastMarker() {
		let e = this.entries.indexOf(Ne);
		e === -1 ? this.entries.length = 0 : this.entries.splice(0, e + 1);
	}
	getElementEntryInScopeWithTagName(e) {
		let t = this.entries.find((t) => t.type === Me.Marker || this.treeAdapter.getTagName(t.element) === e);
		return t && t.type === Me.Element ? t : null;
	}
	getElementEntry(e) {
		return this.entries.find((t) => t.type === Me.Element && t.element === e);
	}
}, Fe = {
	createDocument() {
		return {
			nodeName: "#document",
			mode: k.NO_QUIRKS,
			childNodes: []
		};
	},
	createDocumentFragment() {
		return {
			nodeName: "#document-fragment",
			childNodes: []
		};
	},
	createElement(e, t, n) {
		return {
			nodeName: e,
			tagName: e,
			attrs: n,
			namespaceURI: t,
			childNodes: [],
			parentNode: null
		};
	},
	createCommentNode(e) {
		return {
			nodeName: "#comment",
			data: e,
			parentNode: null
		};
	},
	createTextNode(e) {
		return {
			nodeName: "#text",
			value: e,
			parentNode: null
		};
	},
	appendChild(e, t) {
		e.childNodes.push(t), t.parentNode = e;
	},
	insertBefore(e, t, n) {
		let r = e.childNodes.indexOf(n);
		e.childNodes.splice(r, 0, t), t.parentNode = e;
	},
	setTemplateContent(e, t) {
		e.content = t;
	},
	getTemplateContent(e) {
		return e.content;
	},
	setDocumentType(e, t, n, r) {
		let i = e.childNodes.find((e) => e.nodeName === "#documentType");
		if (i) i.name = t, i.publicId = n, i.systemId = r;
		else {
			let i = {
				nodeName: "#documentType",
				name: t,
				publicId: n,
				systemId: r,
				parentNode: null
			};
			Fe.appendChild(e, i);
		}
	},
	setDocumentMode(e, t) {
		e.mode = t;
	},
	getDocumentMode(e) {
		return e.mode;
	},
	detachNode(e) {
		if (e.parentNode) {
			let t = e.parentNode.childNodes.indexOf(e);
			e.parentNode.childNodes.splice(t, 1), e.parentNode = null;
		}
	},
	insertText(e, t) {
		if (e.childNodes.length > 0) {
			let n = e.childNodes[e.childNodes.length - 1];
			if (Fe.isTextNode(n)) {
				n.value += t;
				return;
			}
		}
		Fe.appendChild(e, Fe.createTextNode(t));
	},
	insertTextBefore(e, t, n) {
		let r = e.childNodes[e.childNodes.indexOf(n) - 1];
		r && Fe.isTextNode(r) ? r.value += t : Fe.insertBefore(e, Fe.createTextNode(t), n);
	},
	adoptAttributes(e, t) {
		let n = new Set(e.attrs.map((e) => e.name));
		for (let r = 0; r < t.length; r++) n.has(t[r].name) || e.attrs.push(t[r]);
	},
	getFirstChild(e) {
		return e.childNodes[0];
	},
	getChildNodes(e) {
		return e.childNodes;
	},
	getParentNode(e) {
		return e.parentNode;
	},
	getAttrList(e) {
		return e.attrs;
	},
	getTagName(e) {
		return e.tagName;
	},
	getNamespaceURI(e) {
		return e.namespaceURI;
	},
	getTextNodeContent(e) {
		return e.value;
	},
	getCommentNodeContent(e) {
		return e.data;
	},
	getDocumentTypeNodeName(e) {
		return e.name;
	},
	getDocumentTypeNodePublicId(e) {
		return e.publicId;
	},
	getDocumentTypeNodeSystemId(e) {
		return e.systemId;
	},
	isTextNode(e) {
		return e.nodeName === "#text";
	},
	isCommentNode(e) {
		return e.nodeName === "#comment";
	},
	isDocumentTypeNode(e) {
		return e.nodeName === "#documentType";
	},
	isElementNode(e) {
		return Object.prototype.hasOwnProperty.call(e, "tagName");
	},
	setNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = t;
	},
	getNodeSourceCodeLocation(e) {
		return e.sourceCodeLocation;
	},
	updateNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = {
			...e.sourceCodeLocation,
			...t
		};
	}
}, Ie = "html", Le = "about:legacy-compat", Re = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd", ze = /* @__PURE__ */ "+//silmaril//dtd html pro v0r11 19970101//,-//as//dtd html 3.0 aswedit + extensions//,-//advasoft ltd//dtd html 3.0 aswedit + extensions//,-//ietf//dtd html 2.0 level 1//,-//ietf//dtd html 2.0 level 2//,-//ietf//dtd html 2.0 strict level 1//,-//ietf//dtd html 2.0 strict level 2//,-//ietf//dtd html 2.0 strict//,-//ietf//dtd html 2.0//,-//ietf//dtd html 2.1e//,-//ietf//dtd html 3.0//,-//ietf//dtd html 3.2 final//,-//ietf//dtd html 3.2//,-//ietf//dtd html 3//,-//ietf//dtd html level 0//,-//ietf//dtd html level 1//,-//ietf//dtd html level 2//,-//ietf//dtd html level 3//,-//ietf//dtd html strict level 0//,-//ietf//dtd html strict level 1//,-//ietf//dtd html strict level 2//,-//ietf//dtd html strict level 3//,-//ietf//dtd html strict//,-//ietf//dtd html//,-//metrius//dtd metrius presentational//,-//microsoft//dtd internet explorer 2.0 html strict//,-//microsoft//dtd internet explorer 2.0 html//,-//microsoft//dtd internet explorer 2.0 tables//,-//microsoft//dtd internet explorer 3.0 html strict//,-//microsoft//dtd internet explorer 3.0 html//,-//microsoft//dtd internet explorer 3.0 tables//,-//netscape comm. corp.//dtd html//,-//netscape comm. corp.//dtd strict html//,-//o'reilly and associates//dtd html 2.0//,-//o'reilly and associates//dtd html extended 1.0//,-//o'reilly and associates//dtd html extended relaxed 1.0//,-//sq//dtd html 2.0 hotmetal + extensions//,-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//,-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//,-//spyglass//dtd html 2.0 extended//,-//sun microsystems corp.//dtd hotjava html//,-//sun microsystems corp.//dtd hotjava strict html//,-//w3c//dtd html 3 1995-03-24//,-//w3c//dtd html 3.2 draft//,-//w3c//dtd html 3.2 final//,-//w3c//dtd html 3.2//,-//w3c//dtd html 3.2s draft//,-//w3c//dtd html 4.0 frameset//,-//w3c//dtd html 4.0 transitional//,-//w3c//dtd html experimental 19960712//,-//w3c//dtd html experimental 970421//,-//w3c//dtd w3 html//,-//w3o//dtd w3 html 3.0//,-//webtechs//dtd mozilla html 2.0//,-//webtechs//dtd mozilla html//".split(","), Be = [
	...ze,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
], Ve = /* @__PURE__ */ new Set([
	"-//w3o//dtd w3 html strict 3.0//en//",
	"-/w3c/dtd html 4.0 transitional/en",
	"html"
]), He = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], Ue = [
	...He,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
];
function We(e, t) {
	return t.some((t) => e.startsWith(t));
}
function Ge(e) {
	return e.name === Ie && e.publicId === null && (e.systemId === null || e.systemId === Le);
}
function Ke(e) {
	if (e.name !== Ie) return k.QUIRKS;
	let { systemId: t } = e;
	if (t && t.toLowerCase() === Re) return k.QUIRKS;
	let { publicId: n } = e;
	if (n !== null) {
		if (n = n.toLowerCase(), Ve.has(n)) return k.QUIRKS;
		let e = t === null ? Be : ze;
		if (We(n, e)) return k.QUIRKS;
		if (e = t === null ? He : Ue, We(n, e)) return k.LIMITED_QUIRKS;
	}
	return k.NO_QUIRKS;
}
//#endregion
//#region node_modules/parse5/dist/common/foreign-content.js
var qe = {
	TEXT_HTML: "text/html",
	APPLICATION_XML: "application/xhtml+xml"
}, Je = "definitionurl", Ye = "definitionURL", Xe = new Map((/* @__PURE__ */ "attributeName.attributeType.baseFrequency.baseProfile.calcMode.clipPathUnits.diffuseConstant.edgeMode.filterUnits.glyphRef.gradientTransform.gradientUnits.kernelMatrix.kernelUnitLength.keyPoints.keySplines.keyTimes.lengthAdjust.limitingConeAngle.markerHeight.markerUnits.markerWidth.maskContentUnits.maskUnits.numOctaves.pathLength.patternContentUnits.patternTransform.patternUnits.pointsAtX.pointsAtY.pointsAtZ.preserveAlpha.preserveAspectRatio.primitiveUnits.refX.refY.repeatCount.repeatDur.requiredExtensions.requiredFeatures.specularConstant.specularExponent.spreadMethod.startOffset.stdDeviation.stitchTiles.surfaceScale.systemLanguage.tableValues.targetX.targetY.textLength.viewBox.viewTarget.xChannelSelector.yChannelSelector.zoomAndPan".split(".")).map((e) => [e.toLowerCase(), e])), Ze = /* @__PURE__ */ new Map([
	["xlink:actuate", {
		prefix: "xlink",
		name: "actuate",
		namespace: O.XLINK
	}],
	["xlink:arcrole", {
		prefix: "xlink",
		name: "arcrole",
		namespace: O.XLINK
	}],
	["xlink:href", {
		prefix: "xlink",
		name: "href",
		namespace: O.XLINK
	}],
	["xlink:role", {
		prefix: "xlink",
		name: "role",
		namespace: O.XLINK
	}],
	["xlink:show", {
		prefix: "xlink",
		name: "show",
		namespace: O.XLINK
	}],
	["xlink:title", {
		prefix: "xlink",
		name: "title",
		namespace: O.XLINK
	}],
	["xlink:type", {
		prefix: "xlink",
		name: "type",
		namespace: O.XLINK
	}],
	["xml:lang", {
		prefix: "xml",
		name: "lang",
		namespace: O.XML
	}],
	["xml:space", {
		prefix: "xml",
		name: "space",
		namespace: O.XML
	}],
	["xmlns", {
		prefix: "",
		name: "xmlns",
		namespace: O.XMLNS
	}],
	["xmlns:xlink", {
		prefix: "xmlns",
		name: "xlink",
		namespace: O.XMLNS
	}]
]), Qe = new Map((/* @__PURE__ */ "altGlyph.altGlyphDef.altGlyphItem.animateColor.animateMotion.animateTransform.clipPath.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feDistantLight.feFlood.feFuncA.feFuncB.feFuncG.feFuncR.feGaussianBlur.feImage.feMerge.feMergeNode.feMorphology.feOffset.fePointLight.feSpecularLighting.feSpotLight.feTile.feTurbulence.foreignObject.glyphRef.linearGradient.radialGradient.textPath".split(".")).map((e) => [e.toLowerCase(), e])), $e = /* @__PURE__ */ new Set([
	j.B,
	j.BIG,
	j.BLOCKQUOTE,
	j.BODY,
	j.BR,
	j.CENTER,
	j.CODE,
	j.DD,
	j.DIV,
	j.DL,
	j.DT,
	j.EM,
	j.EMBED,
	j.H1,
	j.H2,
	j.H3,
	j.H4,
	j.H5,
	j.H6,
	j.HEAD,
	j.HR,
	j.I,
	j.IMG,
	j.LI,
	j.LISTING,
	j.MENU,
	j.META,
	j.NOBR,
	j.OL,
	j.P,
	j.PRE,
	j.RUBY,
	j.S,
	j.SMALL,
	j.SPAN,
	j.STRONG,
	j.STRIKE,
	j.SUB,
	j.SUP,
	j.TABLE,
	j.TT,
	j.U,
	j.UL,
	j.VAR
]);
function et(e) {
	let t = e.tagID;
	return t === j.FONT && e.attrs.some(({ name: e }) => e === ie.COLOR || e === ie.SIZE || e === ie.FACE) || $e.has(t);
}
function tt(e) {
	for (let t = 0; t < e.attrs.length; t++) if (e.attrs[t].name === Je) {
		e.attrs[t].name = Ye;
		break;
	}
}
function nt(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Xe.get(e.attrs[t].name);
		n != null && (e.attrs[t].name = n);
	}
}
function rt(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Ze.get(e.attrs[t].name);
		n && (e.attrs[t].prefix = n.prefix, e.attrs[t].name = n.name, e.attrs[t].namespace = n.namespace);
	}
}
function it(e) {
	let t = Qe.get(e.tagName);
	t != null && (e.tagName = t, e.tagID = oe(e.tagName));
}
function at(e, t) {
	return t === O.MATHML && (e === j.MI || e === j.MO || e === j.MN || e === j.MS || e === j.MTEXT);
}
function ot(e, t, n) {
	if (t === O.MATHML && e === j.ANNOTATION_XML) {
		for (let e = 0; e < n.length; e++) if (n[e].name === ie.ENCODING) {
			let t = n[e].value.toLowerCase();
			return t === qe.TEXT_HTML || t === qe.APPLICATION_XML;
		}
	}
	return t === O.SVG && (e === j.FOREIGN_OBJECT || e === j.DESC || e === j.TITLE);
}
function st(e, t, n, r) {
	return (!r || r === O.HTML) && ot(e, t, n) || (!r || r === O.MATHML) && at(e, t);
}
//#endregion
//#region node_modules/parse5/dist/parser/index.js
var ct = "hidden", lt = 8, ut = 3, F;
(function(e) {
	e[e.INITIAL = 0] = "INITIAL", e[e.BEFORE_HTML = 1] = "BEFORE_HTML", e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD", e[e.IN_HEAD = 3] = "IN_HEAD", e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT", e[e.AFTER_HEAD = 5] = "AFTER_HEAD", e[e.IN_BODY = 6] = "IN_BODY", e[e.TEXT = 7] = "TEXT", e[e.IN_TABLE = 8] = "IN_TABLE", e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT", e[e.IN_CAPTION = 10] = "IN_CAPTION", e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP", e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY", e[e.IN_ROW = 13] = "IN_ROW", e[e.IN_CELL = 14] = "IN_CELL", e[e.IN_SELECT = 15] = "IN_SELECT", e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE", e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE", e[e.AFTER_BODY = 18] = "AFTER_BODY", e[e.IN_FRAMESET = 19] = "IN_FRAMESET", e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET", e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY", e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET";
})(F ||= {});
var dt = {
	startLine: -1,
	startCol: -1,
	startOffset: -1,
	endLine: -1,
	endCol: -1,
	endOffset: -1
}, ft = /* @__PURE__ */ new Set([
	j.TABLE,
	j.TBODY,
	j.TFOOT,
	j.THEAD,
	j.TR
]), pt = {
	scriptingEnabled: !0,
	sourceCodeLocationInfo: !1,
	treeAdapter: Fe,
	onParseError: null
}, mt = class {
	constructor(e, t, n = null, r = null) {
		this.fragmentContext = n, this.scriptHandler = r, this.currentToken = null, this.stopped = !1, this.insertionMode = F.INITIAL, this.originalInsertionMode = F.INITIAL, this.headElement = null, this.formElement = null, this.currentNotInHTML = !1, this.tmplInsertionModeStack = [], this.pendingCharacterTokens = [], this.hasNonWhitespacePendingCharacterToken = !1, this.framesetOk = !0, this.skipNextNewLine = !1, this.fosterParentingEnabled = !1, this.options = {
			...pt,
			...e
		}, this.treeAdapter = this.options.treeAdapter, this.onParseError = this.options.onParseError, this.onParseError && (this.options.sourceCodeLocationInfo = !0), this.document = t ?? this.treeAdapter.createDocument(), this.tokenizer = new ve(this.options, this), this.activeFormattingElements = new Pe(this.treeAdapter), this.fragmentContextID = n ? oe(this.treeAdapter.getTagName(n)) : j.UNKNOWN, this._setContextModes(n ?? this.document, this.fragmentContextID), this.openElements = new Ae(this.document, this.treeAdapter, this);
	}
	static parse(e, t) {
		let n = new this(t);
		return n.tokenizer.write(e, !0), n.document;
	}
	static getFragmentParser(e, t) {
		let n = {
			...pt,
			...t
		};
		e ??= n.treeAdapter.createElement(A.TEMPLATE, O.HTML, []);
		let r = n.treeAdapter.createElement("documentmock", O.HTML, []), i = new this(n, r, e);
		return i.fragmentContextID === j.TEMPLATE && i.tmplInsertionModeStack.unshift(F.IN_TEMPLATE), i._initTokenizerForFragmentParsing(), i._insertFakeRootElement(), i._resetInsertionMode(), i._findFormInFragmentContext(), i;
	}
	getFragment() {
		let e = this.treeAdapter.getFirstChild(this.document), t = this.treeAdapter.createDocumentFragment();
		return this._adoptNodes(e, t), t;
	}
	_err(e, t, n) {
		if (!this.onParseError) return;
		let r = e.location ?? dt, i = {
			code: t,
			startLine: r.startLine,
			startCol: r.startCol,
			startOffset: r.startOffset,
			endLine: n ? r.startLine : r.endLine,
			endCol: n ? r.startCol : r.endCol,
			endOffset: n ? r.startOffset : r.endOffset
		};
		this.onParseError(i);
	}
	onItemPush(e, t, n) {
		var r, i;
		(i = (r = this.treeAdapter).onItemPush) == null || i.call(r, e), n && this.openElements.stackTop > 0 && this._setContextModes(e, t);
	}
	onItemPop(e, t) {
		var n, r;
		if (this.options.sourceCodeLocationInfo && this._setEndLocation(e, this.currentToken), (r = (n = this.treeAdapter).onItemPop) == null || r.call(n, e, this.openElements.current), t) {
			let e, t;
			this.openElements.stackTop === 0 && this.fragmentContext ? (e = this.fragmentContext, t = this.fragmentContextID) : {current: e, currentTagId: t} = this.openElements, this._setContextModes(e, t);
		}
	}
	_setContextModes(e, t) {
		let n = e === this.document || e && this.treeAdapter.getNamespaceURI(e) === O.HTML;
		this.currentNotInHTML = !n, this.tokenizer.inForeignNode = !n && e !== void 0 && t !== void 0 && !this._isIntegrationPoint(t, e);
	}
	_switchToTextParsing(e, t) {
		this._insertElement(e, O.HTML), this.tokenizer.state = t, this.originalInsertionMode = this.insertionMode, this.insertionMode = F.TEXT;
	}
	switchToPlaintextParsing() {
		this.insertionMode = F.TEXT, this.originalInsertionMode = F.IN_BODY, this.tokenizer.state = P.PLAINTEXT;
	}
	_getAdjustedCurrentElement() {
		return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
	}
	_findFormInFragmentContext() {
		let e = this.fragmentContext;
		for (; e;) {
			if (this.treeAdapter.getTagName(e) === A.FORM) {
				this.formElement = e;
				break;
			}
			e = this.treeAdapter.getParentNode(e);
		}
	}
	_initTokenizerForFragmentParsing() {
		if (this.fragmentContext && this.treeAdapter.getNamespaceURI(this.fragmentContext) === O.HTML) switch (this.fragmentContextID) {
			case j.TITLE:
			case j.TEXTAREA:
				this.tokenizer.state = P.RCDATA;
				break;
			case j.STYLE:
			case j.XMP:
			case j.IFRAME:
			case j.NOEMBED:
			case j.NOFRAMES:
			case j.NOSCRIPT:
				this.tokenizer.state = P.RAWTEXT;
				break;
			case j.SCRIPT:
				this.tokenizer.state = P.SCRIPT_DATA;
				break;
			case j.PLAINTEXT: this.tokenizer.state = P.PLAINTEXT;
		}
	}
	_setDocumentType(e) {
		let t = e.name || "", n = e.publicId || "", r = e.systemId || "";
		if (this.treeAdapter.setDocumentType(this.document, t, n, r), e.location) {
			let t = this.treeAdapter.getChildNodes(this.document).find((e) => this.treeAdapter.isDocumentTypeNode(e));
			t && this.treeAdapter.setNodeSourceCodeLocation(t, e.location);
		}
	}
	_attachElementToTree(e, t) {
		if (this.options.sourceCodeLocationInfo) {
			let n = t && {
				...t,
				startTag: t
			};
			this.treeAdapter.setNodeSourceCodeLocation(e, n);
		}
		if (this._shouldFosterParentOnInsertion()) this._fosterParentElement(e);
		else {
			let t = this.openElements.currentTmplContentOrNode;
			this.treeAdapter.appendChild(t ?? this.document, e);
		}
	}
	_appendElement(e, t) {
		let n = this.treeAdapter.createElement(e.tagName, t, e.attrs);
		this._attachElementToTree(n, e.location);
	}
	_insertElement(e, t) {
		let n = this.treeAdapter.createElement(e.tagName, t, e.attrs);
		this._attachElementToTree(n, e.location), this.openElements.push(n, e.tagID);
	}
	_insertFakeElement(e, t) {
		let n = this.treeAdapter.createElement(e, O.HTML, []);
		this._attachElementToTree(n, null), this.openElements.push(n, t);
	}
	_insertTemplate(e) {
		let t = this.treeAdapter.createElement(e.tagName, O.HTML, e.attrs), n = this.treeAdapter.createDocumentFragment();
		this.treeAdapter.setTemplateContent(t, n), this._attachElementToTree(t, e.location), this.openElements.push(t, e.tagID), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, null);
	}
	_insertFakeRootElement() {
		let e = this.treeAdapter.createElement(A.HTML, O.HTML, []);
		this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(e, null), this.treeAdapter.appendChild(this.openElements.current, e), this.openElements.push(e, j.HTML);
	}
	_appendCommentNode(e, t) {
		let n = this.treeAdapter.createCommentNode(e.data);
		this.treeAdapter.appendChild(t, n), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, e.location);
	}
	_insertCharacters(e) {
		let t, n;
		if (this._shouldFosterParentOnInsertion() ? ({parent: t, beforeElement: n} = this._findFosterParentingLocation(), n ? this.treeAdapter.insertTextBefore(t, e.chars, n) : this.treeAdapter.insertText(t, e.chars)) : (t = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(t, e.chars)), !e.location) return;
		let r = this.treeAdapter.getChildNodes(t), i = r[(n ? r.lastIndexOf(n) : r.length) - 1];
		if (this.treeAdapter.getNodeSourceCodeLocation(i)) {
			let { endLine: t, endCol: n, endOffset: r } = e.location;
			this.treeAdapter.updateNodeSourceCodeLocation(i, {
				endLine: t,
				endCol: n,
				endOffset: r
			});
		} else this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(i, e.location);
	}
	_adoptNodes(e, t) {
		for (let n = this.treeAdapter.getFirstChild(e); n; n = this.treeAdapter.getFirstChild(e)) this.treeAdapter.detachNode(n), this.treeAdapter.appendChild(t, n);
	}
	_setEndLocation(e, t) {
		if (this.treeAdapter.getNodeSourceCodeLocation(e) && t.location) {
			let n = t.location, r = this.treeAdapter.getTagName(e), i = t.type === d.END_TAG && r === t.tagName ? {
				endTag: { ...n },
				endLine: n.endLine,
				endCol: n.endCol,
				endOffset: n.endOffset
			} : {
				endLine: n.startLine,
				endCol: n.startCol,
				endOffset: n.startOffset
			};
			this.treeAdapter.updateNodeSourceCodeLocation(e, i);
		}
	}
	shouldProcessStartTagTokenInForeignContent(e) {
		if (!this.currentNotInHTML) return !1;
		let t, n;
		return this.openElements.stackTop === 0 && this.fragmentContext ? (t = this.fragmentContext, n = this.fragmentContextID) : {current: t, currentTagId: n} = this.openElements, e.tagID === j.SVG && this.treeAdapter.getTagName(t) === A.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(t) === O.MATHML ? !1 : this.tokenizer.inForeignNode || (e.tagID === j.MGLYPH || e.tagID === j.MALIGNMARK) && n !== void 0 && !this._isIntegrationPoint(n, t, O.HTML);
	}
	_processToken(e) {
		switch (e.type) {
			case d.CHARACTER:
				this.onCharacter(e);
				break;
			case d.NULL_CHARACTER:
				this.onNullCharacter(e);
				break;
			case d.COMMENT:
				this.onComment(e);
				break;
			case d.DOCTYPE:
				this.onDoctype(e);
				break;
			case d.START_TAG:
				this._processStartTag(e);
				break;
			case d.END_TAG:
				this.onEndTag(e);
				break;
			case d.EOF:
				this.onEof(e);
				break;
			case d.WHITESPACE_CHARACTER: this.onWhitespaceCharacter(e);
		}
	}
	_isIntegrationPoint(e, t, n) {
		return st(e, this.treeAdapter.getNamespaceURI(t), this.treeAdapter.getAttrList(t), n);
	}
	_reconstructActiveFormattingElements() {
		let e = this.activeFormattingElements.entries.length;
		if (e) {
			let t = this.activeFormattingElements.entries.findIndex((e) => e.type === Me.Marker || this.openElements.contains(e.element)), n = t === -1 ? e - 1 : t - 1;
			for (let e = n; e >= 0; e--) {
				let t = this.activeFormattingElements.entries[e];
				this._insertElement(t.token, this.treeAdapter.getNamespaceURI(t.element)), t.element = this.openElements.current;
			}
		}
	}
	_closeTableCell() {
		this.openElements.generateImpliedEndTags(), this.openElements.popUntilTableCellPopped(), this.activeFormattingElements.clearToLastMarker(), this.insertionMode = F.IN_ROW;
	}
	_closePElement() {
		this.openElements.generateImpliedEndTagsWithExclusion(j.P), this.openElements.popUntilTagNamePopped(j.P);
	}
	_resetInsertionMode() {
		for (let e = this.openElements.stackTop; e >= 0; e--) switch (e === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[e]) {
			case j.TR:
				this.insertionMode = F.IN_ROW;
				return;
			case j.TBODY:
			case j.THEAD:
			case j.TFOOT:
				this.insertionMode = F.IN_TABLE_BODY;
				return;
			case j.CAPTION:
				this.insertionMode = F.IN_CAPTION;
				return;
			case j.COLGROUP:
				this.insertionMode = F.IN_COLUMN_GROUP;
				return;
			case j.TABLE:
				this.insertionMode = F.IN_TABLE;
				return;
			case j.BODY:
				this.insertionMode = F.IN_BODY;
				return;
			case j.FRAMESET:
				this.insertionMode = F.IN_FRAMESET;
				return;
			case j.SELECT:
				this._resetInsertionModeForSelect(e);
				return;
			case j.TEMPLATE:
				this.insertionMode = this.tmplInsertionModeStack[0];
				return;
			case j.HTML:
				this.insertionMode = this.headElement ? F.AFTER_HEAD : F.BEFORE_HEAD;
				return;
			case j.TD:
			case j.TH:
				if (e > 0) {
					this.insertionMode = F.IN_CELL;
					return;
				}
				break;
			case j.HEAD: if (e > 0) {
				this.insertionMode = F.IN_HEAD;
				return;
			}
		}
		this.insertionMode = F.IN_BODY;
	}
	_resetInsertionModeForSelect(e) {
		if (e > 0) for (let t = e - 1; t > 0; t--) {
			let e = this.openElements.tagIDs[t];
			if (e === j.TEMPLATE) break;
			if (e === j.TABLE) {
				this.insertionMode = F.IN_SELECT_IN_TABLE;
				return;
			}
		}
		this.insertionMode = F.IN_SELECT;
	}
	_isElementCausesFosterParenting(e) {
		return ft.has(e);
	}
	_shouldFosterParentOnInsertion() {
		return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
	}
	_findFosterParentingLocation() {
		for (let e = this.openElements.stackTop; e >= 0; e--) {
			let t = this.openElements.items[e];
			switch (this.openElements.tagIDs[e]) {
				case j.TEMPLATE:
					if (this.treeAdapter.getNamespaceURI(t) === O.HTML) return {
						parent: this.treeAdapter.getTemplateContent(t),
						beforeElement: null
					};
					break;
				case j.TABLE: {
					let n = this.treeAdapter.getParentNode(t);
					return n ? {
						parent: n,
						beforeElement: t
					} : {
						parent: this.openElements.items[e - 1],
						beforeElement: null
					};
				}
			}
		}
		return {
			parent: this.openElements.items[0],
			beforeElement: null
		};
	}
	_fosterParentElement(e) {
		let t = this._findFosterParentingLocation();
		t.beforeElement ? this.treeAdapter.insertBefore(t.parent, e, t.beforeElement) : this.treeAdapter.appendChild(t.parent, e);
	}
	_isSpecialElement(e, t) {
		return se[this.treeAdapter.getNamespaceURI(e)].has(t);
	}
	onCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) Mr(this, e);
		else switch (this.insertionMode) {
			case F.INITIAL:
				Dt(this, e);
				break;
			case F.BEFORE_HTML:
				At(this, e);
				break;
			case F.BEFORE_HEAD:
				Nt(this, e);
				break;
			case F.IN_HEAD:
				Lt(this, e);
				break;
			case F.IN_HEAD_NO_SCRIPT:
				Bt(this, e);
				break;
			case F.AFTER_HEAD:
				Ut(this, e);
				break;
			case F.IN_BODY:
			case F.IN_CAPTION:
			case F.IN_CELL:
			case F.IN_TEMPLATE:
				Kt(this, e);
				break;
			case F.TEXT:
			case F.IN_SELECT:
			case F.IN_SELECT_IN_TABLE:
				this._insertCharacters(e);
				break;
			case F.IN_TABLE:
			case F.IN_TABLE_BODY:
			case F.IN_ROW:
				Vn(this, e);
				break;
			case F.IN_TABLE_TEXT:
				er(this, e);
				break;
			case F.IN_COLUMN_GROUP:
				sr(this, e);
				break;
			case F.AFTER_BODY:
				Cr(this, e);
				break;
			case F.AFTER_AFTER_BODY: kr(this, e);
		}
	}
	onNullCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) jr(this, e);
		else switch (this.insertionMode) {
			case F.INITIAL:
				Dt(this, e);
				break;
			case F.BEFORE_HTML:
				At(this, e);
				break;
			case F.BEFORE_HEAD:
				Nt(this, e);
				break;
			case F.IN_HEAD:
				Lt(this, e);
				break;
			case F.IN_HEAD_NO_SCRIPT:
				Bt(this, e);
				break;
			case F.AFTER_HEAD:
				Ut(this, e);
				break;
			case F.TEXT:
				this._insertCharacters(e);
				break;
			case F.IN_TABLE:
			case F.IN_TABLE_BODY:
			case F.IN_ROW:
				Vn(this, e);
				break;
			case F.IN_COLUMN_GROUP:
				sr(this, e);
				break;
			case F.AFTER_BODY:
				Cr(this, e);
				break;
			case F.AFTER_AFTER_BODY: kr(this, e);
		}
	}
	onComment(e) {
		if (this.skipNextNewLine = !1, this.currentNotInHTML) St(this, e);
		else switch (this.insertionMode) {
			case F.INITIAL:
			case F.BEFORE_HTML:
			case F.BEFORE_HEAD:
			case F.IN_HEAD:
			case F.IN_HEAD_NO_SCRIPT:
			case F.AFTER_HEAD:
			case F.IN_BODY:
			case F.IN_TABLE:
			case F.IN_CAPTION:
			case F.IN_COLUMN_GROUP:
			case F.IN_TABLE_BODY:
			case F.IN_ROW:
			case F.IN_CELL:
			case F.IN_SELECT:
			case F.IN_SELECT_IN_TABLE:
			case F.IN_TEMPLATE:
			case F.IN_FRAMESET:
			case F.AFTER_FRAMESET:
				St(this, e);
				break;
			case F.IN_TABLE_TEXT:
				tr(this, e);
				break;
			case F.AFTER_BODY:
				Ct(this, e);
				break;
			case F.AFTER_AFTER_BODY:
			case F.AFTER_AFTER_FRAMESET: wt(this, e);
		}
	}
	onDoctype(e) {
		switch (this.skipNextNewLine = !1, this.insertionMode) {
			case F.INITIAL:
				Et(this, e);
				break;
			case F.BEFORE_HEAD:
			case F.IN_HEAD:
			case F.IN_HEAD_NO_SCRIPT:
			case F.AFTER_HEAD:
				this._err(e, c.misplacedDoctype);
				break;
			case F.IN_TABLE_TEXT: tr(this, e);
		}
	}
	onStartTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this._processStartTag(e), e.selfClosing && !e.ackSelfClosing && this._err(e, c.nonVoidHtmlElementStartTagWithTrailingSolidus);
	}
	_processStartTag(e) {
		this.shouldProcessStartTagTokenInForeignContent(e) ? Pr(this, e) : this._startTagOutsideForeignContent(e);
	}
	_startTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case F.INITIAL:
				Dt(this, e);
				break;
			case F.BEFORE_HTML:
				Ot(this, e);
				break;
			case F.BEFORE_HEAD:
				jt(this, e);
				break;
			case F.IN_HEAD:
				Pt(this, e);
				break;
			case F.IN_HEAD_NO_SCRIPT:
				Rt(this, e);
				break;
			case F.AFTER_HEAD:
				Vt(this, e);
				break;
			case F.IN_BODY:
				I(this, e);
				break;
			case F.IN_TABLE:
				Xn(this, e);
				break;
			case F.IN_TABLE_TEXT:
				tr(this, e);
				break;
			case F.IN_CAPTION:
				rr(this, e);
				break;
			case F.IN_COLUMN_GROUP:
				ar(this, e);
				break;
			case F.IN_TABLE_BODY:
				cr(this, e);
				break;
			case F.IN_ROW:
				ur(this, e);
				break;
			case F.IN_CELL:
				fr(this, e);
				break;
			case F.IN_SELECT:
				mr(this, e);
				break;
			case F.IN_SELECT_IN_TABLE:
				gr(this, e);
				break;
			case F.IN_TEMPLATE:
				vr(this, e);
				break;
			case F.AFTER_BODY:
				xr(this, e);
				break;
			case F.IN_FRAMESET:
				wr(this, e);
				break;
			case F.AFTER_FRAMESET:
				Er(this, e);
				break;
			case F.AFTER_AFTER_BODY:
				Or(this, e);
				break;
			case F.AFTER_AFTER_FRAMESET: Ar(this, e);
		}
	}
	onEndTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this.currentNotInHTML ? Fr(this, e) : this._endTagOutsideForeignContent(e);
	}
	_endTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case F.INITIAL:
				Dt(this, e);
				break;
			case F.BEFORE_HTML:
				kt(this, e);
				break;
			case F.BEFORE_HEAD:
				Mt(this, e);
				break;
			case F.IN_HEAD:
				Ft(this, e);
				break;
			case F.IN_HEAD_NO_SCRIPT:
				zt(this, e);
				break;
			case F.AFTER_HEAD:
				Ht(this, e);
				break;
			case F.IN_BODY:
				Ln(this, e);
				break;
			case F.TEXT:
				zn(this, e);
				break;
			case F.IN_TABLE:
				Zn(this, e);
				break;
			case F.IN_TABLE_TEXT:
				tr(this, e);
				break;
			case F.IN_CAPTION:
				ir(this, e);
				break;
			case F.IN_COLUMN_GROUP:
				or(this, e);
				break;
			case F.IN_TABLE_BODY:
				lr(this, e);
				break;
			case F.IN_ROW:
				dr(this, e);
				break;
			case F.IN_CELL:
				pr(this, e);
				break;
			case F.IN_SELECT:
				hr(this, e);
				break;
			case F.IN_SELECT_IN_TABLE:
				_r(this, e);
				break;
			case F.IN_TEMPLATE:
				yr(this, e);
				break;
			case F.AFTER_BODY:
				Sr(this, e);
				break;
			case F.IN_FRAMESET:
				Tr(this, e);
				break;
			case F.AFTER_FRAMESET:
				Dr(this, e);
				break;
			case F.AFTER_AFTER_BODY: kr(this, e);
		}
	}
	onEof(e) {
		switch (this.insertionMode) {
			case F.INITIAL:
				Dt(this, e);
				break;
			case F.BEFORE_HTML:
				At(this, e);
				break;
			case F.BEFORE_HEAD:
				Nt(this, e);
				break;
			case F.IN_HEAD:
				Lt(this, e);
				break;
			case F.IN_HEAD_NO_SCRIPT:
				Bt(this, e);
				break;
			case F.AFTER_HEAD:
				Ut(this, e);
				break;
			case F.IN_BODY:
			case F.IN_TABLE:
			case F.IN_CAPTION:
			case F.IN_COLUMN_GROUP:
			case F.IN_TABLE_BODY:
			case F.IN_ROW:
			case F.IN_CELL:
			case F.IN_SELECT:
			case F.IN_SELECT_IN_TABLE:
				Rn(this, e);
				break;
			case F.TEXT:
				Bn(this, e);
				break;
			case F.IN_TABLE_TEXT:
				tr(this, e);
				break;
			case F.IN_TEMPLATE:
				br(this, e);
				break;
			case F.AFTER_BODY:
			case F.IN_FRAMESET:
			case F.AFTER_FRAMESET:
			case F.AFTER_AFTER_BODY:
			case F.AFTER_AFTER_FRAMESET: Tt(this, e);
		}
	}
	onWhitespaceCharacter(e) {
		if (this.skipNextNewLine && (this.skipNextNewLine = !1, e.chars.charCodeAt(0) === t.LINE_FEED)) {
			if (e.chars.length === 1) return;
			e.chars = e.chars.substr(1);
		}
		if (this.tokenizer.inForeignNode) this._insertCharacters(e);
		else switch (this.insertionMode) {
			case F.IN_HEAD:
			case F.IN_HEAD_NO_SCRIPT:
			case F.AFTER_HEAD:
			case F.TEXT:
			case F.IN_COLUMN_GROUP:
			case F.IN_SELECT:
			case F.IN_SELECT_IN_TABLE:
			case F.IN_FRAMESET:
			case F.AFTER_FRAMESET:
				this._insertCharacters(e);
				break;
			case F.IN_BODY:
			case F.IN_CAPTION:
			case F.IN_CELL:
			case F.IN_TEMPLATE:
			case F.AFTER_BODY:
			case F.AFTER_AFTER_BODY:
			case F.AFTER_AFTER_FRAMESET:
				Gt(this, e);
				break;
			case F.IN_TABLE:
			case F.IN_TABLE_BODY:
			case F.IN_ROW:
				Vn(this, e);
				break;
			case F.IN_TABLE_TEXT: $n(this, e);
		}
	}
};
function ht(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
	return n ? e.openElements.contains(n.element) ? e.openElements.hasInScope(t.tagID) || (n = null) : (e.activeFormattingElements.removeEntry(n), n = null) : In(e, t), n;
}
function gt(e, t) {
	let n = null, r = e.openElements.stackTop;
	for (; r >= 0; r--) {
		let i = e.openElements.items[r];
		if (i === t.element) break;
		e._isSpecialElement(i, e.openElements.tagIDs[r]) && (n = i);
	}
	return n || (e.openElements.shortenToLength(Math.max(r, 0)), e.activeFormattingElements.removeEntry(t)), n;
}
function _t(e, t, n) {
	let r = t, i = e.openElements.getCommonAncestor(t);
	for (let a = 0, o = i; o !== n; a++, o = i) {
		i = e.openElements.getCommonAncestor(o);
		let n = e.activeFormattingElements.getElementEntry(o), s = n && a >= ut;
		!n || s ? (s && e.activeFormattingElements.removeEntry(n), e.openElements.remove(o)) : (o = vt(e, n), r === t && (e.activeFormattingElements.bookmark = n), e.treeAdapter.detachNode(r), e.treeAdapter.appendChild(o, r), r = o);
	}
	return r;
}
function vt(e, t) {
	let n = e.treeAdapter.getNamespaceURI(t.element), r = e.treeAdapter.createElement(t.token.tagName, n, t.token.attrs);
	return e.openElements.replace(t.element, r), t.element = r, r;
}
function yt(e, t, n) {
	let r = oe(e.treeAdapter.getTagName(t));
	if (e._isElementCausesFosterParenting(r)) e._fosterParentElement(n);
	else {
		let i = e.treeAdapter.getNamespaceURI(t);
		r === j.TEMPLATE && i === O.HTML && (t = e.treeAdapter.getTemplateContent(t)), e.treeAdapter.appendChild(t, n);
	}
}
function bt(e, t, n) {
	let r = e.treeAdapter.getNamespaceURI(n.element), { token: i } = n, a = e.treeAdapter.createElement(i.tagName, r, i.attrs);
	e._adoptNodes(t, a), e.treeAdapter.appendChild(t, a), e.activeFormattingElements.insertElementAfterBookmark(a, i), e.activeFormattingElements.removeEntry(n), e.openElements.remove(n.element), e.openElements.insertAfter(t, a, i.tagID);
}
function xt(e, t) {
	for (let n = 0; n < lt; n++) {
		let n = ht(e, t);
		if (!n) break;
		let r = gt(e, n);
		if (!r) break;
		e.activeFormattingElements.bookmark = n;
		let i = _t(e, r, n.element), a = e.openElements.getCommonAncestor(n.element);
		e.treeAdapter.detachNode(i), a && yt(e, a, i), bt(e, r, n);
	}
}
function St(e, t) {
	e._appendCommentNode(t, e.openElements.currentTmplContentOrNode);
}
function Ct(e, t) {
	e._appendCommentNode(t, e.openElements.items[0]);
}
function wt(e, t) {
	e._appendCommentNode(t, e.document);
}
function Tt(e, t) {
	if (e.stopped = !0, t.location) {
		let n = e.fragmentContext ? 0 : 2;
		for (let r = e.openElements.stackTop; r >= n; r--) e._setEndLocation(e.openElements.items[r], t);
		if (!e.fragmentContext && e.openElements.stackTop >= 0) {
			let n = e.openElements.items[0], r = e.treeAdapter.getNodeSourceCodeLocation(n);
			if (r && !r.endTag && (e._setEndLocation(n, t), e.openElements.stackTop >= 1)) {
				let n = e.openElements.items[1], r = e.treeAdapter.getNodeSourceCodeLocation(n);
				r && !r.endTag && e._setEndLocation(n, t);
			}
		}
	}
}
function Et(e, t) {
	e._setDocumentType(t);
	let n = t.forceQuirks ? k.QUIRKS : Ke(t);
	Ge(t) || e._err(t, c.nonConformingDoctype), e.treeAdapter.setDocumentMode(e.document, n), e.insertionMode = F.BEFORE_HTML;
}
function Dt(e, t) {
	e._err(t, c.missingDoctype, !0), e.treeAdapter.setDocumentMode(e.document, k.QUIRKS), e.insertionMode = F.BEFORE_HTML, e._processToken(t);
}
function Ot(e, t) {
	t.tagID === j.HTML ? (e._insertElement(t, O.HTML), e.insertionMode = F.BEFORE_HEAD) : At(e, t);
}
function kt(e, t) {
	let n = t.tagID;
	(n === j.HTML || n === j.HEAD || n === j.BODY || n === j.BR) && At(e, t);
}
function At(e, t) {
	e._insertFakeRootElement(), e.insertionMode = F.BEFORE_HEAD, e._processToken(t);
}
function jt(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.HEAD:
			e._insertElement(t, O.HTML), e.headElement = e.openElements.current, e.insertionMode = F.IN_HEAD;
			break;
		default: Nt(e, t);
	}
}
function Mt(e, t) {
	let n = t.tagID;
	n === j.HEAD || n === j.BODY || n === j.HTML || n === j.BR ? Nt(e, t) : e._err(t, c.endTagWithoutMatchingOpenElement);
}
function Nt(e, t) {
	e._insertFakeElement(A.HEAD, j.HEAD), e.headElement = e.openElements.current, e.insertionMode = F.IN_HEAD, e._processToken(t);
}
function Pt(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.BASE:
		case j.BASEFONT:
		case j.BGSOUND:
		case j.LINK:
		case j.META:
			e._appendElement(t, O.HTML), t.ackSelfClosing = !0;
			break;
		case j.TITLE:
			e._switchToTextParsing(t, P.RCDATA);
			break;
		case j.NOSCRIPT:
			e.options.scriptingEnabled ? e._switchToTextParsing(t, P.RAWTEXT) : (e._insertElement(t, O.HTML), e.insertionMode = F.IN_HEAD_NO_SCRIPT);
			break;
		case j.NOFRAMES:
		case j.STYLE:
			e._switchToTextParsing(t, P.RAWTEXT);
			break;
		case j.SCRIPT:
			e._switchToTextParsing(t, P.SCRIPT_DATA);
			break;
		case j.TEMPLATE:
			e._insertTemplate(t), e.activeFormattingElements.insertMarker(), e.framesetOk = !1, e.insertionMode = F.IN_TEMPLATE, e.tmplInsertionModeStack.unshift(F.IN_TEMPLATE);
			break;
		case j.HEAD:
			e._err(t, c.misplacedStartTagForHeadElement);
			break;
		default: Lt(e, t);
	}
}
function Ft(e, t) {
	switch (t.tagID) {
		case j.HEAD:
			e.openElements.pop(), e.insertionMode = F.AFTER_HEAD;
			break;
		case j.BODY:
		case j.BR:
		case j.HTML:
			Lt(e, t);
			break;
		case j.TEMPLATE:
			It(e, t);
			break;
		default: e._err(t, c.endTagWithoutMatchingOpenElement);
	}
}
function It(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== j.TEMPLATE && e._err(t, c.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(j.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode()) : e._err(t, c.endTagWithoutMatchingOpenElement);
}
function Lt(e, t) {
	e.openElements.pop(), e.insertionMode = F.AFTER_HEAD, e._processToken(t);
}
function Rt(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.BASEFONT:
		case j.BGSOUND:
		case j.HEAD:
		case j.LINK:
		case j.META:
		case j.NOFRAMES:
		case j.STYLE:
			Pt(e, t);
			break;
		case j.NOSCRIPT:
			e._err(t, c.nestedNoscriptInHead);
			break;
		default: Bt(e, t);
	}
}
function zt(e, t) {
	switch (t.tagID) {
		case j.NOSCRIPT:
			e.openElements.pop(), e.insertionMode = F.IN_HEAD;
			break;
		case j.BR:
			Bt(e, t);
			break;
		default: e._err(t, c.endTagWithoutMatchingOpenElement);
	}
}
function Bt(e, t) {
	let n = t.type === d.EOF ? c.openElementsLeftAfterEof : c.disallowedContentInNoscriptInHead;
	e._err(t, n), e.openElements.pop(), e.insertionMode = F.IN_HEAD, e._processToken(t);
}
function Vt(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.BODY:
			e._insertElement(t, O.HTML), e.framesetOk = !1, e.insertionMode = F.IN_BODY;
			break;
		case j.FRAMESET:
			e._insertElement(t, O.HTML), e.insertionMode = F.IN_FRAMESET;
			break;
		case j.BASE:
		case j.BASEFONT:
		case j.BGSOUND:
		case j.LINK:
		case j.META:
		case j.NOFRAMES:
		case j.SCRIPT:
		case j.STYLE:
		case j.TEMPLATE:
		case j.TITLE:
			e._err(t, c.abandonedHeadElementChild), e.openElements.push(e.headElement, j.HEAD), Pt(e, t), e.openElements.remove(e.headElement);
			break;
		case j.HEAD:
			e._err(t, c.misplacedStartTagForHeadElement);
			break;
		default: Ut(e, t);
	}
}
function Ht(e, t) {
	switch (t.tagID) {
		case j.BODY:
		case j.HTML:
		case j.BR:
			Ut(e, t);
			break;
		case j.TEMPLATE:
			It(e, t);
			break;
		default: e._err(t, c.endTagWithoutMatchingOpenElement);
	}
}
function Ut(e, t) {
	e._insertFakeElement(A.BODY, j.BODY), e.insertionMode = F.IN_BODY, Wt(e, t);
}
function Wt(e, t) {
	switch (t.type) {
		case d.CHARACTER:
			Kt(e, t);
			break;
		case d.WHITESPACE_CHARACTER:
			Gt(e, t);
			break;
		case d.COMMENT:
			St(e, t);
			break;
		case d.START_TAG:
			I(e, t);
			break;
		case d.END_TAG:
			Ln(e, t);
			break;
		case d.EOF: Rn(e, t);
	}
}
function Gt(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t);
}
function Kt(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t), e.framesetOk = !1;
}
function qt(e, t) {
	e.openElements.tmplCount === 0 && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs);
}
function Jt(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	n && e.openElements.tmplCount === 0 && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(n, t.attrs));
}
function Yt(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	e.framesetOk && n && (e.treeAdapter.detachNode(n), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, O.HTML), e.insertionMode = F.IN_FRAMESET);
}
function Xt(e, t) {
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._insertElement(t, O.HTML);
}
function Zt(e, t) {
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e.openElements.currentTagId !== void 0 && ce.has(e.openElements.currentTagId) && e.openElements.pop(), e._insertElement(t, O.HTML);
}
function Qt(e, t) {
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._insertElement(t, O.HTML), e.skipNextNewLine = !0, e.framesetOk = !1;
}
function $t(e, t) {
	let n = e.openElements.tmplCount > 0;
	(!e.formElement || n) && (e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._insertElement(t, O.HTML), n || (e.formElement = e.openElements.current));
}
function en(e, t) {
	e.framesetOk = !1;
	let n = t.tagID;
	for (let t = e.openElements.stackTop; t >= 0; t--) {
		let r = e.openElements.tagIDs[t];
		if (n === j.LI && r === j.LI || (n === j.DD || n === j.DT) && (r === j.DD || r === j.DT)) {
			e.openElements.generateImpliedEndTagsWithExclusion(r), e.openElements.popUntilTagNamePopped(r);
			break;
		}
		if (r !== j.ADDRESS && r !== j.DIV && r !== j.P && e._isSpecialElement(e.openElements.items[t], r)) break;
	}
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._insertElement(t, O.HTML);
}
function tn(e, t) {
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._insertElement(t, O.HTML), e.tokenizer.state = P.PLAINTEXT;
}
function nn(e, t) {
	e.openElements.hasInScope(j.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(j.BUTTON)), e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML), e.framesetOk = !1;
}
function rn(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(A.A);
	n && (xt(e, t), e.openElements.remove(n.element), e.activeFormattingElements.removeEntry(n)), e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function an(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function on(e, t) {
	e._reconstructActiveFormattingElements(), e.openElements.hasInScope(j.NOBR) && (xt(e, t), e._reconstructActiveFormattingElements()), e._insertElement(t, O.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function sn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML), e.activeFormattingElements.insertMarker(), e.framesetOk = !1;
}
function cn(e, t) {
	e.treeAdapter.getDocumentMode(e.document) !== k.QUIRKS && e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._insertElement(t, O.HTML), e.framesetOk = !1, e.insertionMode = F.IN_TABLE;
}
function ln(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, O.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function un(e) {
	let t = f(e, ie.TYPE);
	return t != null && t.toLowerCase() === ct;
}
function dn(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, O.HTML), un(t) || (e.framesetOk = !1), t.ackSelfClosing = !0;
}
function fn(e, t) {
	e._appendElement(t, O.HTML), t.ackSelfClosing = !0;
}
function pn(e, t) {
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._appendElement(t, O.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function mn(e, t) {
	t.tagName = A.IMG, t.tagID = j.IMG, ln(e, t);
}
function hn(e, t) {
	e._insertElement(t, O.HTML), e.skipNextNewLine = !0, e.tokenizer.state = P.RCDATA, e.originalInsertionMode = e.insertionMode, e.framesetOk = !1, e.insertionMode = F.TEXT;
}
function gn(e, t) {
	e.openElements.hasInButtonScope(j.P) && e._closePElement(), e._reconstructActiveFormattingElements(), e.framesetOk = !1, e._switchToTextParsing(t, P.RAWTEXT);
}
function _n(e, t) {
	e.framesetOk = !1, e._switchToTextParsing(t, P.RAWTEXT);
}
function vn(e, t) {
	e._switchToTextParsing(t, P.RAWTEXT);
}
function yn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML), e.framesetOk = !1, e.insertionMode = e.insertionMode === F.IN_TABLE || e.insertionMode === F.IN_CAPTION || e.insertionMode === F.IN_TABLE_BODY || e.insertionMode === F.IN_ROW || e.insertionMode === F.IN_CELL ? F.IN_SELECT_IN_TABLE : F.IN_SELECT;
}
function bn(e, t) {
	e.openElements.currentTagId === j.OPTION && e.openElements.pop(), e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML);
}
function xn(e, t) {
	e.openElements.hasInScope(j.RUBY) && e.openElements.generateImpliedEndTags(), e._insertElement(t, O.HTML);
}
function Sn(e, t) {
	e.openElements.hasInScope(j.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(j.RTC), e._insertElement(t, O.HTML);
}
function Cn(e, t) {
	e._reconstructActiveFormattingElements(), tt(t), rt(t), t.selfClosing ? e._appendElement(t, O.MATHML) : e._insertElement(t, O.MATHML), t.ackSelfClosing = !0;
}
function wn(e, t) {
	e._reconstructActiveFormattingElements(), nt(t), rt(t), t.selfClosing ? e._appendElement(t, O.SVG) : e._insertElement(t, O.SVG), t.ackSelfClosing = !0;
}
function Tn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, O.HTML);
}
function I(e, t) {
	switch (t.tagID) {
		case j.I:
		case j.S:
		case j.B:
		case j.U:
		case j.EM:
		case j.TT:
		case j.BIG:
		case j.CODE:
		case j.FONT:
		case j.SMALL:
		case j.STRIKE:
		case j.STRONG:
			an(e, t);
			break;
		case j.A:
			rn(e, t);
			break;
		case j.H1:
		case j.H2:
		case j.H3:
		case j.H4:
		case j.H5:
		case j.H6:
			Zt(e, t);
			break;
		case j.P:
		case j.DL:
		case j.OL:
		case j.UL:
		case j.DIV:
		case j.DIR:
		case j.NAV:
		case j.MAIN:
		case j.MENU:
		case j.ASIDE:
		case j.CENTER:
		case j.FIGURE:
		case j.FOOTER:
		case j.HEADER:
		case j.HGROUP:
		case j.DIALOG:
		case j.DETAILS:
		case j.ADDRESS:
		case j.ARTICLE:
		case j.SEARCH:
		case j.SECTION:
		case j.SUMMARY:
		case j.FIELDSET:
		case j.BLOCKQUOTE:
		case j.FIGCAPTION:
			Xt(e, t);
			break;
		case j.LI:
		case j.DD:
		case j.DT:
			en(e, t);
			break;
		case j.BR:
		case j.IMG:
		case j.WBR:
		case j.AREA:
		case j.EMBED:
		case j.KEYGEN:
			ln(e, t);
			break;
		case j.HR:
			pn(e, t);
			break;
		case j.RB:
		case j.RTC:
			xn(e, t);
			break;
		case j.RT:
		case j.RP:
			Sn(e, t);
			break;
		case j.PRE:
		case j.LISTING:
			Qt(e, t);
			break;
		case j.XMP:
			gn(e, t);
			break;
		case j.SVG:
			wn(e, t);
			break;
		case j.HTML:
			qt(e, t);
			break;
		case j.BASE:
		case j.LINK:
		case j.META:
		case j.STYLE:
		case j.TITLE:
		case j.SCRIPT:
		case j.BGSOUND:
		case j.BASEFONT:
		case j.TEMPLATE:
			Pt(e, t);
			break;
		case j.BODY:
			Jt(e, t);
			break;
		case j.FORM:
			$t(e, t);
			break;
		case j.NOBR:
			on(e, t);
			break;
		case j.MATH:
			Cn(e, t);
			break;
		case j.TABLE:
			cn(e, t);
			break;
		case j.INPUT:
			dn(e, t);
			break;
		case j.PARAM:
		case j.TRACK:
		case j.SOURCE:
			fn(e, t);
			break;
		case j.IMAGE:
			mn(e, t);
			break;
		case j.BUTTON:
			nn(e, t);
			break;
		case j.APPLET:
		case j.OBJECT:
		case j.MARQUEE:
			sn(e, t);
			break;
		case j.IFRAME:
			_n(e, t);
			break;
		case j.SELECT:
			yn(e, t);
			break;
		case j.OPTION:
		case j.OPTGROUP:
			bn(e, t);
			break;
		case j.NOEMBED:
		case j.NOFRAMES:
			vn(e, t);
			break;
		case j.FRAMESET:
			Yt(e, t);
			break;
		case j.TEXTAREA:
			hn(e, t);
			break;
		case j.NOSCRIPT:
			e.options.scriptingEnabled ? vn(e, t) : Tn(e, t);
			break;
		case j.PLAINTEXT:
			tn(e, t);
			break;
		case j.COL:
		case j.TH:
		case j.TD:
		case j.TR:
		case j.HEAD:
		case j.FRAME:
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
		case j.CAPTION:
		case j.COLGROUP: break;
		default: Tn(e, t);
	}
}
function En(e, t) {
	if (e.openElements.hasInScope(j.BODY) && (e.insertionMode = F.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
		let n = e.openElements.tryPeekProperlyNestedBodyElement();
		n && e._setEndLocation(n, t);
	}
}
function Dn(e, t) {
	e.openElements.hasInScope(j.BODY) && (e.insertionMode = F.AFTER_BODY, Sr(e, t));
}
function On(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n));
}
function kn(e) {
	let t = e.openElements.tmplCount > 0, { formElement: n } = e;
	t || (e.formElement = null), (n || t) && e.openElements.hasInScope(j.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(j.FORM) : n && e.openElements.remove(n));
}
function An(e) {
	e.openElements.hasInButtonScope(j.P) || e._insertFakeElement(A.P, j.P), e._closePElement();
}
function jn(e) {
	e.openElements.hasInListItemScope(j.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(j.LI), e.openElements.popUntilTagNamePopped(j.LI));
}
function Mn(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTagsWithExclusion(n), e.openElements.popUntilTagNamePopped(n));
}
function Nn(e) {
	e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped());
}
function Pn(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker());
}
function Fn(e) {
	e._reconstructActiveFormattingElements(), e._insertFakeElement(A.BR, j.BR), e.openElements.pop(), e.framesetOk = !1;
}
function In(e, t) {
	let n = t.tagName, r = t.tagID;
	for (let t = e.openElements.stackTop; t > 0; t--) {
		let i = e.openElements.items[t], a = e.openElements.tagIDs[t];
		if (r === a && (r !== j.UNKNOWN || e.treeAdapter.getTagName(i) === n)) {
			e.openElements.generateImpliedEndTagsWithExclusion(r), e.openElements.stackTop >= t && e.openElements.shortenToLength(t);
			break;
		}
		if (e._isSpecialElement(i, a)) break;
	}
}
function Ln(e, t) {
	switch (t.tagID) {
		case j.A:
		case j.B:
		case j.I:
		case j.S:
		case j.U:
		case j.EM:
		case j.TT:
		case j.BIG:
		case j.CODE:
		case j.FONT:
		case j.NOBR:
		case j.SMALL:
		case j.STRIKE:
		case j.STRONG:
			xt(e, t);
			break;
		case j.P:
			An(e);
			break;
		case j.DL:
		case j.UL:
		case j.OL:
		case j.DIR:
		case j.DIV:
		case j.NAV:
		case j.PRE:
		case j.MAIN:
		case j.MENU:
		case j.ASIDE:
		case j.BUTTON:
		case j.CENTER:
		case j.FIGURE:
		case j.FOOTER:
		case j.HEADER:
		case j.HGROUP:
		case j.DIALOG:
		case j.ADDRESS:
		case j.ARTICLE:
		case j.DETAILS:
		case j.SEARCH:
		case j.SECTION:
		case j.SUMMARY:
		case j.LISTING:
		case j.FIELDSET:
		case j.BLOCKQUOTE:
		case j.FIGCAPTION:
			On(e, t);
			break;
		case j.LI:
			jn(e);
			break;
		case j.DD:
		case j.DT:
			Mn(e, t);
			break;
		case j.H1:
		case j.H2:
		case j.H3:
		case j.H4:
		case j.H5:
		case j.H6:
			Nn(e);
			break;
		case j.BR:
			Fn(e);
			break;
		case j.BODY:
			En(e, t);
			break;
		case j.HTML:
			Dn(e, t);
			break;
		case j.FORM:
			kn(e);
			break;
		case j.APPLET:
		case j.OBJECT:
		case j.MARQUEE:
			Pn(e, t);
			break;
		case j.TEMPLATE:
			It(e, t);
			break;
		default: In(e, t);
	}
}
function Rn(e, t) {
	e.tmplInsertionModeStack.length > 0 ? br(e, t) : Tt(e, t);
}
function zn(e, t) {
	var n;
	t.tagID === j.SCRIPT && ((n = e.scriptHandler) == null || n.call(e, e.openElements.current)), e.openElements.pop(), e.insertionMode = e.originalInsertionMode;
}
function Bn(e, t) {
	e._err(t, c.eofInElementThatCanContainOnlyText), e.openElements.pop(), e.insertionMode = e.originalInsertionMode, e.onEof(t);
}
function Vn(e, t) {
	if (e.openElements.currentTagId !== void 0 && ft.has(e.openElements.currentTagId)) switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = F.IN_TABLE_TEXT, t.type) {
		case d.CHARACTER:
			er(e, t);
			break;
		case d.WHITESPACE_CHARACTER: $n(e, t);
	}
	else Qn(e, t);
}
function Hn(e, t) {
	e.openElements.clearBackToTableContext(), e.activeFormattingElements.insertMarker(), e._insertElement(t, O.HTML), e.insertionMode = F.IN_CAPTION;
}
function Un(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, O.HTML), e.insertionMode = F.IN_COLUMN_GROUP;
}
function Wn(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(A.COLGROUP, j.COLGROUP), e.insertionMode = F.IN_COLUMN_GROUP, ar(e, t);
}
function Gn(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, O.HTML), e.insertionMode = F.IN_TABLE_BODY;
}
function Kn(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(A.TBODY, j.TBODY), e.insertionMode = F.IN_TABLE_BODY, cr(e, t);
}
function qn(e, t) {
	e.openElements.hasInTableScope(j.TABLE) && (e.openElements.popUntilTagNamePopped(j.TABLE), e._resetInsertionMode(), e._processStartTag(t));
}
function Jn(e, t) {
	un(t) ? e._appendElement(t, O.HTML) : Qn(e, t), t.ackSelfClosing = !0;
}
function Yn(e, t) {
	!e.formElement && e.openElements.tmplCount === 0 && (e._insertElement(t, O.HTML), e.formElement = e.openElements.current, e.openElements.pop());
}
function Xn(e, t) {
	switch (t.tagID) {
		case j.TD:
		case j.TH:
		case j.TR:
			Kn(e, t);
			break;
		case j.STYLE:
		case j.SCRIPT:
		case j.TEMPLATE:
			Pt(e, t);
			break;
		case j.COL:
			Wn(e, t);
			break;
		case j.FORM:
			Yn(e, t);
			break;
		case j.TABLE:
			qn(e, t);
			break;
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
			Gn(e, t);
			break;
		case j.INPUT:
			Jn(e, t);
			break;
		case j.CAPTION:
			Hn(e, t);
			break;
		case j.COLGROUP:
			Un(e, t);
			break;
		default: Qn(e, t);
	}
}
function Zn(e, t) {
	switch (t.tagID) {
		case j.TABLE:
			e.openElements.hasInTableScope(j.TABLE) && (e.openElements.popUntilTagNamePopped(j.TABLE), e._resetInsertionMode());
			break;
		case j.TEMPLATE:
			It(e, t);
			break;
		case j.BODY:
		case j.CAPTION:
		case j.COL:
		case j.COLGROUP:
		case j.HTML:
		case j.TBODY:
		case j.TD:
		case j.TFOOT:
		case j.TH:
		case j.THEAD:
		case j.TR: break;
		default: Qn(e, t);
	}
}
function Qn(e, t) {
	let n = e.fosterParentingEnabled;
	e.fosterParentingEnabled = !0, Wt(e, t), e.fosterParentingEnabled = n;
}
function $n(e, t) {
	e.pendingCharacterTokens.push(t);
}
function er(e, t) {
	e.pendingCharacterTokens.push(t), e.hasNonWhitespacePendingCharacterToken = !0;
}
function tr(e, t) {
	let n = 0;
	if (e.hasNonWhitespacePendingCharacterToken) for (; n < e.pendingCharacterTokens.length; n++) Qn(e, e.pendingCharacterTokens[n]);
	else for (; n < e.pendingCharacterTokens.length; n++) e._insertCharacters(e.pendingCharacterTokens[n]);
	e.insertionMode = e.originalInsertionMode, e._processToken(t);
}
var nr = /* @__PURE__ */ new Set([
	j.CAPTION,
	j.COL,
	j.COLGROUP,
	j.TBODY,
	j.TD,
	j.TFOOT,
	j.TH,
	j.THEAD,
	j.TR
]);
function rr(e, t) {
	let n = t.tagID;
	nr.has(n) ? e.openElements.hasInTableScope(j.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(j.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = F.IN_TABLE, Xn(e, t)) : I(e, t);
}
function ir(e, t) {
	let n = t.tagID;
	switch (n) {
		case j.CAPTION:
		case j.TABLE:
			e.openElements.hasInTableScope(j.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(j.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = F.IN_TABLE, n === j.TABLE && Zn(e, t));
			break;
		case j.BODY:
		case j.COL:
		case j.COLGROUP:
		case j.HTML:
		case j.TBODY:
		case j.TD:
		case j.TFOOT:
		case j.TH:
		case j.THEAD:
		case j.TR: break;
		default: Ln(e, t);
	}
}
function ar(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.COL:
			e._appendElement(t, O.HTML), t.ackSelfClosing = !0;
			break;
		case j.TEMPLATE:
			Pt(e, t);
			break;
		default: sr(e, t);
	}
}
function or(e, t) {
	switch (t.tagID) {
		case j.COLGROUP:
			e.openElements.currentTagId === j.COLGROUP && (e.openElements.pop(), e.insertionMode = F.IN_TABLE);
			break;
		case j.TEMPLATE:
			It(e, t);
			break;
		case j.COL: break;
		default: sr(e, t);
	}
}
function sr(e, t) {
	e.openElements.currentTagId === j.COLGROUP && (e.openElements.pop(), e.insertionMode = F.IN_TABLE, e._processToken(t));
}
function cr(e, t) {
	switch (t.tagID) {
		case j.TR:
			e.openElements.clearBackToTableBodyContext(), e._insertElement(t, O.HTML), e.insertionMode = F.IN_ROW;
			break;
		case j.TH:
		case j.TD:
			e.openElements.clearBackToTableBodyContext(), e._insertFakeElement(A.TR, j.TR), e.insertionMode = F.IN_ROW, ur(e, t);
			break;
		case j.CAPTION:
		case j.COL:
		case j.COLGROUP:
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE, Xn(e, t));
			break;
		default: Xn(e, t);
	}
}
function lr(e, t) {
	let n = t.tagID;
	switch (t.tagID) {
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
			e.openElements.hasInTableScope(n) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE);
			break;
		case j.TABLE:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE, Zn(e, t));
			break;
		case j.BODY:
		case j.CAPTION:
		case j.COL:
		case j.COLGROUP:
		case j.HTML:
		case j.TD:
		case j.TH:
		case j.TR: break;
		default: Zn(e, t);
	}
}
function ur(e, t) {
	switch (t.tagID) {
		case j.TH:
		case j.TD:
			e.openElements.clearBackToTableRowContext(), e._insertElement(t, O.HTML), e.insertionMode = F.IN_CELL, e.activeFormattingElements.insertMarker();
			break;
		case j.CAPTION:
		case j.COL:
		case j.COLGROUP:
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
		case j.TR:
			e.openElements.hasInTableScope(j.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE_BODY, cr(e, t));
			break;
		default: Xn(e, t);
	}
}
function dr(e, t) {
	switch (t.tagID) {
		case j.TR:
			e.openElements.hasInTableScope(j.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE_BODY);
			break;
		case j.TABLE:
			e.openElements.hasInTableScope(j.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE_BODY, lr(e, t));
			break;
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
			(e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(j.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = F.IN_TABLE_BODY, lr(e, t));
			break;
		case j.BODY:
		case j.CAPTION:
		case j.COL:
		case j.COLGROUP:
		case j.HTML:
		case j.TD:
		case j.TH: break;
		default: Zn(e, t);
	}
}
function fr(e, t) {
	let n = t.tagID;
	nr.has(n) ? (e.openElements.hasInTableScope(j.TD) || e.openElements.hasInTableScope(j.TH)) && (e._closeTableCell(), ur(e, t)) : I(e, t);
}
function pr(e, t) {
	let n = t.tagID;
	switch (n) {
		case j.TD:
		case j.TH:
			e.openElements.hasInTableScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = F.IN_ROW);
			break;
		case j.TABLE:
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
		case j.TR:
			e.openElements.hasInTableScope(n) && (e._closeTableCell(), dr(e, t));
			break;
		case j.BODY:
		case j.CAPTION:
		case j.COL:
		case j.COLGROUP:
		case j.HTML: break;
		default: Ln(e, t);
	}
}
function mr(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.OPTION:
			e.openElements.currentTagId === j.OPTION && e.openElements.pop(), e._insertElement(t, O.HTML);
			break;
		case j.OPTGROUP:
			e.openElements.currentTagId === j.OPTION && e.openElements.pop(), e.openElements.currentTagId === j.OPTGROUP && e.openElements.pop(), e._insertElement(t, O.HTML);
			break;
		case j.HR:
			e.openElements.currentTagId === j.OPTION && e.openElements.pop(), e.openElements.currentTagId === j.OPTGROUP && e.openElements.pop(), e._appendElement(t, O.HTML), t.ackSelfClosing = !0;
			break;
		case j.INPUT:
		case j.KEYGEN:
		case j.TEXTAREA:
		case j.SELECT:
			e.openElements.hasInSelectScope(j.SELECT) && (e.openElements.popUntilTagNamePopped(j.SELECT), e._resetInsertionMode(), t.tagID !== j.SELECT && e._processStartTag(t));
			break;
		case j.SCRIPT:
		case j.TEMPLATE: Pt(e, t);
	}
}
function hr(e, t) {
	switch (t.tagID) {
		case j.OPTGROUP:
			e.openElements.stackTop > 0 && e.openElements.currentTagId === j.OPTION && e.openElements.tagIDs[e.openElements.stackTop - 1] === j.OPTGROUP && e.openElements.pop(), e.openElements.currentTagId === j.OPTGROUP && e.openElements.pop();
			break;
		case j.OPTION:
			e.openElements.currentTagId === j.OPTION && e.openElements.pop();
			break;
		case j.SELECT:
			e.openElements.hasInSelectScope(j.SELECT) && (e.openElements.popUntilTagNamePopped(j.SELECT), e._resetInsertionMode());
			break;
		case j.TEMPLATE: It(e, t);
	}
}
function gr(e, t) {
	let n = t.tagID;
	n === j.CAPTION || n === j.TABLE || n === j.TBODY || n === j.TFOOT || n === j.THEAD || n === j.TR || n === j.TD || n === j.TH ? (e.openElements.popUntilTagNamePopped(j.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : mr(e, t);
}
function _r(e, t) {
	let n = t.tagID;
	n === j.CAPTION || n === j.TABLE || n === j.TBODY || n === j.TFOOT || n === j.THEAD || n === j.TR || n === j.TD || n === j.TH ? e.openElements.hasInTableScope(n) && (e.openElements.popUntilTagNamePopped(j.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : hr(e, t);
}
function vr(e, t) {
	switch (t.tagID) {
		case j.BASE:
		case j.BASEFONT:
		case j.BGSOUND:
		case j.LINK:
		case j.META:
		case j.NOFRAMES:
		case j.SCRIPT:
		case j.STYLE:
		case j.TEMPLATE:
		case j.TITLE:
			Pt(e, t);
			break;
		case j.CAPTION:
		case j.COLGROUP:
		case j.TBODY:
		case j.TFOOT:
		case j.THEAD:
			e.tmplInsertionModeStack[0] = F.IN_TABLE, e.insertionMode = F.IN_TABLE, Xn(e, t);
			break;
		case j.COL:
			e.tmplInsertionModeStack[0] = F.IN_COLUMN_GROUP, e.insertionMode = F.IN_COLUMN_GROUP, ar(e, t);
			break;
		case j.TR:
			e.tmplInsertionModeStack[0] = F.IN_TABLE_BODY, e.insertionMode = F.IN_TABLE_BODY, cr(e, t);
			break;
		case j.TD:
		case j.TH:
			e.tmplInsertionModeStack[0] = F.IN_ROW, e.insertionMode = F.IN_ROW, ur(e, t);
			break;
		default: e.tmplInsertionModeStack[0] = F.IN_BODY, e.insertionMode = F.IN_BODY, I(e, t);
	}
}
function yr(e, t) {
	t.tagID === j.TEMPLATE && It(e, t);
}
function br(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.popUntilTagNamePopped(j.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode(), e.onEof(t)) : Tt(e, t);
}
function xr(e, t) {
	t.tagID === j.HTML ? I(e, t) : Cr(e, t);
}
function Sr(e, t) {
	if (t.tagID === j.HTML) {
		if (e.fragmentContext || (e.insertionMode = F.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === j.HTML) {
			e._setEndLocation(e.openElements.items[0], t);
			let n = e.openElements.items[1];
			n && !e.treeAdapter.getNodeSourceCodeLocation(n)?.endTag && e._setEndLocation(n, t);
		}
	} else Cr(e, t);
}
function Cr(e, t) {
	e.insertionMode = F.IN_BODY, Wt(e, t);
}
function wr(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.FRAMESET:
			e._insertElement(t, O.HTML);
			break;
		case j.FRAME:
			e._appendElement(t, O.HTML), t.ackSelfClosing = !0;
			break;
		case j.NOFRAMES: Pt(e, t);
	}
}
function Tr(e, t) {
	t.tagID === j.FRAMESET && !e.openElements.isRootHtmlElementCurrent() && (e.openElements.pop(), !e.fragmentContext && e.openElements.currentTagId !== j.FRAMESET && (e.insertionMode = F.AFTER_FRAMESET));
}
function Er(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.NOFRAMES: Pt(e, t);
	}
}
function Dr(e, t) {
	t.tagID === j.HTML && (e.insertionMode = F.AFTER_AFTER_FRAMESET);
}
function Or(e, t) {
	t.tagID === j.HTML ? I(e, t) : kr(e, t);
}
function kr(e, t) {
	e.insertionMode = F.IN_BODY, Wt(e, t);
}
function Ar(e, t) {
	switch (t.tagID) {
		case j.HTML:
			I(e, t);
			break;
		case j.NOFRAMES: Pt(e, t);
	}
}
function jr(e, t) {
	t.chars = "�", e._insertCharacters(t);
}
function Mr(e, t) {
	e._insertCharacters(t), e.framesetOk = !1;
}
function Nr(e) {
	for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== O.HTML && e.openElements.currentTagId !== void 0 && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current);) e.openElements.pop();
}
function Pr(e, t) {
	if (et(t)) Nr(e), e._startTagOutsideForeignContent(t);
	else {
		let n = e._getAdjustedCurrentElement(), r = e.treeAdapter.getNamespaceURI(n);
		r === O.MATHML ? tt(t) : r === O.SVG && (it(t), nt(t)), rt(t), t.selfClosing ? e._appendElement(t, r) : e._insertElement(t, r), t.ackSelfClosing = !0;
	}
}
function Fr(e, t) {
	if (t.tagID === j.P || t.tagID === j.BR) Nr(e), e._endTagOutsideForeignContent(t);
	else for (let n = e.openElements.stackTop; n > 0; n--) {
		let r = e.openElements.items[n];
		if (e.treeAdapter.getNamespaceURI(r) === O.HTML) {
			e._endTagOutsideForeignContent(t);
			break;
		}
		let i = e.treeAdapter.getTagName(r);
		if (i.toLowerCase() === t.tagName) {
			t.tagName = i, e.openElements.shortenToLength(n);
			break;
		}
	}
}
A.AREA, A.BASE, A.BASEFONT, A.BGSOUND, A.BR, A.COL, A.EMBED, A.FRAME, A.HR, A.IMG, A.INPUT, A.KEYGEN, A.LINK, A.META, A.PARAM, A.SOURCE, A.TRACK, A.WBR;
//#endregion
//#region node_modules/parse5/dist/index.js
function Ir(e, t) {
	return mt.parse(e, t);
}
//#endregion
//#region src/forum-client/html.ts
function L(e) {
	return "tagName" in e;
}
function R(e) {
	return "childNodes" in e ? e.childNodes : [];
}
function z(e, t) {
	return L(e) ? e.attrs.find((e) => e.name === t)?.value ?? "" : "";
}
function B(e, t) {
	return R(e).flatMap((e) => [...L(e) && t(e) ? [e] : [], ...B(e, t)]);
}
function V(e, t) {
	return B(e, (e) => z(e, "id") === t)[0];
}
function H(e) {
	let t = (e) => e.attrs.some((e) => e.name === "disabled");
	if (t(e)) return !0;
	let n = e;
	for (let r = e.parentNode; r; r = "parentNode" in r ? r.parentNode : null) {
		if (L(r) && t(r) && (r.tagName === "optgroup" && e.tagName === "option" || r.tagName === "fieldset" && R(r).find((e) => L(e) && e.tagName === "legend") !== n)) return !0;
		n = r;
	}
	return !1;
}
function U(e, t) {
	return z(e, "class").split(/\s+/).includes(t);
}
function W(e) {
	return e ? "value" in e ? e.value : L(e) && ["script", "style"].includes(e.tagName) ? "" : R(e).map(W).join("") : "";
}
function G(e) {
	return W(e).replace(/\s+/g, " ").trim();
}
function K(e, t) {
	if (!e.trim()) return null;
	try {
		let n = new URL(e, t);
		return ["http:", "https:"].includes(n.protocol) && !n.username && !n.password ? n.href : null;
	} catch {
		return null;
	}
}
var Lr = new Set("p div span br hr strong b em i u s del ins sub sup small blockquote pre code ul ol li dl dt dd table thead tbody tfoot tr th td caption h1 h2 h3 h4 h5 h6 details summary a img".split(" ")), Rr = new Set("script style link meta base noscript template svg math input button select textarea".split(" ")), zr = new Set("iframe object embed video audio form".split(" "));
function Br(e, t, n, r) {
	return R(e).flatMap((e) => {
		if ("value" in e) return [{
			kind: "text",
			text: e.value
		}];
		if (!L(e) || Rr.has(e.tagName)) return [];
		if (z(e, "id") === "hb_mask" && U(e, "mask") && B(e, (e) => z(e, "id") === "hb_env" && U(e, "env")).length > 0) return [{
			kind: "unsupported",
			description: "Native red-packet interaction requires the native forum.",
			children: []
		}];
		let i = (U(e, "spoiler") || U(e, "spoiler_wrap")) && B(e, (e) => U(e, "spoilerbody") || U(e, "spoiler_content"))[0];
		if (i) {
			let a = B(e, (e) => U(e, "spoilerbutton") || U(e, "spoiler_btn") || U(e, "spoilerheader") || U(e, "spoiler_control")).find((e) => z(e, "value") || G(e));
			return [{
				kind: "element",
				tag: "details",
				attributes: {},
				children: [{
					kind: "element",
					tag: "summary",
					attributes: {},
					children: [{
						kind: "text",
						text: a && (z(a, "value") || G(a)) || "Show hidden content"
					}]
				}, ...Br(i, t, n, r)]
			}];
		}
		if (e.attrs.some((e) => e.name === "hidden") || /(?:^|;)\s*display\s*:\s*none(?:\s*!important)?\s*(?:;|$)/i.test(z(e, "style")) || /(?:^|;)\s*visibility\s*:\s*hidden(?:\s*!important)?\s*(?:;|$)/i.test(z(e, "style"))) return [{
			kind: "unsupported",
			description: "Additional native content is hidden; view it in the native forum.",
			children: []
		}];
		if (e.tagName === "ignore_js_op") return Br(e, t, n, r);
		if (zr.has(e.tagName)) return [{
			kind: "unsupported",
			description: "Unsupported interactive content",
			children: Br(e, t, n, r)
		}];
		if (!Lr.has(e.tagName)) return [{
			kind: "unsupported",
			description: `Unsupported formatting (${e.tagName})`,
			children: Br(e, t, n, r)
		}];
		if (r?.has(e) && ![
			"locked",
			"showhide",
			"attach_nopermission"
		].some((t) => U(e, t))) return Br(e, t, n, r);
		let a = {};
		[
			"locked",
			"showhide",
			"attach_nopermission"
		].some((t) => U(e, t)) && (a.class = "permission-notice"), U(e, "quote") && (a.class = "quote"), U(e, "blockcode") && (a.class = "code-block");
		let o = z(e, "align") || /(?:^|;)\s*text-align\s*:\s*(left|right|center|justify)\s*(?:;|$)/.exec(z(e, "style"))?.[1];
		if (o && [
			"left",
			"right",
			"center",
			"justify"
		].includes(o) && (a.style = `text-align:${o}`), e.tagName === "a") {
			let n = K(z(e, "href"), t);
			n && (a.href = n, a.rel = "noopener noreferrer");
		}
		if (e.tagName === "img") {
			let r = [
				"data-src",
				"zoomfile",
				"file",
				"data-original",
				"src"
			].map((t) => z(e, t)).find(Boolean) ?? "", i = n?.get(e), o = i ?? K(r, t);
			if (!o || !i && !/\.(?:png|jpe?g|gif|webp|avif|bmp)$/i.test(new URL(o).pathname)) return [{
				kind: "unsupported",
				description: "Image or attachment requires native viewing",
				children: []
			}];
			a.src = o, a.alt = z(e, "alt"), a.loading = "lazy", a.referrerpolicy = "no-referrer";
		}
		for (let t of ["colspan", "rowspan"]) /^[1-9]\d?$/.test(z(e, t)) && (a[t] = z(e, t));
		return [
			"ltr",
			"rtl",
			"auto"
		].includes(z(e, "dir")) && (a.dir = z(e, "dir")), z(e, "title") && (a.title = z(e, "title")), [{
			kind: "element",
			tag: e.tagName,
			attributes: a,
			children: Br(e, t, n, r)
		}];
	});
}
function q(e) {
	return Ir(e);
}
//#endregion
//#region src/forum-client/attachments.ts
function Vr(e, t) {
	let n = K(e, t);
	if (!n) return null;
	let r = new URL(n);
	return r.origin === new URL(t).origin && r.pathname === "/forum.php" && r.searchParams.get("mod") === "attachment" && [...r.searchParams.keys()].every((e) => [
		"mod",
		"aid",
		"nothumb",
		"noupdate"
	].includes(e) && r.searchParams.getAll(e).length === 1) && r.searchParams.getAll("aid").length === 1 && r.searchParams.get("aid") && !r.hash ? r.href : null;
}
function Hr(e, t) {
	let n = B(e, (e) => /^attach_[1-9]\d*$/.test(z(e, "id"))).flatMap((e) => {
		let t = B(e, (e) => e.tagName === "a" && !!z(e, "href"));
		return t.length === 1 ? [{
			id: z(e, "id").slice(7),
			anchor: t[0],
			scope: "parentNode" in e && e.parentNode ? e.parentNode : e
		}] : [];
	});
	for (let t of B(e, (e) => e.tagName === "dl" && U(e, "tattl"))) {
		let e = B(t, (e) => e.tagName === "p" && U(e, "attnm"));
		if (e.length !== 1) continue;
		let r = B(e[0], (e) => e.tagName === "a" && !!z(e, "href")), i = r.length === 1 ? r[0] : void 0;
		i && /^aid[1-9]\d*$/.test(z(i, "id")) && n.push({
			id: z(i, "id").slice(3),
			anchor: i,
			scope: t
		});
	}
	let r = B(e, (e) => e.tagName === "img" && /^aimg_[1-9]\d*$/.test(z(e, "id")));
	for (let i of r) {
		let a = z(i, "id").slice(5);
		if (z(i, "aid") !== a || r.filter((e) => z(e, "id") === `aimg_${a}`).length !== 1) continue;
		let o = !1;
		for (let t = i; t && (U(t, "attach_nopermission") && (o = !0), t !== e); t = "parentNode" in t ? t.parentNode : null);
		if (o) continue;
		let s = B(e, (e) => z(e, "id") === `aimg_${a}_menu`);
		if (s.length !== 1 || s[0].tagName !== "div") continue;
		let c = s[0], l = B(c, (e) => e.tagName === "a" && !!Vr(z(e, "href"), t));
		if (l.length !== 1) continue;
		let u = l[0], d = B(c, (e) => e.tagName === "strong"), f = d.length === 1 ? d[0] : void 0;
		if (z(u, "onclick") || z(u, "ping") || !f || f.parentNode?.nodeName !== "p" || !/\.(?:png|jpe?g|gif|webp|avif|bmp)$/i.test(G(f))) continue;
		let p = Vr(z(i, "file"), t), m = Vr(z(u, "href"), t), h = Vr(z(i, "zoomfile"), t);
		if (!p || !m || !h || ["data-src", "data-original"].some((e) => z(i, e) && K(z(i, e), t) !== p)) continue;
		let g = new URL(p), _ = new URL(m), v = new URL(h);
		g.searchParams.size === 3 && g.searchParams.get("noupdate") === "yes" && _.searchParams.size === 3 && _.searchParams.get("nothumb") === "yes" && g.searchParams.get("aid") === _.searchParams.get("aid") && v.searchParams.size === 4 && v.searchParams.get("noupdate") === "yes" && v.searchParams.get("nothumb") === "yes" && v.searchParams.get("aid") === g.searchParams.get("aid") && n.push({
			id: a,
			anchor: u,
			scope: c,
			image: i,
			imageURL: p,
			name: G(f)
		});
	}
	let i = n.filter((e, t) => n.findIndex((t) => t.id === e.id && t.anchor === e.anchor) === t), a = /* @__PURE__ */ new Map();
	return {
		attachments: i.flatMap(({ id: e, anchor: n, scope: r, image: o, imageURL: s, name: c }) => {
			if (i.filter((t) => t.id === e).length !== 1 || i.some((t) => t.anchor === n && t.id !== e) || /^aid[1-9]\d*$/.test(z(n, "id")) && z(n, "id").slice(3) !== e) return [];
			let l = Vr(z(n, "href"), t), u = c ?? G(n);
			return !l || !u || z(n, "onclick") || z(n, "ping") ? [] : (o && s && a.set(o, s), [{
				id: e,
				name: u,
				url: l,
				details: G(r)
			}]);
		}),
		inlineImages: a
	};
}
//#endregion
//#region src/forum-client/routes.ts
var Ur = {
	favorites: [
		"mod",
		"do",
		"type",
		"page"
	],
	"private-conversation": [
		"mod",
		"do",
		"subop",
		"touid",
		"page",
		"daterange"
	],
	messages: [
		"mod",
		"do",
		"filter",
		"page"
	],
	notices: [
		"mod",
		"do",
		"view",
		"type",
		"isread",
		"page"
	],
	search: [
		"mod",
		"adv",
		"searchid",
		"page",
		"orderby",
		"ascdesc",
		"searchsubmit",
		"kw"
	],
	directory: ["mod", "gid"],
	board: [
		"mod",
		"fid",
		"page",
		"filter",
		"typeid",
		"orderby",
		"digest",
		"specialtype",
		"rewardtype",
		"dateline",
		"authorid"
	],
	thread: [
		"mod",
		"tid",
		"page",
		"authorid",
		"ordertype",
		"viewpid",
		"from",
		"_dsign",
		"highlight"
	],
	redirect: [
		"mod",
		"goto",
		"tid",
		"ptid",
		"pid",
		"fromuid"
	]
};
function J(e) {
	try {
		let t = new URL(e), n = t.searchParams;
		if (t.protocol !== "https:" || t.username || t.password) return null;
		let r = null;
		if ([
			"/",
			"/index.php",
			"/forum.php"
		].includes(t.pathname) && (!n.has("mod") || n.get("mod") === "index") && (r = "directory"), t.pathname === "/forum.php" && (n.get("mod") === "forumdisplay" && /^[1-9]\d*$/.test(n.get("fid") ?? "") && (r = "board"), n.get("mod") === "viewthread" && /^[1-9]\d*$/.test(n.get("tid") ?? "") && (r = "thread"), n.get("mod") === "redirect" && (n.get("goto") === "findpost" && /^[1-9]\d*$/.test(n.get("pid") ?? "") || n.get("goto") === "lastpost" && /^[1-9]\d*$/.test(n.get("tid") ?? "")) && (r = "redirect")), t.pathname === "/search.php" && n.get("mod") === "forum" && (!n.has("adv") || n.get("adv") === "yes") && (!n.has("searchsubmit") || n.has("searchid") && n.get("searchsubmit") === "yes") && (!n.has("searchid") || /^[1-9]\d*$/.test(n.get("searchid") ?? "")) && (r = "search"), t.pathname === "/home.php" && n.get("mod") === "space" && n.get("do") === "notice" && ["view", "type"].every((e) => !n.has(e) || e === "type" && n.get(e) === "" || /^[a-zA-Z0-9_-]+$/.test(n.get(e))) && (!n.has("isread") || ["0", "1"].includes(n.get("isread"))) && (r = "notices"), t.pathname === "/home.php" && n.get("mod") === "space" && n.get("do") === "favorite" && ["thread", "forum"].includes(n.get("type") ?? "") && (r = "favorites"), t.pathname === "/home.php" && n.get("mod") === "space" && n.get("do") === "pm" && (!n.has("filter") || n.get("filter") === "privatepm") && (r = "messages"), t.pathname === "/home.php" && n.get("mod") === "space" && n.get("do") === "pm" && n.get("subop") === "view" && /^[1-9]\d*$/.test(n.get("touid") ?? "") && (!n.has("daterange") || n.get("daterange") === "0") && (!t.hash || /^#(?:last|pmlist_[1-9]\d*)$/.test(t.hash)) && (r = "private-conversation"), !r) return null;
		let i = [
			...Ur[r],
			"extra",
			"mobile",
			"tsdmapp"
		];
		for (let e of n.keys()) if (!i.includes(e) || n.getAll(e).length !== 1) return null;
		for (let e of [
			"gid",
			"fid",
			"tid",
			"pid",
			"ptid",
			"page",
			"authorid",
			"viewpid",
			"fromuid"
		]) if (n.has(e) && !/^[1-9]\d*$/.test(n.get(e) ?? "")) return null;
		return n.has("mobile") && !["2", "no"].includes(n.get("mobile")) ? null : {
			kind: r,
			url: t
		};
	} catch {
		return null;
	}
}
function Wr(e) {
	let t = J(e);
	return t?.kind === "thread" ? t.url : null;
}
function Y(e) {
	let t = new URL(e);
	return t.searchParams.delete("tsdmapp"), t.href;
}
//#endregion
//#region src/forum-client/read-board.ts
function Gr(e, t) {
	let n = e;
	for (; n;) {
		if ("tagName" in n && t(n)) return n;
		n = "parentNode" in n ? n.parentNode : null;
	}
	return null;
}
function Kr(e, t) {
	if (!e) return null;
	let n = K(z(e, "href"), t);
	return n && G(e) ? {
		url: Y(n),
		label: G(e)
	} : null;
}
function qr(e, t, n) {
	if (!e) return null;
	let r = B(e, (e) => e.tagName === "em").flatMap((e) => B(e, (e) => e.tagName === "a"))[0], i = r && K(z(r, "href"), t), a = i && J(i);
	if (!a || a.url.origin !== new URL(t).origin) return null;
	let o = a.url.searchParams, s = ["tid", "ptid"].every((e) => o.getAll(e).every((e) => e === n)), c = a.kind === "redirect" || a.kind === "thread" && (o.has("page") || o.has("pid") || /^#(?:pid[1-9]\d*|lastpost)$/.test(a.url.hash));
	return s && c ? {
		url: Y(a.url.href),
		label: G(r)
	} : null;
}
function Jr(e, t, n) {
	let r = t && Kr(B(t, (e) => e.tagName === "a")[0], n), i = r && J(r.url);
	return {
		...z(e, "id") ? { sourceId: z(e, "id") } : {},
		...i && ["directory", "favorites"].includes(i.kind) && i.url.origin === new URL(n).origin ? { sourceURL: i.url.href } : {}
	};
}
function Yr(e, t, n) {
	let r = B(e, (e) => e.tagName === "a" && n(e)).map((e) => Kr(e, t)).filter((e) => e !== null);
	return [...new Map(r.map((e) => [e.url, e])).values()];
}
function Xr(e, t) {
	let n = B(e, (e) => U(e, "pg") || U(e, "page"))[0];
	return {
		current: G(n && B(n, (e) => e.tagName === "strong")[0]) || new URL(t).searchParams.get("page") || "1",
		links: n ? Yr(n, t, (e) => !!J(K(z(e, "href"), t) ?? "")) : []
	};
}
function Zr(e, t) {
	let n = B(e, (e) => e.tagName === "a" && !!Gr(e, (e) => e.tagName === "h2" || e.tagName === "dt" || U(e, "murl"))).map((e) => {
		let n = Kr(e, t), r = n && J(n.url);
		if (!n || r?.kind !== "board" || r.url.origin !== new URL(t).origin) return null;
		let i = U(e, "murl") ? e : Gr(e, (e) => ["td", "li"].includes(e.tagName)) ?? e;
		return {
			...n,
			label: G(B(e, (e) => U(e, "mtit"))[0]) || n.label,
			id: r.url.searchParams.get("fid"),
			description: G(B(i, (e) => U(e, "xg2") || U(e, "mtxt"))[0]),
			stats: G(B(i, (e) => U(e, "xg1") || U(e, "mnum"))[0])
		};
	}).filter((e) => e !== null);
	return [...new Map(n.map((e) => [e.url, e])).values()];
}
function Qr(e, t) {
	let n = J(t), r = J(e.url), i = (e, n) => ({
		kind: e,
		message: n,
		account: { kind: "unknown" },
		sourceURL: t
	});
	if (!n || !r || r.url.origin !== n.url.origin || r.kind !== n.kind || n.kind === "board" && r.url.searchParams.get("fid") !== n.url.searchParams.get("fid") || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType)) return i("invalid", "The forum returned an unsupported response envelope.");
	let a = e.body;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(a)) try {
		let e = JSON.parse(a);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		a = `${"head" in e && typeof e.head == "string" ? e.head : ""}${e.document}`;
	} catch {
		return i("invalid", "The forum returned an invalid response.");
	}
	let o = q(a), s = X(o, e.url), c = G(B(o, (e) => e.tagName === "title")[0]), l = G(V(o, "messagetext") ?? V(o, "main_message"));
	if (V(o, "challenge-form") || V(o, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(c)) return {
		...i("challenge", "Native verification is required. Your destination is preserved."),
		account: s
	};
	if (e.status === 404 || e.status === 410 || /不存在|已[被經经]*删除|已[被經经]*刪除|not found/i.test(l)) return {
		...i("missing", "This board is missing or has been deleted."),
		account: s
	};
	if (e.status === 401 || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(l)) return {
		...i("login", "Sign in through the native forum, then retry."),
		account: s
	};
	if (e.status === 403 || /权限|權限|用户组|用戶組|無權/.test(l)) return {
		...i("permission", "The current account does not have permission to read this board."),
		account: s
	};
	if (e.status === 429) return {
		...i("limited", "The forum is limiting requests. Retry explicitly later."),
		account: s
	};
	if (e.status < 200 || e.status >= 300 || l) return {
		...i("invalid", e.status === 429 ? "The forum is limiting requests. Retry explicitly later." : "The forum response could not be displayed reliably."),
		account: s
	};
	let u = Y(e.url), d = {
		account: s,
		sourceURL: u
	};
	if (r.kind === "directory") {
		let e = B(o, (e) => /^category_\d+$/.test(z(e, "id"))).map((e) => {
			let t = Gr(e, (e) => U(e, "bm")), n = t ? B(t, (e) => U(e, "bm_h"))[0] : void 0, r = n && (B(n, (e) => e.tagName === "h2")[0] ?? n);
			return {
				...Jr(e, r, u),
				title: G(r) || "Boards",
				boards: Zr(e, u)
			};
		});
		return e.length || e.push(...B(o, (e) => U(e, "sub-forum")).map((e) => ({
			title: G(Gr(e, (e) => U(e, "forumlist")) && B(Gr(e, (e) => U(e, "forumlist")), (e) => e.tagName === "h2")[0] || void 0) || "Forum boards",
			boards: Zr(e, u)
		}))), e.length || e.push({
			title: "Forum boards",
			boards: Zr(o, u)
		}), e.some((e) => e.boards.length) ? {
			...d,
			kind: "directory",
			directory: {
				groups: e.filter((e) => e.boards.length),
				url: u,
				pages: Xr(o, u)
			}
		} : {
			...i("invalid", "The board directory could not be interpreted."),
			account: s
		};
	}
	let f = B(o, (e) => U(e, "threadlist_box"))[0], p = !!f, m = f ?? V(o, "threadlisttableid");
	if (V(o, "waterfall") && !m) return {
		...i("invalid", "This picture-board representation cannot yet be interpreted completely. Continue in the native forum."),
		account: s
	};
	let h = B(o, (e) => /^subforum_\d+$/.test(z(e, "id"))).flatMap((e) => Zr(e, u)), g = (m ? B(m, (e) => p ? e.tagName === "li" && (U(e, "list") || U(e, "list_top")) : /^(normal|stick)thread_[1-9]\d*$/.test(z(e, "id"))) : []).map((e) => {
		let t = Kr(B(e, (e) => e.tagName === "a" && (p ? z(e, "href").includes("mod=viewthread") : U(e, "xst")))[0], u), n = t && J(t.url);
		if (!t || n?.kind !== "thread" || n.url.origin !== r.url.origin) return null;
		let i = n.url.searchParams.get("tid"), a = p ? i : z(e, "id").split("_").at(-1), o = /(?:移动|移動)\s*[:：]/.test(G(e));
		if (a !== i && !o) return null;
		let s = B(e, (e) => e.tagName === "td" && U(e, "by")), c = B(e, (e) => U(e, "num"))[0], l = s.length > 1 ? s.at(-1) : void 0, d = l && B(l, (e) => e.tagName === "em")[0], f = d && B(d, (e) => !!z(e, "title"))[0];
		return {
			...t,
			id: i,
			rowId: a,
			...l ? { latestReply: {
				author: G(B(l, (e) => e.tagName === "cite")[0]) || null,
				time: (f ? z(f, "title") : G(d)) || null
			} } : {},
			moved: o,
			pinned: p ? U(e, "list_top") : z(e, "id").startsWith("stick"),
			category: G(B(e, (e) => e.tagName === "th").flatMap((e) => B(e, (e) => e.tagName === "em"))[0]),
			author: G(p ? B(e, (e) => U(e, "muser"))[0] : s[0] && B(s[0], (e) => e.tagName === "cite")[0]),
			date: G(p ? B(e, (e) => U(e, "mtime"))[0] : s[0] && B(s[0], (e) => e.tagName === "em")[0]),
			replies: G(p ? B(e, (e) => U(e, "mreply"))[0] : c && B(c, (e) => e.tagName === "a")[0]),
			views: G(c && B(c, (e) => e.tagName === "em")[0]),
			lastPost: qr(l, u, i)
		};
	}), _ = m ? G(B(m, (e) => U(e, "emp"))[0]) : "";
	if (g.some((e) => e === null) || !g.length && !h.length && !/暂无|沒有|没有|無主題|no (?:threads|posts)/i.test(_)) return {
		...i("invalid", "The board contains unrecognized or incomplete thread rows. Continue in the native forum for complete content."),
		account: s
	};
	let v = {
		thread_types: "category",
		filter_special_menu: "type",
		filter_orderby_menu: "order",
		filter_dateline_menu: "time",
		dhnav: "unclassified",
		dhnavs: "unclassified"
	}, y = (e) => Object.hasOwn(v, z(e, "id")) || /^filter_[a-z0-9_]+_menu$/i.test(z(e, "id")), b = B(o, y).flatMap((e) => {
		let t = z(e, "id"), n = (t) => Yr(t, u, (t) => Gr(t, y) === e).filter((e) => J(e.url)?.kind === "board"), r = n(e), i = B(e, (t) => t.tagName === "li" && !!t.parentNode && U(t.parentNode, "pop_moremenu") && Gr(t, y) === e), a = i.map((e) => {
			let r = [];
			for (let t of R(e)) {
				if (L(t) && (t.tagName === "a" || B(t, (e) => e.tagName === "a").length)) break;
				r.push(t);
			}
			let i = r.map((e) => G(e)).join(" ").replace(/\s+/g, " ").trim();
			return {
				kind: "unclassified",
				sourceId: t,
				...i ? { sourceLabel: i } : {},
				links: n(e)
			};
		}).filter((e) => e.links.length), o = new Set(a.flatMap((e) => e.links.map((e) => e.url)));
		return a.length && r.every((e) => o.has(e.url)) ? a : [{
			kind: i.length ? "unclassified" : Object.hasOwn(v, t) ? v[t] : "unclassified",
			sourceId: t,
			links: r
		}];
	}).filter((e) => e.links.length), x = b.flatMap((e) => e.links), S = {
		typeid: "Category",
		orderby: "Sort",
		authorid: "Author",
		dateline: "Time",
		digest: "Digest",
		specialtype: "Thread type",
		rewardtype: "Reward",
		filter: "Filter"
	}, C = {
		typeid: "category",
		orderby: "order",
		dateline: "time",
		specialtype: "type"
	}, w = V(o, "thread_types"), T = w ? B(w, (e) => e.tagName === "li" && U(e, "a") && U(e, "xw1")).flatMap((e) => Yr(e, u, () => !0)).filter((e) => J(e.url)?.kind === "board" && new URL(e.url).origin === r.url.origin && new URL(e.url).searchParams.get("fid") === r.url.searchParams.get("fid")) : [], ee = T.length === 1 ? T[0]?.label : void 0, te = (e) => {
		let t = new URL(e).searchParams;
		return [...t].filter(([e]) => Object.hasOwn(S, e) && !(e === "filter" && t.has(t.get("filter") ?? ""))).map(([t, n]) => {
			let i = b.flatMap((e) => e.links.filter((r) => {
				let i = new URL(r.url).searchParams;
				if (i.get(t) !== n) return !1;
				if (e.sourceId === "filter_reward_menu") return t === "rewardtype";
				let a = i.get("filter");
				return a ? a === t : e.kind === C[t];
			}))[0];
			return {
				label: `${S[t]}: ${t === "typeid" && n === r.url.searchParams.get("typeid") && ee ? ee : i?.label ?? n}`,
				url: e
			};
		});
	}, E = te(u), D = p ? B(o, (e) => U(e, "header"))[0] : V(o, "ct"), ne = D && B(D, (e) => e.tagName === (p ? "h2" : "h1"))[0], re = ne && R(ne).filter(L).filter((e) => e.tagName === "a").map((e) => Kr(e, u)).find((e) => e && J(e.url)?.kind === "board" && new URL(e.url).origin === r.url.origin && new URL(e.url).searchParams.get("fid") === r.url.searchParams.get("fid")), O = re && ne ? R(ne).filter(L).filter((e) => e.tagName === "span" && U(e, "xs1") && U(e, "xw0")).map((e) => G(e)).filter(Boolean).join(" ") : "", ie = re && te(re.url).length === 0 ? re : void 0, k = [...new Map([...x, ...ie ? [ie] : []].filter((e) => new URL(e.url).origin === r.url.origin && new URL(e.url).searchParams.get("fid") === r.url.searchParams.get("fid")).map((e) => [e.url, e])).values()].map((e) => {
		let t = new URL(e.url).searchParams;
		return {
			url: e.url,
			criteria: te(e.url),
			removed: E.filter((e) => {
				let n = Object.keys(S).find((t) => e.label.startsWith(`${S[t]}:`));
				return n && r.url.searchParams.get(n) !== t.get(n);
			})
		};
	});
	return {
		...d,
		kind: "board",
		board: {
			id: r.url.searchParams.get("fid"),
			title: re?.label || G(ne) || "Board threads",
			...O ? { statistics: O } : {},
			...ie ? { clearFilter: ie } : {},
			filterChoices: k,
			url: u,
			boards: h,
			threads: g.filter((e) => e !== null),
			filters: [...new Map(x.map((e) => [e.url, e])).values()],
			filterGroups: b,
			criteria: E,
			pages: Xr(o, u),
			empty: _
		}
	};
}
//#endregion
//#region src/forum-client/read-thread.ts
function $r(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set([t, ...B(t, () => !0)]), o = B(e, (e) => U(e, "pob") && !a.has(e)).flatMap((e) => B(e, (e) => e.tagName === "a").flatMap((e) => {
		let t = /^showWindow\('rate',\s*'([^']+)',\s*'get',\s*-1\);return false;?$/.exec(z(e, "onclick")), a = t && K(t[1], n);
		if (!a) return [];
		let o = new URL(a);
		return o.origin === new URL(n).origin && o.pathname === "/forum.php" && o.searchParams.get("mod") === "misc" && o.searchParams.get("action") === "rate" && o.searchParams.get("tid") === r && o.searchParams.get("pid") === i && [...o.searchParams.keys()].length === 4 && [...o.searchParams.keys()].every((e) => [
			"mod",
			"action",
			"tid",
			"pid"
		].includes(e)) ? [o.href] : [];
	}));
	return o.length === 1 ? o[0] : void 0;
}
function ei(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set([t, ...B(t, () => !0)]), o = B(e, (e) => U(e, "pob") && !a.has(e)).flatMap((e) => B(e, (e) => e.tagName === "a").flatMap((e) => {
		let t = /^showWindow\('miscreport\d+',\s*'([^']+)',\s*'get',\s*-1\);return false;?$/.exec(z(e, "onclick")), a = t && K(t[1], n);
		if (!a) return [];
		let o = new URL(a);
		return o.origin === new URL(n).origin && o.pathname === "/misc.php" && o.searchParams.get("mod") === "report" && o.searchParams.get("rtype") === "post" && o.searchParams.get("tid") === r && o.searchParams.get("rid") === i && /^[1-9]\d*$/.test(o.searchParams.get("fid") ?? "") && z(e, "onclick").startsWith(`showWindow('miscreport${i}',`) && [...o.searchParams.keys()].length === 5 && [...o.searchParams.keys()].every((e) => [
			"mod",
			"rtype",
			"tid",
			"rid",
			"fid"
		].includes(e)) ? [o.href] : [];
	}));
	return o.length === 1 ? o[0] : void 0;
}
var ti = (e) => e !== null && /^[1-9]\d*$/.test(e);
function ni(e) {
	let t = e;
	for (; t;) {
		if (/^(?:postlist|post_[0-9]+|postmessage_[0-9]+)$/.test(z(t, "id")) || U(t, "pcb") || U(t, "pcbs") || U(t, "viewthread") || U(t, "nts") || U(t, "ntc_body")) return !1;
		t = "parentNode" in t ? t.parentNode : null;
	}
	return !0;
}
function ri(e) {
	return e.some((e) => e.kind === "text" ? !!e.text.trim() : e.kind === "unsupported" || e.tag === "img" || ri(e.children));
}
function ii(e, t) {
	let n = Wr(t);
	if (!n) return;
	let r = B(e, (e) => U(e, "pg") && ni(e)), i;
	for (let e of r) {
		let r = B(e, (e) => e.tagName === "input" && z(e, "name") === "custompage"), a = G(B(e, (e) => e.tagName === "strong")[0]);
		if (r.length !== 1 || !ti(a) || a !== (n.searchParams.get("page") ?? "1") || z(r[0], "value") !== a) return;
		let o = r[0], s = z(o, "onkeydown").match(/^if\s*\(event\.keyCode\s*==\s*13\)\s*\{\s*window\.location\s*=\s*'([^'\\]+)'\s*\+\s*this\.value\s*;;\s*doane\(event\);\s*\}$/);
		if (!s || !/[?&]page=$/.test(s[1])) return;
		let c = K(`${s[1]}1`, t), l = c && Wr(c);
		if (!l || l.origin !== n.origin || l.searchParams.getAll("page").length !== 1 || [
			"tid",
			"authorid",
			"ordertype"
		].some((e) => (l.searchParams.get(e) ?? (e === "ordertype" ? "0" : "")) !== (n.searchParams.get(e) ?? (e === "ordertype" ? "0" : ""))) || [...l.searchParams.keys()].some((e) => /formhash|password|token|credential/i.test(e))) return;
		let u = "parentNode" in o ? o.parentNode : null, d = u && B(u, (e) => e.tagName === "span");
		if (!d || d.length !== 1) return;
		let f = z(d[0], "title").match(/^共\s*([1-9]\d*)\s*页$/), p = G(d[0]).match(/^\/\s*([1-9]\d*)\s*页$/);
		if (!f || !p || f[1] !== p[1]) return;
		let m = Number(f[1]);
		if (!Number.isSafeInteger(m) || m < Number(a)) return;
		let h = {
			url: Y(l.href),
			total: m
		};
		if (i && (i.url !== h.url || i.total !== h.total)) return;
		i = h;
	}
	return i;
}
function ai(e, t) {
	let n = Wr(t);
	if (!n || ![
		null,
		"0",
		"1",
		"2"
	].includes(n.searchParams.get("ordertype"))) return;
	let r = B(e, (e) => U(e, "pg") && ni(e))[0];
	if (!r) return;
	let i = G(B(r, (e) => e.tagName === "strong")[0]), a = B(r, (e) => e.tagName === "input" && z(e, "name") === "custompage");
	if (!ti(i) || a.length !== 1 || z(a[0], "value") !== i || i !== (n.searchParams.get("page") ?? "1")) return;
	let o = (e) => {
		let i = B(r, (t) => t.tagName === "a" && U(t, e));
		if (!i.length) return null;
		if (i.length !== 1) return;
		let a = K(z(i[0], "href"), t), o = a && Wr(a);
		if (o && o.origin === n.origin && ![
			"tid",
			"authorid",
			"ordertype"
		].some((e) => (o.searchParams.get(e) ?? (e === "ordertype" ? "0" : "")) !== (n.searchParams.get(e) ?? (e === "ordertype" ? "0" : "")))) return {
			url: Y(o.href),
			label: G(i[0]) || o.searchParams.get("page") || "1"
		};
	}, s = o("prev"), c = o("nxt"), l = o("last");
	if (s === void 0 || c === void 0 || l === void 0) return;
	let u = Number(i);
	if (s && Number(new URL(s.url).searchParams.get("page") ?? "1") !== u - 1 || c && Number(new URL(c.url).searchParams.get("page") ?? "1") !== u + 1 || !s && u !== 1) return;
	let d = B(r, (e) => e.tagName === "a").flatMap((e) => {
		let r = K(z(e, "href"), t), i = r && Wr(r);
		return i && i.origin === n.origin && i.searchParams.get("tid") === n.searchParams.get("tid") ? [Number(i.searchParams.get("page") ?? "1")] : [];
	});
	if (!c && d.some((e) => e > u) || !s && d.some((e) => e < u)) return;
	let f = n.searchParams.get("ordertype") === "1", p = !s && u === 1, m = !c;
	return {
		earlier: f ? c : s,
		later: f ? s : c,
		beginning: f ? m : p,
		end: f ? p : m,
		latest: !f && l ? {
			...l,
			url: `${l.url.split("#")[0]}#lastpost`
		} : null,
		order: f ? "descending" : "ascending"
	};
}
function X(e, t) {
	let n = B(e, (e) => ["um", "inner_stat"].includes(z(e, "id")) && ni(e)), r = n.length === 1 ? n[0] : void 0, i = r ? B(r, (e) => e.tagName === "strong").flatMap((e) => B(e, (e) => e.tagName === "a")).map((e) => {
		let n = K(z(e, "href"), t), r = n ? new URL(n).searchParams.get("uid") : null;
		return ti(r) ? {
			kind: "member",
			id: r,
			name: G(e)
		} : null;
	}).filter((e) => e !== null) : [];
	return i.length === 1 && i[0] ? i[0] : i.length === 0 && B(e, (e) => e.tagName === "form" && (z(e, "id") === "lsform" || z(e, "id").startsWith("loginform")) && ni(e)).length ? { kind: "guest" } : { kind: "unknown" };
}
function oi(e, t) {
	let n = Wr(t)?.origin, r = null;
	try {
		r = new URL(e.url).origin;
	} catch {}
	if (!n || r !== n || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType.trim())) return {
		kind: "invalid",
		message: "The forum returned an unsupported response envelope.",
		account: { kind: "unknown" },
		sourceURL: t
	};
	let i = e.body, a = null, o = null;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(i)) try {
		let e = JSON.parse(i);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error("No document");
		"uid" in e && typeof e.uid == "number" && Number.isSafeInteger(e.uid) && e.uid >= 0 && (a = e.uid === 0 ? { kind: "guest" } : {
			kind: "member",
			id: String(e.uid),
			name: `Member ${e.uid}`
		}), "thread" in e && e.thread && typeof e.thread == "object" && "tid" in e.thread && (typeof e.thread.tid == "number" || typeof e.thread.tid == "string") && (o = String(e.thread.tid)), i = `${"head" in e && typeof e.head == "string" ? e.head : ""}${e.document}`;
	} catch {
		return {
			kind: "invalid",
			message: "The forum returned an invalid response.",
			account: { kind: "unknown" },
			sourceURL: t
		};
	}
	let s = q(i), c = X(s, e.url), l = {
		account: a && c.kind !== "unknown" && (a.kind !== c.kind || a.kind === "member" && c.kind === "member" && a.id !== c.id) ? { kind: "unknown" } : c.kind === "unknown" ? a ?? c : c,
		sourceURL: e.url
	}, u = (e, t) => ({
		...l,
		kind: e,
		message: t
	}), d = G(B(s, (e) => e.tagName === "title")[0]), f = G(V(s, "messagetext") ?? V(s, "main_message"));
	if (V(s, "challenge-form") || V(s, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(d)) return u("challenge", "Native verification is required. Your intended thread is preserved.");
	if (e.status === 404 || e.status === 410 || /不存在|已[被經经]*删除|已[被經经]*刪除|not found/i.test(f)) return u("missing", "This thread is missing or has been deleted.");
	if (e.status === 401 || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(f) || B(s, (e) => e.tagName === "form" && z(e, "id").startsWith("loginform")).length) return u("login", "Sign in through the native forum, then retry this thread.");
	if (e.status === 403 || /权限|權限|用户组|用戶組|無權/.test(f)) return u("permission", "The current account does not have permission to read this thread.");
	if (e.status === 429) return u("limited", "The forum is limiting requests. Retry explicitly later.");
	if (e.status < 200 || e.status >= 300 || f) return u("invalid", "The forum response could not be displayed reliably.");
	let p = Wr(t), m = Wr(e.url);
	if (!p || !m || m.origin !== p.origin || m.searchParams.get("tid") !== p.searchParams.get("tid")) return u("invalid", "The forum returned a different destination. Continue in the native forum.");
	if (o !== null && o !== p.searchParams.get("tid")) return u("invalid", "The returned thread identity did not match.");
	let h = B(s, (e) => U(e, "viewthread")).length > 0, g = B(s, (e) => h ? U(e, "viewthread") : z(e, "id") === "postlist"), _ = g[0];
	if (!_ || g.length !== 1) return u("invalid", "Unrecognized thread content. Continue in the native forum.");
	let v = B(s, (e) => e.tagName === "link" && z(e, "rel") === "canonical")[0];
	if (v) {
		let t = K(z(v, "href"), e.url);
		if (!t || new URL(t).origin !== p.origin || Wr(t)?.searchParams.get("tid") !== p.searchParams.get("tid")) return u("invalid", "The returned thread identity did not match.");
	}
	let y = h ? B(_, (e) => U(e, "view_tit"))[0] : V(_, "thread_subject"), b = B(_, (e) => h ? /^pid[1-9]\d*$/.test(z(e, "id")) && U(e, "plc") : /^post_[1-9]\d*$/.test(z(e, "id")));
	if (!G(y) || !b.length) return u("invalid", "This thread has unrecognized or incomplete content.");
	let x = b.map((e) => z(e, "id").slice(h ? 3 : 5));
	if (new Set(x).size !== x.length) return u("invalid", "The returned post identities are ambiguous.");
	let S = /* @__PURE__ */ new Set(), C = b.map((t) => {
		let n = z(t, "id").slice(h ? 3 : 5), r = B(t, (e) => h ? U(e, "message") : U(e, "pcb") || U(e, "pcbs"))[0] ?? B(t, (e) => /^postmessage_/.test(z(e, "id")))[0];
		if (!r || !R(r).length) return null;
		S.add(r);
		let i = Hr(t, e.url), a = V(r, `postmessage_${n}`), o = /* @__PURE__ */ new Set();
		for (let e = a?.parentNode; e && e !== r; e = "parentNode" in e ? e.parentNode : null) "tagName" in e && e.tagName === "table" && o.add(e);
		let s = new Set(B(r, (e) => {
			if (![
				"table",
				"thead",
				"tbody",
				"tfoot",
				"tr",
				"td",
				"th"
			].includes(e.tagName)) return !1;
			let t = e;
			for (; t && !("tagName" in t && t.tagName === "table");) t = "parentNode" in t ? t.parentNode : null;
			return t !== null && o.has(t);
		})), c = Br(r, e.url, i.inlineImages, s);
		if (!ri(c)) return null;
		let l = B(t, (e) => U(e, "authi"))[0], u = l ? B(l, (e) => e.tagName === "a" && z(e, "href").includes("uid="))[0] : void 0, d = u ? K(z(u, "href"), e.url) : null, f = $r(t, r, e.url, p.searchParams.get("tid"), n), m = ei(t, r, e.url, p.searchParams.get("tid"), n);
		return {
			id: n,
			...m ? { reportURL: m } : {},
			attachments: i.attachments,
			...f ? { rateURL: f } : {},
			...B(r, (e) => U(e, "hb-entry") && z(e, "data-tid") === p.searchParams.get("tid")).length === 1 ? { redPacketThreadId: p.searchParams.get("tid") } : {},
			author: G(u) || "Anonymous",
			authorId: d && new URL(d).origin === p.origin && new URL(d).pathname === "/home.php" && new URL(d).searchParams.get("mod") === "space" && ti(new URL(d).searchParams.get("uid")) ? new URL(d).searchParams.get("uid") : null,
			floor: G(h ? B(t, (e) => U(e, "y"))[0] : V(t, `postnum${n}`)),
			date: G(h ? B(t, (e) => U(e, "mtime"))[0] : V(t, `authorposton${n}`)),
			url: `${p.origin}/forum.php?mod=redirect&goto=findpost&ptid=${p.searchParams.get("tid")}&pid=${n}`,
			content: [...c, ...B(t, (e) => U(e, "locked") || U(e, "attach_nopermission") || U(e, "modact")).filter((e) => {
				let t = e;
				for (; t;) {
					if (t === r) return !1;
					t = "parentNode" in t ? t.parentNode : null;
				}
				return !0;
			}).flatMap((e) => [{
				kind: "element",
				tag: "p",
				attributes: { class: "permission-notice" },
				children: [{
					kind: "text",
					text: G(e)
				}]
			}])]
		};
	});
	if (C.some((e) => e === null)) return u("invalid", "A post could not be interpreted. Continue in the native forum for complete content.");
	let w = Xr(s, e.url), T = ai(s, e.url), ee = ii(s, e.url), te = /^#pid([1-9]\d*)$/.exec(p.hash)?.[1] ?? p.searchParams.get("viewpid");
	if (p.hash === "#lastpost") {
		let e = C.filter((e) => e !== null), t = e.map((e) => /^\s*([1-9]\d*)/.exec(e.floor)?.[1]).map((e) => e ? Number(e) : NaN), n = m.searchParams.get("ordertype") === "1", r = Number(w.current), i = w.links.map((e) => Number(new URL(e.url).searchParams.get("page") ?? "1")), a = Number.isSafeInteger(r) && r > 0 && (n ? r === 1 && !i.some((e) => e < r) : !i.some((e) => e > r)), o = t.every((e, r) => Number.isSafeInteger(e) && (r === 0 || (n ? e < t[r - 1] : e > t[r - 1])));
		if (a && o && !m.searchParams.has("authorid")) te = (n ? e[0] : e.at(-1)).id;
		else return {
			...l,
			kind: "document-navigation",
			message: "The last reply requires canonical forum resolution.",
			destination: `${p.origin}/forum.php?mod=redirect&goto=lastpost&tid=${p.searchParams.get("tid")}#lastpost`
		};
	}
	return {
		...l,
		kind: "thread",
		thread: {
			id: p.searchParams.get("tid"),
			title: G(y),
			url: Y(e.url),
			posts: C.filter((e) => e !== null),
			pages: w,
			...T ? { history: T } : {},
			...ee ? { pageJump: ee } : {},
			filters: [...new Map(B(s, (e) => e.tagName === "a" && /[?&](authorid|ordertype)=/.test(z(e, "href")) && (() => {
				let t = !1;
				for (let n = e; n; n = "parentNode" in n ? n.parentNode : null) {
					if (S.has(n) || U(n, "pg") || U(n, "page")) return !1;
					(U(n, "pi") || U(n, "authi") || z(n, "id") === "postlist_filters") && (t = !0);
				}
				return !/[?&]authorid=/.test(z(e, "href")) || t;
			})()).map((t) => Kr(t, e.url)).filter((e) => e !== null && J(e.url)?.kind === "thread").map((e) => [e.url, e])).values()],
			parent: (V(s, "pt") ? B(V(s, "pt"), (e) => e.tagName === "a").map((t) => Kr(t, e.url)).filter((e) => e !== null && ["board", "directory"].includes(J(e.url)?.kind ?? "")) : []).at(-1) ?? null,
			target: te,
			notices: B(s, (e) => U(e, "locked") && ni(e)).map(G)
		}
	};
}
//#endregion
//#region src/forum-client/report.ts
var si = "var reasonstring = '';\nfor (i=0; i<reasons.length; i++) {\nreasonstring += '<label><input type=\"radio\" name=\"report_select\" class=\"pr\" onclick=\"' + (i < reasons.length -1 ? '$(\\'report_message\\').innerHTML=this.value;' : '') + '$(\\'report_other\\').style.display=\\'' + (i < reasons.length -1 ? 'none' : '') + '\\';$(\\'report_msg\\').style.display=\\'' + (i < reasons.length -1 ? 'none' : '') + '\\'\" value=\"' + reasons[i] + '\"> ' + reasons[i] + '</label><br />';\n}\n$('report_reasons').innerHTML = reasonstring;";
function ci(e) {
	let t = /^\s*var reasons = \[('[^'"&\\<>\r\n]{1,200}'(?:,\s*'[^'"&\\<>\r\n]{1,200}'){1,19})\];\s*([\s\S]*)$/.exec(e);
	if (!t || t[2].trim() !== si) throw Error("Reporting is unavailable: the native reason generator is unsupported.");
	let n = [...t[1].matchAll(/'([^']+)'/g)].map((e) => e[1]);
	if (new Set(n).size !== n.length) throw Error("The report reasons are ambiguous.");
	return n;
}
function li(e) {
	let t = 0, n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), a = (e) => `${e.accountId}:${e.threadId}:${e.postId}`, o = (e, t) => JSON.stringify(e) === JSON.stringify(t);
	async function s(t) {
		let n = new URL(t.threadURL), r = new URL(t.url);
		if (n.origin !== e.origin || r.origin !== e.origin || n.searchParams.get("tid") !== t.threadId || r.searchParams.get("fid") !== t.boardId) throw Error("The report target is invalid.");
		n.searchParams.set("tsdmapp", "json");
		let i = oi(await e.transport.request(n.href, { fresh: !0 }), t.threadURL);
		if (e.observe(i.account), i.kind !== "thread" || i.account.kind !== "member" || i.account.id !== t.accountId || !i.thread.posts.some((e) => e.id === t.postId && e.reportURL === t.url)) throw Error("The account, post or report permission changed. Nothing was sent.");
	}
	async function c(t) {
		let n = new URL(t.url), r = `miscreport${t.postId}`;
		n.searchParams.set("infloat", "yes"), n.searchParams.set("handlekey", r), n.searchParams.set("inajax", "1"), n.searchParams.set("ajaxtarget", `fwin_content_${r}`), n.searchParams.set("tsdmapp", "json");
		let i = await e.transport.request(n.href, { fresh: !0 }), a = new URL(i.url);
		if (a.origin !== n.origin || a.pathname !== "/misc.php" || [
			"mod",
			"rtype",
			"rid",
			"tid",
			"fid"
		].some((e) => a.searchParams.get(e) !== n.searchParams.get(e))) throw Error("The report response returned a different target.");
		if (i.status !== 200 || !/json/i.test(i.contentType)) throw Error("The report form response is unsupported.");
		let o = JSON.parse(i.body);
		if (o.ok !== 1 || o.type !== "result" || o.schema !== 13 || o.kind !== "page" || !Number.isSafeInteger(o.uid) || o.uid < 0 || typeof o.formhash != "string" || !o.formhash || typeof o.document != "string") throw Error("The structured report authority is unsupported.");
		let s = o.uid ? {
			kind: "member",
			id: String(o.uid),
			name: `Member ${o.uid}`
		} : { kind: "guest" };
		if (e.observe(s), s.kind !== "member" || s.id !== t.accountId) throw Error("The account changed on the report form. Nothing was sent.");
		let c = q(o.document), l = B(c, (e) => U(e, "alert_error") || z(e, "id") === "messagetext").map(G).join(" ");
		if (l) throw Error(l);
		let u = X(c, i.url);
		if (u.kind !== "unknown" && (u.kind !== "member" || u.id !== t.accountId)) throw Error("The report account evidence conflicts.");
		let d = B(c, (e) => e.tagName === "form"), f = d[0];
		if (d.length !== 1 || !f || z(f, "id") !== `form_${r}` || z(f, "method").toLowerCase() !== "post" || z(f, "onsubmit") !== `if(!$('report_message').value) return false;ajaxpost(this.id, 'form_${r}');`) throw Error("Reporting is unavailable: the native form is unsupported.");
		let p = K(z(f, "action"), i.url);
		if (p !== `${e.origin}/misc.php?mod=report`) throw Error("The report form returned a different action.");
		let m = B(f, (e) => [
			"input",
			"textarea",
			"select",
			"button"
		].includes(e.tagName)), h = {}, g = [
			"referer",
			"reportsubmit",
			"rtype",
			"rid",
			"fid",
			"url",
			"inajax",
			"handlekey",
			"formhash"
		];
		for (let e of m) {
			let t = z(e, "name");
			if (H(e)) throw Error("The report form has disabled controls.");
			if (t) {
				if (Object.hasOwn(h, t)) throw Error("The report controls are ambiguous.");
				if (t === "message") {
					if (e.tagName !== "textarea" || z(e, "id") !== "report_message" || e.attrs.some((e) => [
						"maxlength",
						"required",
						"pattern"
					].includes(e.name))) throw Error("The report content control is unsupported.");
				} else if (!g.includes(t) || e.tagName !== "input" || z(e, "type") !== "hidden") throw Error("The report form contains unsupported controls.");
				h[t] = z(e, "value");
			} else if (e.tagName !== "button" || z(e, "id") !== "report_submit" || z(e, "type") !== "submit" || z(e, "value") !== "true") throw Error("The report submit control is unsupported.");
		}
		if (g.some((e) => !Object.hasOwn(h, e)) || !Object.hasOwn(h, "message") || m.length !== 11 || h.formhash !== o.formhash || h.reportsubmit !== "true" || h.rtype !== "post" || h.rid !== t.postId || h.fid !== t.boardId || h.inajax !== "1" || h.handlekey !== r) throw Error("The report form authority or target does not match.");
		for (let e of [
			"report_reasons",
			"report_other",
			"report_msg"
		]) if (B(f, (t) => z(t, "id") === e).length !== 1) throw Error("The report choices are incomplete.");
		let _ = B(c, (e) => e.tagName === "script").map((e) => R(e).map((e) => "value" in e ? e.value : "").join("")).filter((e) => /report_reasons|var reasons\s*=/.test(e));
		if (_.length !== 1) throw Error("The report reasons are ambiguous.");
		let v = ci(_[0]), y = B(f, (e) => z(e, "id") === "checklen"), b = m.find((e) => z(e, "name") === "message");
		if (y.length !== 1 || G(y[0]) !== "200" || z(b, "onkeyup") !== "dstrLenCalc(this, 'checklen');") throw Error("The native report content limit is unsupported.");
		return {
			url: p,
			fields: h,
			reasons: v
		};
	}
	return {
		async prepare(l) {
			l = { ...l };
			try {
				if (r.has(a(l))) throw Error("This report is already in progress.");
				if (i.has(a(l))) throw Error("The previous report result is uncertain. It will not be retried; use the native forum to investigate before reporting again.");
				await s(l);
				let u = e.generation(), d = await c(l);
				if (e.generation() !== u) throw Error("The account changed while opening report.");
				for (let [e, t] of n) o(t.target, l) && n.delete(e);
				let f = {
					id: `report-${++t}`,
					target: l,
					reasons: d.reasons,
					maximum: 200,
					generation: u
				};
				return n.set(f.id, JSON.parse(JSON.stringify(f))), {
					kind: "ready",
					form: f
				};
			} catch (e) {
				return {
					kind: "unavailable",
					message: e instanceof Error ? e.message : "Reporting is unavailable."
				};
			}
		},
		async submit(t, l) {
			let u = JSON.parse(JSON.stringify(t)), d = JSON.parse(JSON.stringify(l)), f = (e, t) => ({
				kind: e,
				message: t,
				target: { ...u.target },
				intent: { ...d }
			});
			if (!o(n.get(u.id), u) || r.has(a(u.target)) || i.has(a(u.target))) return f("not-sent", "This report approval is stale or already used. Nothing was sent.");
			n.delete(u.id), r.add(a(u.target));
			let p = !1;
			try {
				if (typeof d.message != "string" || !d.message.trim() || Array.from(d.message).length > u.maximum || !u.reasons.includes(d.reason) || d.reason !== u.reasons.at(-1) && d.message !== d.reason) throw Error("Choose supported report content within the current limit. Nothing was sent.");
				if (e.generation() !== u.generation) throw Error("The account changed. Reopen report; nothing was sent.");
				await s(u.target);
				let t = await c(u.target);
				if (!o(t.reasons, u.reasons)) throw Error("The report choices changed. Reopen report; nothing was sent.");
				if (await s(u.target), e.generation() !== u.generation) throw Error("The account changed. Nothing was sent.");
				let n = new URLSearchParams(t.fields);
				n.set("message", d.message), n.set("report_select", d.reason), i.add(a(u.target)), p = !0;
				let r = await e.transport.request(t.url, {
					method: "POST",
					body: n.toString(),
					fresh: !0
				});
				if (r.status === 200 && r.url === t.url && /^text\/html/i.test(r.contentType)) {
					let e = q(r.body), t = B(e, (e) => U(e, "alert_error")), n = B(e, (e) => U(e, "alert_right"));
					if (t.length === 1 && G(t[0]) && n.length === 0 && B(e, (e) => e.tagName === "form" || e.tagName === "script").length === 0) return i.delete(a(u.target)), f("rejected", `Report rejected: ${G(t[0])}`);
				}
				return f("uncertain", "Report result uncertain. Independent report status is unavailable. The forum may have received it; it will not be retried.");
			} catch (e) {
				return f(p ? "uncertain" : "not-sent", p ? "Report result uncertain. Independent report status is unavailable. The forum may have received it; it will not be retried." : e instanceof Error ? e.message : "Report was not sent.");
			} finally {
				r.delete(a(u.target));
			}
		}
	};
}
//#endregion
//#region src/forum-client/rating.ts
function ui(e, t, n) {
	let r = new URL(e.url), i = new URL(t.url);
	if (r.origin !== i.origin || r.pathname !== "/forum.php" || r.searchParams.get("mod") !== "misc" || r.searchParams.get("action") !== n || r.searchParams.get("tid") !== t.threadId || r.searchParams.get("pid") !== t.postId) throw Error("The rating response returned a different target.");
}
function di(e) {
	let t = e.body;
	if (/json/i.test(e.contentType)) {
		let e = JSON.parse(t);
		if (typeof e.document != "string") throw Error("The rating response is unsupported.");
		t = (typeof e.head == "string" ? e.head : "") + e.document;
	} else if (/xml/i.test(e.contentType)) {
		let e = /^\s*(?:<\?xml[^?]*\?>\s*)?<root>\s*<!\[CDATA\[([\s\S]*)\]\]>\s*<\/root>\s*$/.exec(t);
		if (!e || /<!DOCTYPE|<!ENTITY/.test(t)) throw Error("The rating response is unsupported.");
		t = e[1];
	} else if (!/^text\/html/i.test(e.contentType)) throw Error("The rating response is unsupported.");
	return q(t);
}
function fi(e, t) {
	ui(e, t, "rate");
	let n = di(e), r = B(n, (e) => U(e, "alert_error") || z(e, "id") === "messagetext").map(G).join(" ");
	if (e.status !== 200 || r) throw Error(r || "The forum refused this rating form.");
	let i = B(n, (e) => e.tagName === "form" && z(e, "id") === "rateform"), a = i[0];
	if (i.length !== 1 || !a || z(a, "method").toLowerCase() !== "post") throw Error("Rating is unavailable: the current form is unsupported.");
	let o = K(z(a, "action"), e.url), s = o && new URL(o), c = new URL(t.url);
	if (!s || s.origin !== c.origin || s.pathname !== "/forum.php" || s.searchParams.get("mod") !== "misc" || s.searchParams.get("action") !== "rate" || s.searchParams.get("ratesubmit") !== "yes" || s.searchParams.get("infloat") !== "yes" || [...s.searchParams.keys()].length !== 4 || [...s.searchParams.keys()].some((e) => ![
		"mod",
		"action",
		"ratesubmit",
		"infloat"
	].includes(e))) throw Error("The rating form returned a different action.");
	let l = B(a, (e) => [
		"input",
		"textarea",
		"select",
		"button"
	].includes(e.tagName)), u = {};
	for (let e of l) {
		let t = z(e, "name");
		if (t) {
			if (H(e) || Object.hasOwn(u, t) || !/^(?:formhash|tid|pid|referer|handlekey|reason|sendreasonpm|ratesubmit|score\d+)$/.test(t)) throw Error("Rating is unavailable: unfamiliar or disabled form controls.");
			u[t] = z(e, "type") === "checkbox" && !e.attrs.some((e) => e.name === "value") ? "on" : z(e, "value");
		}
	}
	for (let e of [
		"formhash",
		"tid",
		"pid",
		"referer",
		"handlekey"
	]) {
		let t = l.find((t) => z(t, "name") === e);
		if (!t || t.tagName !== "input" || z(t, "type") !== "hidden") throw Error("The rating form authority controls are unsupported.");
	}
	for (let e of [
		"formhash",
		"tid",
		"pid"
	]) if (!u[e]) throw Error("The rating form is incomplete.");
	if (!Object.hasOwn(u, "referer") || !Object.hasOwn(u, "handlekey")) throw Error("The rating form is incomplete.");
	if (u.tid !== t.threadId || u.pid !== t.postId) throw Error("The rating form returned a different post.");
	let d = [];
	for (let e of B(a, (e) => e.tagName === "tr")) {
		let t = B(e, (e) => e.tagName === "input" && /^score\d+$/.test(z(e, "name")));
		if (!t.length) continue;
		let n = R(e).filter((e) => "tagName" in e && e.tagName === "td"), r = /^(-?\d+)\s*[~～至]\s*(-?\d+)$/.exec(G(n[2]));
		if (t.length !== 1 || !["", "text"].includes(z(t[0], "type")) || z(t[0], "value") !== "0" || n.length !== 4 || !r || !/^\d+$/.test(G(n[3]))) throw Error("The rating limits could not be established.");
		let i = Number(r[1]), a = Number(r[2]), o = Number(G(n[3]));
		if (![
			i,
			a,
			o
		].every(Number.isSafeInteger) || i > 0 || a < 0 || i > a || !G(n[0])) throw Error("The rating limits are unsupported.");
		d.push({
			name: z(t[0], "name"),
			label: G(n[0]),
			minimum: i,
			maximum: a,
			remaining: o
		});
	}
	let f = l.find((e) => z(e, "name") === "sendreasonpm"), p = l.find((e) => z(e, "name") === "reason"), m = l.find((e) => z(e, "name") === "ratesubmit");
	if (!d.length || d.length !== Object.keys(u).filter((e) => /^score\d+$/.test(e)).length || !p || p.tagName !== "input" || !["", "text"].includes(z(p, "type")) || p.attrs.some((e) => [
		"maxlength",
		"required",
		"pattern"
	].includes(e.name)) || !f || z(f, "type") !== "checkbox" || u.sendreasonpm !== "on" || !m || z(m, "type") !== "submit" || u.ratesubmit !== "true") throw Error("The rating choices are incomplete.");
	return {
		url: s.href,
		fields: u,
		scores: d,
		reasons: B(a, (e) => z(e, "id") === "reasonselect").flatMap((e) => B(e, (e) => e.tagName === "li").map(G)),
		notify: f.attrs.some((e) => e.name === "checked"),
		notice: G(B(a, (e) => U(e, "alert_info"))[0])
	};
}
function pi(e) {
	let t = 0, n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set(), o = (e) => `${e.accountId}:${e.threadId}:${e.postId}`, s = (e, t) => JSON.stringify(e) === JSON.stringify(t);
	async function c(t) {
		let n = new URL(t.url);
		n.searchParams.set("action", "viewratings"), n.searchParams.set("infloat", "yes"), n.searchParams.set("handlekey", "viewratings"), n.searchParams.set("inajax", "1"), n.searchParams.set("ajaxtarget", "fwin_content_viewratings"), n.searchParams.set("tsdmapp", "json");
		let r = await e.transport.request(n.href, { fresh: !0 });
		if (ui(r, t, "viewratings"), r.status !== 200) throw Error("Rating log is unavailable.");
		if (/json/i.test(r.contentType)) {
			let n = JSON.parse(r.body);
			if (n && typeof n == "object" && "uid" in n) {
				if (typeof n.uid != "number" || !Number.isSafeInteger(n.uid) || n.uid < 0 || !("schema" in n) || n.schema !== 13 || !("type" in n) || n.type !== "result") throw Error("The structured rating log is unsupported.");
				if (e.observe(n.uid ? {
					kind: "member",
					id: String(n.uid),
					name: `Member ${n.uid}`
				} : { kind: "guest" }), String(n.uid) !== t.accountId) throw Error("The account changed while checking the rating log.");
				if ("ok" in n && n.ok === 0 && "kind" in n && n.kind === "handle" && "message_key" in n && n.message_key === "thread_rate_log_nonexistence") return [];
				if (!("ok" in n) || n.ok !== 1 || !("kind" in n) || n.kind !== "page") throw Error("The forum did not return a qualified rating log.");
			}
		}
		let i = di(r), a = B(i, (e) => e.tagName === "table" && U(e, "list"));
		if (a.length !== 1) {
			if (/errorhandle_viewratings\('抱歉，指定帖子在近一年内没有评分记录'/.test(r.body)) return [];
			throw Error("The rating log could not be established.");
		}
		if (B(i, (e) => U(e, "pg")).length) throw Error("The rating log is paginated and cannot confirm this action.");
		return B(a[0], (e) => e.tagName === "tr").flatMap((e, n) => {
			let i = R(e).filter((e) => "tagName" in e && e.tagName === "td");
			if (!i.length || n === 0 && i.length === 4 && G(i[0]) === "积分" && G(i[2]) === "时间" && B(e, (e) => e.tagName === "a").length === 0) return [];
			let a = /^(.+?)\s+([+-]?\d+)$/.exec(G(i[0])), o = i[1] ? B(i[1], (e) => e.tagName === "a") : [], s = o.length === 1 ? K(z(o[0], "href"), r.url) : null, c = s ? new URL(s) : null, l = c?.searchParams.get("uid");
			if (i.length !== 4 || !a || !c || c.origin !== new URL(t.url).origin || c.pathname !== "/home.php" || c.searchParams.get("mod") !== "space" || !l || !/^\d+$/.test(l) || !G(i[2])) throw Error("The rating log contains an unsupported record.");
			return [{
				label: a[1],
				value: Number(a[2]),
				actor: l,
				time: G(i[2]),
				reason: G(i[3])
			}];
		});
	}
	async function l(t) {
		let n = new URL(t.threadURL);
		if (n.origin !== e.origin || new URL(t.url).origin !== e.origin || n.searchParams.get("tid") !== t.threadId) throw Error("The rating target is invalid.");
		n.searchParams.set("tsdmapp", "json");
		let r = oi(await e.transport.request(n.href, { fresh: !0 }), t.threadURL);
		if (e.observe(r.account), r.kind !== "thread" || r.account.kind !== "member" || r.account.id !== t.accountId || !r.thread.posts.some((e) => e.id === t.postId && e.rateURL === t.url)) throw Error("The account, post or rating permission changed. Nothing was sent.");
	}
	async function u(t) {
		let n = new URL(t.url);
		n.searchParams.set("infloat", "yes"), n.searchParams.set("handlekey", "rate"), n.searchParams.set("inajax", "1"), n.searchParams.set("ajaxtarget", "fwin_content_rate"), n.searchParams.set("tsdmapp", "json");
		let r = await e.transport.request(n.href, { fresh: !0 });
		ui(r, t, "rate");
		let i = X(di(r), r.url), a = i, o = null;
		if (/json/i.test(r.contentType)) {
			let e = JSON.parse(r.body);
			if (e && typeof e == "object" && "uid" in e) {
				if (typeof e.uid != "number" || !Number.isSafeInteger(e.uid) || e.uid < 0 || !("ok" in e) || e.ok !== 1 || !("schema" in e) || e.schema !== 13 || !("kind" in e) || e.kind !== "page" || !("type" in e) || e.type !== "result" || !("formhash" in e) || typeof e.formhash != "string" || !e.formhash) throw Error("The structured rating authority is unsupported.");
				if (a = e.uid === 0 ? { kind: "guest" } : {
					kind: "member",
					id: String(e.uid),
					name: `Member ${e.uid}`
				}, i.kind !== "unknown" && (i.kind !== "member" || a.kind !== "member" || i.id !== a.id)) throw Error("The rating account evidence conflicts.");
				o = e.formhash;
			}
		}
		if (a.kind !== "member" || a.id !== t.accountId) throw e.observe(a), Error("The account changed or could not be verified on the rating form. Nothing was sent.");
		e.observe(a);
		let s = fi(r, t);
		if (o !== null && s.fields.formhash !== o) throw Error("The rating form authority does not match the current account envelope.");
		return s;
	}
	return {
		async prepare(r) {
			r = { ...r };
			try {
				if (a.has(o(r))) throw Error("This post already has a rating in progress.");
				if (i.has(o(r))) throw Error("The previous rating result is uncertain. Check the native rating log before another rating; it will not be retried.");
				await l(r);
				let s = e.generation(), c = await u(r);
				if (e.generation() !== s) throw Error("The account changed while opening rating.");
				for (let [e, t] of n) o(t.target) === o(r) && n.delete(e);
				let d = {
					id: `rating-${++t}`,
					target: { ...r },
					scores: c.scores,
					reasons: c.reasons,
					notify: c.notify,
					notice: c.notice,
					generation: s
				};
				return n.set(d.id, JSON.parse(JSON.stringify(d))), {
					kind: "ready",
					form: d
				};
			} catch (e) {
				return {
					kind: "unavailable",
					message: e instanceof Error ? e.message : "Rating is unavailable."
				};
			}
		},
		async submit(t, d) {
			let f = JSON.parse(JSON.stringify(t)), p = JSON.parse(JSON.stringify(d)), m = (e, t) => ({
				kind: e,
				message: t,
				intent: JSON.parse(JSON.stringify(p)),
				target: { ...f.target }
			});
			if (a.has(o(f.target)) || r.has(f.id) || !s(n.get(f.id), f) || i.has(o(f.target))) return m("not-sent", "This rating approval is stale or already used. Nothing was sent.");
			r.add(f.id), n.delete(f.id), a.add(o(f.target));
			let h = !1;
			try {
				if (!s(Object.keys(p.scores).sort(), f.scores.map((e) => e.name).sort()) || typeof p.reason != "string" || typeof p.notify != "boolean" || !f.scores.some((e) => p.scores[e.name] !== 0) || f.scores.some((e) => {
					let t = p.scores[e.name];
					return !Number.isSafeInteger(t) || t < e.minimum || t > e.maximum || Math.abs(t) > e.remaining;
				})) throw Error("Choose a nonzero whole-number rating within the current range and daily allowance. Nothing was sent.");
				if (e.generation() !== f.generation) throw Error("The account changed. Reopen rating; nothing was sent.");
				await l(f.target);
				let t = await u(f.target);
				if (!s(t.scores, f.scores) || !s(t.reasons, f.reasons) || t.notify !== f.notify || t.notice !== f.notice) throw Error("The rating choices or allowance changed. Reopen rating; nothing was sent.");
				let n = await c(f.target);
				if (await l(f.target), e.generation() !== f.generation) throw Error("The account changed. Nothing was sent.");
				let r = new URLSearchParams(t.fields);
				for (let e of f.scores) r.set(e.name, String(p.scores[e.name]));
				r.set("reason", p.reason), p.notify || r.delete("sendreasonpm"), i.add(o(f.target)), h = !0;
				let a = await e.transport.request(t.url, {
					method: "POST",
					body: r.toString()
				}), d = new URL(a.url), g = new URL(t.url);
				if (d.origin !== g.origin || d.pathname !== g.pathname || d.searchParams.get("action") !== "rate") throw Error("The rating response returned an unfamiliar action.");
				let _ = B(di(a), (e) => U(e, "alert_error")).map(G).join(" ") || /errorhandle_rate\('([^']+)'/.exec(a.body)?.[1];
				if (_) return i.delete(o(f.target)), m("rejected", `Rating rejected: ${_}`);
				if (a.status !== 200) throw Error("The rating response was not confirmed.");
				let v = [...await c(f.target)];
				for (let e of n) {
					let t = v.findIndex((t) => s(t, e));
					if (t < 0) throw Error("Rating history changed ambiguously.");
					v.splice(t, 1);
				}
				let y = f.scores.filter((e) => p.scores[e.name] !== 0);
				if (v.length !== y.length || !y.every((e) => v.filter((t) => t.actor === f.target.accountId && t.label === e.label && t.value === p.scores[e.name] && t.reason === p.reason.trim()).length === 1)) throw Error("The exact new rating could not be independently confirmed.");
				return i.delete(o(f.target)), m("confirmed", "Rating confirmed by a fresh forum rating log.");
			} catch (e) {
				return m(h ? "uncertain" : "not-sent", h ? "Rating result uncertain. The forum may have applied it. Check the native rating log; this rating will not be retried." : e instanceof Error ? e.message : "Rating was not sent.");
			} finally {
				a.delete(o(f.target));
			}
		}
	};
}
//#endregion
//#region src/forum-client/private-conversation.ts
function mi(e, t) {
	let n = { kind: "unknown" }, r = (e = "The private conversation could not be confirmed. Continue in the native forum.", r = "invalid") => ({
		kind: r,
		message: e,
		account: n,
		sourceURL: t
	}), i = J(t), a = J(e.url);
	if (i?.kind !== "private-conversation" || a?.kind !== "private-conversation" || i.url.origin !== a.url.origin || i.url.searchParams.get("touid") !== a.url.searchParams.get("touid") || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType)) return r();
	let o = e.body, s = null;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(o)) try {
		let e = JSON.parse(o);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") return r();
		o = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document, "uid" in e && typeof e.uid == "number" && Number.isSafeInteger(e.uid) && e.uid >= 0 && (s = e.uid);
	} catch {
		return r();
	}
	let c = q(o), l = X(c, e.url), u = s === null ? { kind: "unknown" } : s === 0 ? { kind: "guest" } : {
		kind: "member",
		id: String(s),
		name: `Member ${s}`
	}, d = (e) => e.kind === "member" ? e.id : e.kind;
	n = l.kind === "unknown" ? u : u.kind !== "unknown" && d(u) !== d(l) ? { kind: "unknown" } : l;
	let f = G(V(c, "messagetext") ?? V(c, "main_message"));
	if (V(c, "challenge-form") || V(c, "cf-challenge-running") || /Just a moment|Checking your browser/.test(G(B(c, (e) => e.tagName === "title")[0]))) return r("Native verification is required before reading this private conversation.", "challenge");
	if (e.status === 401 || n.kind === "guest" || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(f)) return r("Sign in through the native forum before reading this private conversation.", "login");
	if (e.status === 403 || /权限|權限|用户组|用戶組|無權/.test(f)) return r("The current account cannot read this private conversation.", "permission");
	if (e.status === 429) return r("The forum is limiting private-conversation requests. Retry only deliberately.", "limited");
	if (n.kind !== "member" || e.status < 200 || e.status >= 300 || f) return r();
	let p = n.id, m = i.url.searchParams.get("touid"), h = V(c, "ct"), g = V(c, "pm_ul");
	if (!h) return r();
	let _ = B(h, (e) => U(e, "emp")).map(G).filter(Boolean).join(" ");
	if (!g && !_) return r();
	let v = B(h, (e) => U(e, "tbmu"))[0], y = v ? B(v, (e) => e.tagName === "a").filter((t) => {
		let n = K(z(t, "href"), e.url);
		if (!n) return !1;
		let r = new URL(n);
		return r.origin === i.url.origin && r.pathname === "/home.php" && r.searchParams.get("mod") === "space" && r.searchParams.get("uid") === m;
	}) : [];
	if (y.length !== 1 || !G(y[0]) || B(c, (e) => e.tagName === "input" && z(e, "name") === "topmuid").some((e) => z(e, "value") !== m)) return r();
	let b = R(g ?? h).filter((e) => "tagName" in e && e.tagName === "dl").map((t) => {
		let r = /^pmlist_([1-9]\d*)$/.exec(z(t, "id"))?.[1], a = B(t, (e) => U(e, "avt"))[0], o = a && B(a, (e) => e.tagName === "a")[0], s = o && K(z(o, "href"), e.url), c = s ? new URL(s) : null, l = c?.searchParams.get("uid"), u = B(t, (e) => e.tagName === "dd" && U(e, "ptm"))[0];
		if (!r || !c || c.origin !== i.url.origin || c.pathname !== "/home.php" || c.searchParams.get("mod") !== "space" || ![m, p].includes(l ?? "") || !u) return null;
		let d = u.childNodes, f = d.findIndex((e) => "tagName" in e && e.tagName === "br"), h = d.findIndex((e, t) => t > f && U(e, "xg1")), g = h >= 0 ? B(d[h], (e) => !!z(e, "title"))[0] : null;
		if (f < 0 || h < 0 || !g) return null;
		let _ = {
			...u,
			childNodes: d.slice(f + 1, h)
		}, v = new URL(Y(e.url));
		return v.hash = `pmlist_${r}`, {
			id: r,
			senderId: l,
			sender: l === p ? n.kind === "member" ? n.name : "" : G(y[0]),
			time: z(g, "title"),
			body: Br(_, e.url),
			url: v.href
		};
	});
	if (!b.length && !_ || b.some((e) => e === null) || new Set(b.map((e) => e?.id)).size !== b.length) return r();
	let x = b.filter((e) => e !== null), S = R(g ?? h).findIndex((e) => z(e, "name") === "last"), C = S >= 0 ? R(g ?? h).slice(S + 1).find((e) => /^pmlist_/.test(z(e, "id"))) : null, w = G(V(c, "membernum")) || (_ ? "0" : "");
	if (!/^\d+$/.test(w)) return r();
	let T = Number(w);
	if (!Number.isSafeInteger(T) || T < x.length || !x.length && T !== 0) return r();
	let ee = B(h, (e) => U(e, "pg")), te = ee.flatMap((e) => B(e, (e) => e.tagName === "strong")).map(G);
	if (new Set(te).size > 1 || te.some((e) => !/^[1-9]\d*$/.test(e))) return r();
	let E = te[0] ?? a.url.searchParams.get("page") ?? "1";
	if (i.url.searchParams.has("page") && E !== i.url.searchParams.get("page") || a.url.searchParams.has("page") && E !== a.url.searchParams.get("page")) return r();
	let D = ee.flatMap((e) => B(e, (e) => e.tagName === "a")).map((t) => {
		let n = K(z(t, "href"), e.url), r = n ? J(n) : null;
		return r?.kind !== "private-conversation" || r.url.origin !== i.url.origin || r.url.searchParams.get("touid") !== m || r.url.hash || !r.url.searchParams.has("page") ? null : {
			label: G(t),
			url: Y(r.url.href),
			earlier: U(t, "prev") || U(t.parentNode ?? t, "pgb"),
			later: U(t, "nxt")
		};
	});
	if (D.some((e) => e === null)) return r();
	let ne = D.filter((e) => e !== null), re = ne.filter((e) => e.earlier), O = ne.filter((e) => e.later);
	if (re.length > 1 || O.length > 1 || re.some((e) => Number(new URL(e.url).searchParams.get("page")) !== Number(E) - 1) || O.some((e) => Number(new URL(e.url).searchParams.get("page")) !== Number(E) + 1)) return r();
	let ie = re[0] ? {
		label: re[0].label,
		url: re[0].url
	} : null, k = O[0] ? {
		label: O[0].label,
		url: O[0].url
	} : null, A = i.url.hash === "#last" ? C ? z(C, "id").slice(7) : null : /^#pmlist_([1-9]\d*)$/.exec(i.url.hash)?.[1] ?? null;
	return {
		kind: "private-conversation",
		account: n,
		sourceURL: t,
		conversation: {
			url: Y(e.url),
			peerId: m,
			peerName: G(y[0]),
			totalCount: T,
			messages: x,
			pages: {
				current: E,
				links: ne.map((e) => ({
					label: e.label,
					url: e.url
				}))
			},
			earlier: ie,
			later: k,
			beginning: T === x.length,
			end: T === x.length,
			target: A,
			targetMissing: !!i.url.hash && (!A || !x.some((e) => e.id === A)),
			empty: x.length ? "" : _
		}
	};
}
//#endregion
//#region src/forum-client/edit-attachments.ts
function hi(e, t) {
	let n = B(e, (e) => [
		"input",
		"select",
		"textarea",
		"button"
	].includes(e.tagName) && /^(?:attach|delete)/.test(z(e, "name"))), r = /* @__PURE__ */ new Set();
	for (let e of n) {
		let n = z(e, "name");
		if (r.has(n) || z(e, "form")) return null;
		r.add(n);
		let i = /^attachupdate\[[1-9]\d*\]$/.test(n);
		if (!i && !/^attachnew\[[1-9]\d*\]\[(?:description|readperm|price)\]$/.test(n) || i && (e.tagName !== "input" || z(e, "type") !== "hidden" || z(e, "value") !== "") || !i && (e.tagName === "input" ? ![
			"",
			"text",
			"hidden",
			"number"
		].includes(z(e, "type")) : e.tagName !== "select" || e.attrs.some((e) => e.name === "multiple"))) return null;
		let a = !1, o = !1;
		for (let n = e.parentNode; n; n = "parentNode" in n ? n.parentNode : null) (n === t || ["e_attachlist", "e_imgattachlist"].includes(z(n, "id"))) && (a = !0), "tagName" in n && n.tagName === "form" && n !== t && (o = !0);
		if (!a || o) return null;
	}
	return n;
}
function gi(e) {
	return e.map((e) => {
		let t = e.tagName === "select" ? B(e, (e) => e.tagName === "option") : [], n = t.find((e) => e.attrs.some((e) => e.name === "selected")) ?? t[0];
		return {
			name: z(e, "name"),
			value: n ? n.attrs.some((e) => e.name === "value") ? z(n, "value") : W(n) : z(e, "value"),
			disabled: H(e)
		};
	});
}
//#endregion
//#region src/forum-client/prepare-writing.ts
var _i = {
	usesig: "Signature",
	parseurloff: "Disable URL recognition",
	smileyoff: "Disable emoticons",
	bbcodeoff: "Disable BBCode",
	htmlon: "HTML",
	imgcontent: "Render content as image",
	price: "Thread price",
	readperm: "Read permission",
	hiddenreplies: "Replies visible only to author",
	ordertype: "Reverse reply order",
	allownoticeauthor: "Receive reply notifications",
	addfeed: "Publish activity",
	adddynamic: "Share with followers",
	adddynamic_doing: "Ask followers to share",
	tags: "Tags"
}, vi = (e, t) => e.attrs.some((e) => e.name === t);
function yi(e, t, n) {
	let r = B(e, (e) => e.tagName === "label" && z(e, "for") === z(t, "id") && !!z(t, "id"))[0], i = t.parentNode, a = r ?? (i && "tagName" in i && i.tagName === "label" ? i : void 0);
	return (a ? R(a).filter((e) => !("tagName" in e) || ![
		"input",
		"select",
		"textarea"
	].includes(e.tagName)).map(W).join("").trim() : "") || n;
}
function Z(e, t, n, r, i) {
	let a = { kind: "unknown" }, o = (e, n) => ({
		kind: e,
		message: n,
		account: a,
		sourceURL: t
	}), s = K(e.url, t);
	if (!s || new URL(s).origin !== new URL(t).origin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType)) return o("invalid", "The forum returned an unsupported preparation response.");
	let c = e.body;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(c)) try {
		let e = JSON.parse(c);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		c = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document;
	} catch {
		return o("invalid", "The forum returned invalid preparation data.");
	}
	let l = q(c);
	a = X(l, s);
	let u = G(V(l, "messagetext") ?? V(l, "main_message"));
	if (V(l, "challenge-form") || V(l, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证/i.test(G(B(l, (e) => e.tagName === "title")[0]))) return o("challenge", "Complete native verification, then prepare again.");
	if (e.status === 401 || a.kind === "guest" || /未登录|未登錄|先登录|先登錄/.test(u)) return o("login", "Sign in through the native forum, then prepare again. A form token does not establish an account.");
	if (e.status === 403 || /权限|權限|用户组|用戶組|無權/.test(u)) return o("permission", "The current account cannot prepare this new thread.");
	if (e.status === 429) return o("limited", "The forum is limiting requests. Try again explicitly later.");
	if (e.status < 200 || e.status >= 300 || u || a.kind !== "member") return o("invalid", "A current member account and complete native form are required.");
	let d = B(l, (e) => e.tagName === "form" && z(e, "id") === "postform"), f = d.length === 1 ? d[0] : void 0, p = f && K(z(f, "action"), s);
	if (!f || !p || z(f, "method").toLowerCase() !== "post") return o("invalid", "The current native new-thread form is unavailable.");
	let m = new URL(p);
	if (m.origin !== new URL(t).origin || m.pathname !== "/forum.php" || m.searchParams.get("mod") !== "post" || m.searchParams.get("action") !== (r ? "edit" : i ? "reply" : "newthread") || !r && m.searchParams.get("fid") !== n || i && !r && (m.searchParams.getAll("tid").length !== 1 || m.searchParams.get("tid") !== i.threadId) || r && [
		"fid",
		"tid",
		"pid"
	].some((e) => {
		let t = e === "fid" ? n : e === "tid" ? r.threadId : r.postId, i = [...m.searchParams.getAll(e), ...B(f, (t) => z(t, "name") === e).map((e) => z(e, "value"))];
		return i.length !== 1 || i[0] !== t;
	}) || [
		"mod",
		"action",
		...r ? [] : ["fid"]
	].some((e) => m.searchParams.getAll(e).length !== 1) || m.searchParams.has("special") && m.searchParams.get("special") !== "0") return o("invalid", "The returned form targets a different action or board.");
	let h = B(f, (e) => [
		"input",
		"select",
		"textarea"
	].includes(e.tagName)), g = r ? hi(l, f) : [];
	if (!g) return o("invalid", "Existing attachment controls are unavailable or cannot be preserved safely.");
	for (let e of g) h.includes(e) || h.push(e);
	let _ = (e) => h.filter((t) => z(t, "name") === e);
	if ((r ? _("subject").length > 1 : _("subject").length !== 1) || _("message").length !== 1 || _("message")[0]?.tagName !== "textarea" || [
		"subject",
		"message",
		"typeid",
		...Object.keys(_i)
	].some((e) => _(e).length > 1)) return o("invalid", "The native form does not provide unambiguous complete source and options.");
	if (i && !r) {
		let e = [
			"reppid",
			"reppost",
			"noticeauthor",
			"noticeauthormsg",
			"noticetrimstr"
		];
		if (e.some((e) => _(e).length > 1 || _(e).some((e) => e.tagName !== "input" || z(e, "type") !== "hidden" || H(e)))) return o("invalid", "The reply target controls are ambiguous or unsupported.");
		if (i.postId) {
			if (!["reppid", "reppost"].every((e) => _(e).length === 1 && z(_(e)[0], "value") === i.postId) || !["noticeauthor", "noticeauthormsg"].every((e) => _(e).length === 1 && z(_(e)[0], "value")) || _("noticetrimstr").length !== 1 || z(_("noticetrimstr")[0], "value") !== "") return o("invalid", "The native addressed target did not match the selected post.");
		} else if (_("reppid").length || _("reppost").length || e.some((e) => _(e).some((e) => z(e, "value") !== ""))) return o("invalid", "An ordinary reply unexpectedly contains an addressed target.");
	}
	function v(e, t) {
		let n = e.tagName === "select" ? B(e, (e) => e.tagName === "option").map((e) => ({
			value: vi(e, "value") ? z(e, "value") : W(e),
			label: G(e) || "No category",
			disabled: H(e)
		})) : [], r = e.tagName === "select" ? B(e, (e) => e.tagName === "option" && vi(e, "selected"))[0] : void 0;
		return {
			name: z(e, "name"),
			label: yi(l, e, t),
			kind: e.tagName === "select" ? "select" : z(e, "type") === "checkbox" ? "checkbox" : "text",
			value: e.tagName === "select" ? r ? vi(r, "value") ? z(r, "value") : W(r) : n[0]?.value ?? "" : z(e, "value"),
			checked: vi(e, "checked"),
			disabled: H(e),
			choices: n,
			maxLength: /^\d+$/.test(z(e, "maxlength")) ? Number(z(e, "maxlength")) : null
		};
	}
	let y = {
		hb_total: "Total credits",
		hb_shares: "Share count",
		hb_split: "Split",
		hb_cond: "Require a reply",
		hb_password: "Passphrase",
		hb_appoint: "Designated recipients",
		hb_expire: "Expiry",
		hb_blessing: "Greeting"
	}, b = !r && !i && new URL(t).searchParams.get("specialextra") === "hongbao", x = [];
	if (b) {
		if (h.some((e) => z(e, "name").startsWith("hb_") && !Object.hasOwn(y, z(e, "name")))) return o("invalid", "The complete native red-packet controls are unavailable.");
		for (let [e, t] of Object.entries(y)) {
			let n = _(e);
			if (e === "hb_split") {
				if (n.length !== 2 || n.some((e) => z(e, "type") !== "radio") || n.filter((e) => vi(e, "checked")).length !== 1) return o("invalid", "The native red-packet split controls are unavailable or ambiguous.");
				let e = n.find((e) => vi(e, "checked"));
				x.push({
					...v(e, t),
					label: t,
					kind: "select",
					checked: !1,
					choices: n.map((e) => ({
						value: z(e, "value"),
						label: yi(l, e, z(e, "value")),
						disabled: H(e)
					}))
				});
			} else {
				if (n.length !== 1) return o("invalid", "The complete native red-packet controls are unavailable.");
				let e = n[0];
				x.push({
					...v(e, t),
					label: t,
					...z(e, "min") ? { minimum: z(e, "min") } : {},
					...z(e, "max") ? { maximum: z(e, "max") } : {},
					...z(e, "step") ? { step: z(e, "step") } : {}
				});
			}
		}
	}
	let S = h.filter((e) => Object.hasOwn(_i, z(e, "name"))).map((e) => v(e, _i[z(e, "name")])), C = _("typeid")[0], w = B(V(l, "pt") ?? l, (e) => e.tagName === "a").find((e) => {
		let t = K(z(e, "href"), s);
		if (!t) return !1;
		let r = new URL(t);
		return r.origin === m.origin && r.searchParams.get("mod") === "forumdisplay" && r.searchParams.get("fid") === n;
	}), T = [...new Set(h.map((e) => /^attachnew\[([1-9]\d*)\]/.exec(z(e, "name"))?.[1]).filter((e) => !!e))];
	return {
		kind: "prepared",
		account: a,
		sourceURL: t,
		prepared: {
			action: i ? i.postId ? "quick-quote" : "reply" : "new-thread",
			...i ? { replyTarget: i } : {},
			draftSaveAvailable: !i && _("save").length === 1 && z(_("save")[0], "type") === "hidden" && z(_("save")[0], "id") === "postsave" && !H(_("save")[0]) && B(f, (e) => e.tagName === "button" && z(e, "type") === "button" && !H(e) && /postsave.*value\s*=\s*1/.test(z(e, "onclick"))).length === 1,
			board: {
				id: n,
				label: G(w) || `Board ${n}`,
				url: `${m.origin}/forum.php?mod=forumdisplay&fid=${n}`
			},
			account: a,
			title: _("subject")[0] ? z(_("subject")[0], "value") : "",
			...r && !_("subject").length ? { titleAvailable: !1 } : {},
			source: W(_("message")[0]),
			category: C ? v(C, "Category") : null,
			options: [...S, ...x],
			...b ? { redPacket: { hints: B(f, (e) => z(e, "class").split(/\s+/).includes("hb-hint")).map(G) } } : {},
			uploadedReferences: T,
			...r ? { uploads: T.map((e) => ({
				key: `existing:${e}`,
				serverId: e,
				name: `Attachment ${e}`,
				type: "",
				size: 0,
				loaded: 0,
				status: "associated",
				message: "Existing saved attachment. Removing its source tag does not remove the server file.",
				fields: gi(g).filter((t) => t.name.startsWith(`attachnew[${e}]`))
			})) } : {},
			attachmentFields: r ? gi(g) : h.filter((e) => /^attachnew\[[1-9]\d*\]\[[a-z_]+\]$/.test(z(e, "name"))).map((e) => ({
				name: z(e, "name"),
				value: e.tagName === "textarea" ? W(e) : z(e, "value"),
				disabled: H(e)
			}))
		}
	};
}
function bi(e) {
	return [...new Set([...e.source.matchAll(/\[attach(?:img)?\]\s*([1-9]\d*)\s*\[\/attach(?:img)?\]/gi)].map((e) => e[1]))].filter((t) => !e.uploadedReferences.includes(t));
}
function xi(e) {
	return JSON.stringify([
		e.title,
		e.source,
		e.category && [
			e.category.name,
			e.category.value,
			e.category.checked
		],
		e.options.map((e) => [
			e.name,
			e.value,
			e.checked
		]),
		e.uploadedReferences,
		e.attachmentFields ?? []
	]);
}
function Si(e, t) {
	try {
		let n = JSON.parse(e.version);
		return !Array.isArray(n) || n.length !== 6 || !Array.isArray(n[4]) || !Array.isArray(n[5]) ? e : (n[4] = n[4].filter((e) => e !== t), n[5] = n[5].filter((e) => typeof e?.name != "string" || !e.name.startsWith(`attachnew[${t}]`) && !e.name.startsWith(`attachupdate[${t}]`)), {
			...e,
			version: JSON.stringify(n)
		});
	} catch {
		return e;
	}
}
//#endregion
//#region src/forum-client/upload-authoring.ts
function Ci(e) {
	let t = "", n = "", r = !1;
	for (let i = 0; i < e.length; i++) {
		let a = e[i];
		if (n) t += a, r ? r = !1 : a === "\\" ? r = !0 : a === n && (n = "");
		else if (a === "\"" || a === "'") n = a, t += a;
		else if (e.slice(i, i + 2) === "//") {
			for (; i < e.length && !/[\r\n]/.test(e[i]);) i++;
			t += "\n";
		} else if (e.slice(i, i + 2) === "/*") {
			let n = e.indexOf("*/", i + 2);
			if (n < 0) throw Error();
			i = n + 1, t += " ";
		} else t += a;
	}
	return t;
}
function wi(e) {
	e = Ci(e);
	let t = /* @__PURE__ */ new Map(), n = 0, r = "", i = !1, a = [], o = (r) => {
		let i = e.slice(n, r).trim();
		if (!i) return !0;
		let a = /^(?:([A-Za-z_$][\w$]*)|'([^'\\]*)'|"([^"\\]*)")\s*:([\s\S]+)$/.exec(i);
		if (!a) return !1;
		let o = a[1] ?? a[2] ?? a[3];
		return t.has(o) || t.size > 80 ? !1 : (t.set(o, a[4].trim()), !0);
	};
	for (let t = 0; t < e.length; t++) {
		let s = e[t];
		if (r) i ? i = !1 : s === "\\" ? i = !0 : s === r && (r = "");
		else if (s === "'" || s === "\"") r = s;
		else {
			if (s === "`" || e.slice(t, t + 2) === "/*" || e.slice(t, t + 2) === "//") return null;
			if ("{[(".includes(s)) {
				if (a.push(s), a.length > 16) return null;
			} else if ("}])".includes(s)) {
				if (a.pop() !== {
					"}": "{",
					"]": "[",
					")": "("
				}[s]) return null;
			} else if (s === "," && !a.length) {
				if (!o(t)) return null;
				n = t + 1;
			}
		}
	}
	return !r && !a.length && o(e.length) ? t : null;
}
function Ti(e) {
	let t = /^(['"])([^\\\r\n]*)\1$/.exec(e ?? "");
	return t && !t[2].includes(t[1]) ? t[2] : null;
}
function Ei(e) {
	return /^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(e ?? "") && Number.isFinite(Number(e)) ? Number(e) : null;
}
function Di(e) {
	return e?.startsWith("{") && e.endsWith("}") ? wi(e.slice(1, -1)) : null;
}
function Oi(e) {
	if (/json/i.test(e.contentType)) {
		let t = JSON.parse(e.body);
		if (!t || typeof t != "object" || !("document" in t) || typeof t.document != "string") throw Error();
		return ("head" in t && typeof t.head == "string" ? t.head : "") + t.document;
	}
	return e.body;
}
function ki(e) {
	return "value" in e ? e.value : R(e).map(ki).join("");
}
function Ai(e, t) {
	let n = q(Oi(e)), r = [];
	for (let e of B(n, (e) => e.tagName === "script" && !z(e, "src"))) {
		let t = Ci(ki(e));
		if (t.length > 1e5) return null;
		let n = /\bvar\s+upload\s*=\s*new\s+SWFUpload\s*\(\s*\{/g;
		for (; n.exec(t);) {
			let e = "", i = !1, a = 1, o = n.lastIndex;
			for (; o < t.length; o++) {
				let n = t[o];
				if (e) i ? i = !1 : n === "\\" ? i = !0 : n === e && (e = "");
				else if (n === "\"" || n === "'") e = n;
				else if (n === "{" && a++, n === "}" && !--a) break;
			}
			if (a || !/^\s*\)/.test(t.slice(o + 1))) return null;
			let s = wi(t.slice(n.lastIndex, o));
			if (!s) return null;
			r.push(s), n.lastIndex = o + 1;
		}
	}
	if (r.length !== 1) return null;
	let i = r[0], a = Di(i.get("post_params")), o = Di(i.get("custom_settings"));
	if (!a || !o || Ti(a.get("uid")) !== t.account.id || a.size !== 2 || Ti(o.get("uploadSource")) !== "forum" || Ti(o.get("uploadType")) !== "attach") return null;
	for (let e of ["file_upload_limit", "file_queue_limit"]) if (i.has(e) && Ei(i.get(e)) !== 0) return null;
	let s = Ti(a.get("hash")), c = Ti(i.get("upload_url")), l = Ti(i.get("file_types")), u = Ei(Ti(i.get("file_size_limit")) ?? void 0);
	if (!s || !c || !l || u === null || !(/^(?:\*\.[a-z0-9]+)(?:;\*\.[a-z0-9]+)*$/i.test(l) || l === "*.*")) return null;
	let d = new URL(c, e.url), f = new URL(e.url).origin;
	if (d.origin !== f || d.pathname !== "/misc.php" || d.hash || d.username || d.password || d.searchParams.size !== 4 || d.searchParams.get("mod") !== "swfupload" || d.searchParams.get("action") !== "swfupload" || d.searchParams.get("operation") !== "upload" || d.searchParams.get("fid") !== t.board.id) return null;
	let p = (e) => o.has(e) ? Ei(o.get(e)) : void 0, m = p("maxSizePerDay"), h = p("maxAttachNum");
	if (m === null || h === null) return null;
	let g = Di(o.get("filterType"));
	if (o.has("filterType") && !g) return null;
	let _ = /* @__PURE__ */ new Map();
	for (let [e, t] of g ?? []) {
		let n = Ei(t);
		if (n === null || !/^\w+$/.test(e)) return null;
		_.set(e.toLowerCase(), n);
	}
	return {
		url: d.href,
		hash: s,
		types: l.toLowerCase().split(";"),
		maxBytes: u === 0 ? void 0 : u * 1024,
		daily: m,
		count: h,
		extensionLimits: _
	};
}
function ji(e, t, n = "json") {
	let r = new URL("/forum.php", t);
	for (let [t, i] of Object.entries({
		mod: "post",
		action: e.editTarget || e.draft ? "edit" : e.replyTarget ? "reply" : "newthread",
		fid: e.board.id,
		...n === "json" ? { tsdmapp: "json" } : {},
		...e.editTarget || e.draft ? {
			tid: (e.editTarget ?? e.draft).threadId,
			pid: (e.editTarget ?? e.draft).postId
		} : e.replyTarget ? {
			tid: e.replyTarget.threadId,
			...e.replyTarget.postId ? { reppost: e.replyTarget.postId } : {}
		} : {}
	})) r.searchParams.set(t, i);
	return r.href;
}
async function Mi(e, t, n, r) {
	if (!/^[1-9]\d*$/.test(n)) return null;
	let i = new URL("/forum.php", r);
	for (let [e, r] of Object.entries({
		mod: "ajax",
		action: "attachlist",
		aids: n,
		fid: t.board.id,
		inajax: "1",
		ajaxtarget: "attachlist"
	})) i.searchParams.set(e, r);
	let a = await e.request(i.href, { fresh: !0 });
	if (a.status !== 200 || a.url !== i.href || a.redirect === "followed" || !/^(?:text|application)\/xml(?:;|$)/i.test(a.contentType)) return null;
	let o = /^\s*(?:<\?xml[^>]*>\s*)?<root>\s*<!\[CDATA\[([\s\S]*)\]\]>\s*<\/root>\s*$/.exec(a.body);
	if (!o) return null;
	let s = q(o[1]), c = B(s, (e) => [
		"input",
		"select",
		"textarea"
	].includes(e.tagName)), l = B(s, (e) => z(e, "onclick").includes("insertAttach"));
	if (l.length !== 1) return null;
	let u = /^\s*insertAttach(img)?Tag\(\s*(['"])([1-9]\d*)\2\s*\)\s*;?\s*([\s\S]*)$/.exec(z(l[0], "onclick"));
	if (!u || u[3] !== n) return null;
	let d = u[4].trim();
	if (d && !/^doane\(event\)\s*;?$/.test(d) && !RegExp("^hideMenu\\(\\s*(['\"])attach_preview_" + n + "_menu\\1\\s*\\)\\s*;\\s*doane\\(event\\)\\s*;?$").test(d)) return null;
	let f = u[1] ? "attachimg" : "attach", p = [];
	for (let e of c) {
		let t = z(e, "name");
		if (!RegExp("^attachnew\\[" + n + "\\]\\[(description|readperm|price)\\]$").test(t) || p.some((e) => e.name === t) || z(e, "form") || e.attrs.some((e) => e.name === "disabled")) return null;
		let r = B(e, (e) => e.tagName === "option"), i = r.find((e) => e.attrs.some((e) => e.name === "selected")) ?? r[0];
		p.push({
			name: t,
			value: i ? i.attrs.some((e) => e.name === "value") ? z(i, "value") : W(i) : e.tagName === "textarea" ? W(e) : z(e, "value"),
			disabled: !1
		});
	}
	return p.length === 3 && [
		"description",
		"readperm",
		"price"
	].every((e) => p.some((t) => t.name === `attachnew[${n}][${e}]`)) ? {
		fields: p,
		referenceKind: f
	} : null;
}
async function Ni(e, t, n) {
	let r = (t.uploads ?? []).filter((e) => e.status !== "associated" && e.status !== "removed");
	if (r.some((e) => e.status !== "uploaded" || !e.serverId)) return null;
	let i = [];
	for (let a of r) {
		let r = await Mi(e, t, a.serverId, new URL(n.url).origin);
		if (!r || r.referenceKind !== a.referenceKind || JSON.stringify(r.fields) !== JSON.stringify(a.fields)) return null;
		i.push(...r.fields);
	}
	return i;
}
function Pi(e) {
	return async (t) => {
		let n = e.generation(), r = { kind: "unknown" }, i = (t) => ({
			account: r,
			generation: e.generation(),
			accountVerified: !1,
			usableKeys: [],
			message: t
		});
		if (!["reply", "quick-quote"].includes(t.action) || !t.replyTarget || t.editTarget || t.draft) return i("Only ordinary reply attachment intent can be checked here.");
		let a = ji(t, e.origin, "native"), o = async () => {
			let i = await e.transport.request(a, { fresh: !0 }), o = Z(i, a, t.board.id, void 0, t.replyTarget);
			return r = o.account, e.observe(r), n === e.generation() && o.kind === "prepared" && r.kind === "member" && r.id === t.account.id && !!Ai(i, t);
		};
		try {
			if (!await o()) return i("The current account, permission or attachment form is unavailable.");
			let a = [];
			for (let n of t.uploads ?? []) {
				if (!["uploaded", "associated"].includes(n.status) || !n.serverId || n.ownerId !== t.account.id) continue;
				let r = await Mi(e.transport, t, n.serverId, e.origin);
				r && r.referenceKind === n.referenceKind && JSON.stringify(r.fields) === JSON.stringify(n.fields) && a.push(n.key);
			}
			return await o() ? {
				account: r,
				generation: n,
				accountVerified: !0,
				usableKeys: a,
				message: ""
			} : i("The account or form changed while checking attachment intent.");
		} catch {
			return i("Attachment usability could not be verified. Retained intent was not changed.");
		}
	};
}
function Fi(e) {
	return async (t, n, r, i, a) => {
		let o = !1, s = (e) => ({
			kind: o ? "uncertain" : "not-sent",
			message: e
		});
		if (!e.transport.upload) return s("This host cannot upload files.");
		let c = new Uint8Array(n.bytes);
		if (!n.name || [...n.name].some((e) => e.charCodeAt(0) < 32 || e === "/" || e === "\\") || !c.length) return s("Choose a nonempty file with an ordinary filename.");
		let l = e.generation();
		try {
			let u = ji(t, e.origin, "native"), d = await e.transport.request(u, { fresh: !0 }), f = Z(d, u, t.board.id, t.editTarget ?? t.draft, t.replyTarget);
			if (e.observe(f.account), i.aborted || l !== e.generation() || f.kind !== "prepared" || f.account.kind !== "member" || f.account.id !== t.account.id) return s("The original account, permission or current form is unavailable. Nothing was uploaded.");
			let p = Ai(d, t);
			if (!p) return s("Current upload limits or authorization are unavailable. Nothing was uploaded.");
			let m = /\.([^.]+)$/.exec(n.name)?.[1]?.toLowerCase();
			if (!m || !p.types.includes("*.*") && !p.types.includes("*." + m)) return s("The current form does not permit this file type.");
			let h = p.extensionLimits.get(m);
			if (p.maxBytes !== void 0 && c.length > p.maxBytes || h && c.length > h) return s("The file exceeds the current size limit.");
			if (p.count !== void 0 && p.count < 1 || p.daily !== void 0 && c.length >= p.daily) return s("The current attachment count or daily quota is exhausted.");
			if (a && (!await a.check() || !a.current())) return s("Local writing or recovery changed during preflight. Nothing was uploaded.");
			if (i.aborted || l !== e.generation()) return s("Upload cancelled before sending.");
			o = !0;
			let g = await e.transport.upload(p.url, [
				{
					name: "uid",
					value: t.account.id
				},
				{
					name: "hash",
					value: p.hash
				},
				{
					name: "filetype",
					value: n.type
				},
				{
					name: "size",
					value: String(c.length)
				}
			], {
				...n,
				bytes: c
			}, r, i);
			if (i.aborted || l !== e.generation()) return s("Upload may have reached the forum. Nothing will be retried automatically.");
			if (g.url !== p.url || g.redirect === "followed" || g.status !== 200 || !/^(?:text\/plain|text\/html)(?:;|$)/i.test(g.contentType)) return s("Upload outcome is uncertain. Check the native attachment list before considering another upload.");
			if (/^(?:0|-[1-9]\d*)$/.test(g.body)) return {
				kind: "rejected",
				message: "The forum refused this upload."
			};
			if (!/^[1-9]\d{0,15}$/.test(g.body)) return s("Upload outcome is uncertain. No automatic retry.");
			if (t.uploadedReferences.includes(g.body)) return {
				kind: "uncertain",
				id: g.body,
				message: "The forum returned an existing attachment ID. A new independent upload was not established."
			};
			let _ = await Mi(e.transport, t, g.body, e.origin);
			if (!_ || l !== e.generation()) return {
				kind: "uncertain",
				id: g.body,
				message: "Upload accepted, but current attachment controls could not be verified. The upload is not confirmed associated."
			};
			let v = Z(await e.transport.request(u, { fresh: !0 }), u, t.board.id, t.editTarget ?? t.draft, t.replyTarget);
			if (e.observe(v.account), i.aborted || l !== e.generation() || v.kind !== "prepared" || v.account.kind !== "member" || v.account.id !== t.account.id) return {
				kind: "uncertain",
				id: g.body,
				message: "Account changed after upload. The original account may own this file; it was not adopted into current writing."
			};
			let y = await crypto.subtle.digest("SHA-256", c), b = Array.from(new Uint8Array(y), (e) => e.toString(16).padStart(2, "0")).join("");
			return {
				kind: "uploaded",
				id: g.body,
				..._,
				sha256: b
			};
		} catch {
			return s("Upload interrupted. It may already be stored; no upload was repeated.");
		}
	};
}
function Ii(e) {
	let t = /* @__PURE__ */ new Set();
	return async (n, r, i = !1, a) => {
		let o = !1, s = (e) => ({
			kind: o || i ? "uncertain" : "not-sent",
			message: e
		}), c = n.account.id + ":" + r;
		if (!/^[1-9]\d*$/.test(r) || !n.uploads?.some((e) => e.serverId === r) || !i && t.has(c)) return s("This removal is unavailable or already attempted. Check its original result.");
		let l = e.generation();
		try {
			let u = ji(n, e.origin), d = await e.transport.request(u, { fresh: !0 }), f = Z(d, u, n.board.id, n.editTarget ?? n.draft, n.replyTarget);
			if (e.observe(f.account), l !== e.generation() || f.kind !== "prepared" || f.account.kind !== "member" || f.account.id !== n.account.id) return s("Original account or current removal permission is unavailable.");
			if (!i) {
				if (!f.prepared.uploadedReferences.includes(r) && !await Mi(e.transport, n, r, e.origin)) return s("The current attachment could not be established. Nothing was removed.");
				if (l !== e.generation()) return s("The account changed before removal. Nothing was removed.");
				let i = B(q(Oi(d)), (e) => e.tagName === "form" && z(e, "id") === "postform");
				if (i.length !== 1) return s("Current removal form is unavailable.");
				let u = B(i[0], (e) => z(e, "name") === "formhash");
				if (u.length !== 1 || !z(u[0], "value")) return s("Current removal token is unavailable.");
				let p = new URL("/forum.php", e.origin);
				for (let [e, t] of Object.entries({
					mod: "ajax",
					action: "deleteattach",
					inajax: "yes",
					formhash: z(u[0], "value"),
					tid: (n.editTarget ?? n.draft)?.threadId ?? "0",
					pid: (n.editTarget ?? n.draft)?.postId ?? "0",
					"aids[]": r
				})) p.searchParams.set(e, t);
				if (a && (!await a.check() || !a.current())) return s("Local writing or recovery changed during preflight. Nothing was removed.");
				if (l !== e.generation()) return s("The account changed before removal. Nothing was removed.");
				t.add(c), o = !0;
				try {
					await e.transport.request(p.href, { fresh: !0 });
				} catch {}
			}
			let p = Z(await e.transport.request(u, { fresh: !0 }), u, n.board.id, n.editTarget ?? n.draft, n.replyTarget);
			if (e.observe(p.account), l !== e.generation() || p.kind !== "prepared" || p.account.kind !== "member" || p.account.id !== n.account.id || p.prepared.uploadedReferences.includes(r)) return s("Removal is uncertain. No removal was repeated.");
			let m = new URL("/forum.php", e.origin);
			for (let [e, t] of Object.entries({
				mod: "ajax",
				action: "attachlist",
				aids: r,
				fid: n.board.id,
				inajax: "1",
				ajaxtarget: "attachlist"
			})) m.searchParams.set(e, t);
			let h = await e.transport.request(m.href, { fresh: !0 });
			return l !== e.generation() || h.url !== m.href || h.status !== 200 || h.redirect === "followed" || !/^(?:text|application)\/xml(?:;|$)/i.test(h.contentType) || !/^\s*(?:<\?xml[^>]*>\s*)?<root>\s*<!\[CDATA\[\s*\]\]>\s*<\/root>\s*$/.test(h.body) ? s("Removal is uncertain: current attachment absence could not be verified.") : {
				kind: "removed",
				message: "Server file removal verified. Source references are separate; remove any remaining tag before saving.",
				latest: {
					...p.prepared,
					...n.draft ? { draft: Si(n.draft, r) } : {}
				}
			};
		} catch {
			return s("Removal check was interrupted. No removal was repeated.");
		}
	};
}
//#endregion
//#region src/forum-client/mentions.ts
async function Li(e, t, n) {
	let r = (t, n = "invalid") => ({
		kind: n,
		message: t,
		account: e.account(),
		generation: e.generation()
	});
	if (!n.trim() || n.length > 100) return r("Enter a person name or UID to resolve.");
	if (t.action === "edit-post" && !t.editTarget) return r("The original edit target is unavailable.");
	let i = t.action === "edit-post" ? t.editTarget : t.action === "new-thread" ? t.draft : void 0;
	if (i && ![i.threadId, i.postId].every((e) => /^[1-9]\d*$/.test(e))) return r("The original edit target is unavailable.");
	let a = e.generation(), o = new URL("/forum.php", e.origin);
	Object.entries({
		mod: "post",
		action: i ? "edit" : t.replyTarget ? "reply" : "newthread",
		fid: t.board.id,
		...i ? {
			tid: i.threadId,
			pid: i.postId
		} : t.replyTarget ? {
			tid: t.replyTarget.threadId,
			...t.replyTarget.postId ? { reppost: t.replyTarget.postId } : {}
		} : {}
	}).forEach(([e, t]) => o.searchParams.set(e, t));
	async function s() {
		let n = await e.transport.request(o.href, { fresh: !0 });
		if (e.generation() !== a) throw Error("stale");
		let r = Z(n, o.href, t.board.id, i, t.replyTarget);
		if (e.observe(r.account), e.generation() !== a || r.account.kind !== "member" || r.account.id !== t.account.id) throw Error("stale");
		if (r.kind !== "prepared") throw Error("invalid");
		let s = n.body;
		if (/json/i.test(n.contentType)) {
			let e = JSON.parse(s);
			if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error("invalid");
			s = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document;
		}
		let c = B(q(s), (e) => e.tagName === "script").map((e) => R(e).map(W).join("")).flatMap((e) => {
			let t = /^\s*window\.ATPLUS\s*=\s*(\{[^;]*\})\s*;?\s*$/.exec(e);
			return t ? [t[1]] : [];
		});
		if (c.length !== 1) throw Error("invalid");
		let l = JSON.parse(c[0]);
		if (!l || typeof l != "object" || !("api" in l) || typeof l.api != "string" || !("login" in l) || l.login !== 1 || !("use" in l) || l.use !== 1) throw Error("invalid");
		let u = new URL(l.api, e.origin);
		if (u.origin !== e.origin || u.pathname !== "/plugin.php" || u.search !== "?id=atplus:search" || u.hash) throw Error("invalid");
		return u.href;
	}
	try {
		let t = await s(), r = await e.transport.request(t, {
			method: "POST",
			body: new URLSearchParams({
				op: "search",
				q: n.trim()
			}).toString(),
			fresh: !0
		});
		if (e.generation() !== a) throw Error("stale");
		if (r.status !== 200 || new URL(r.url).origin !== e.origin || !/^application\/json(?:;|$)/i.test(r.contentType)) throw Error("invalid");
		let i = JSON.parse(r.body);
		if (!i || typeof i != "object" || !("ok" in i) || ![!0, 1].includes(i.ok) || !("list" in i) || !Array.isArray(i.list) || i.list.length > 100) throw Error("invalid");
		let o = i.list.map((e) => {
			if (!e || typeof e != "object" || !("uid" in e) || !("username" in e) || typeof e.username != "string" || !e.username.trim() || /[\r\n\u2063\u2064]/.test(e.username) || typeof e.uid != "string" && typeof e.uid != "number" || !/^[1-9]\d*$/.test(String(e.uid))) throw Error("invalid");
			return {
				id: String(e.uid),
				name: e.username
			};
		});
		if (new Set(o.map((e) => e.id)).size !== o.length || await s() !== t) throw Error("invalid");
		return {
			kind: "people",
			people: o,
			generation: a,
			account: e.account()
		};
	} catch (e) {
		return r(e instanceof Error && e.message === "stale" ? "The account changed during mention lookup. Resolve the person again." : "The current forum mention service could not resolve this person. Plain text was preserved.", e instanceof Error && e.message === "stale" ? "stale" : "network");
	}
}
async function Ri(e, t) {
	for (let n of t.mentions ?? []) {
		if (!t.source.includes(`@\u2063${n.name}\u2063`)) continue;
		let r = await Li(e, t, n.name);
		if (r.kind !== "people" || !r.people.some((e) => e.id === n.id && e.name === n.name)) return !1;
	}
	return !0;
}
//#endregion
//#region src/forum-client/hongbao.ts
function zi(e) {
	if (!e.redPacket) return !0;
	let t = e.options.filter((e) => e.name.startsWith("hb_")), n = (e) => t.find((t) => t.name === e)?.value ?? "";
	if (t.length !== 8 || new Set(t.map((e) => e.name)).size !== 8) return !1;
	for (let e of t) if (e.disabled || e.maxLength !== null && e.value.length > e.maxLength || e.kind === "select" && !e.choices.some((t) => t.value === e.value && !t.disabled) || ["hb_total", "hb_shares"].includes(e.name) && !Bi(e)) return !1;
	let r = Vi(e);
	return r !== null && Number(n("hb_total")) >= Number(n("hb_shares")) * r;
}
function Bi(e) {
	let t = Number(e.value), n = Number(e.minimum), r = Number(e.step);
	return /^\d+$/.test(e.value) && Number.isSafeInteger(t) && Number.isSafeInteger(n) && n >= 1 && Number.isSafeInteger(r) && r >= 1 && t >= n && (t - n) % r === 0 && (e.maximum === void 0 || Number.isSafeInteger(Number(e.maximum)) && t <= Number(e.maximum));
}
function Vi(e) {
	let t = e.redPacket?.hints.map((e) => /每份至少\s*(\d+)/.exec(e)?.[1]).filter(Boolean) ?? [];
	return t.length === 1 && Number.isSafeInteger(Number(t[0])) ? Number(t[0]) : null;
}
async function Hi(e, t, n) {
	let r = {
		state: "unknown",
		conditions: [],
		credit: "unknown"
	}, i = new URL("/plugin.php", t);
	i.searchParams.set("id", "hongbao:open"), i.searchParams.set("tid", n);
	try {
		let a = await e.request(i.href, { fresh: !0 });
		if (a.status !== 200 || new URL(a.url).origin !== t || !/^application\/json(?:;|$)/i.test(a.contentType)) return r;
		let o = JSON.parse(a.body);
		if (!o || typeof o != "object" || !("ok" in o)) return r;
		if (o.ok === !1 && "error" in o && o.error === "這裡沒有紅包") return {
			...r,
			state: "absent"
		};
		if (o.ok !== !0 || !("tid" in o) || String(o.tid) !== n || !("state" in o) || typeof o.state != "string" || ![
			"open",
			"claimed",
			"done",
			"withdrawn",
			"expired",
			"closed",
			"unknown"
		].includes(o.state)) return r;
		let s = [];
		for (let [e, t] of [
			["cond", "Reply required"],
			["haspw", "Passphrase present"],
			["appoint", "Designated recipients present"]
		]) {
			if (!(e in o)) return r;
			let n = Reflect.get(o, e);
			if (n !== 0 && n !== 1) return r;
			s.push(`${t}: ${n === 1 ? "yes" : "no"}`);
		}
		return !("splitmode" in o) || ![1, 2].includes(Number(o.splitmode)) || !("bless" in o) || typeof o.bless != "string" ? r : (s.push(`Split: ${Number(o.splitmode) === 1 ? "random" : "equal"}`, `Greeting: ${o.bless}`), {
			state: o.state,
			conditions: s,
			credit: "unknown"
		});
	} catch {
		return r;
	}
}
async function Ui(e, t, n) {
	let r = {
		state: "unavailable",
		rows: []
	}, i = new URL("/home.php?mod=spacecp&ac=credit&op=log", t);
	try {
		let a = await e.request(i.href, { fresh: !0 });
		if (a.status !== 200 || new URL(a.url).origin !== t || !/^text\/html(?:;|$)/i.test(a.contentType)) return {
			ledger: r,
			account: { kind: "unknown" }
		};
		let o = q(a.body), s = X(o, a.url);
		if (s.kind !== "member" || s.id !== n) return {
			ledger: r,
			account: s
		};
		let c = B(o, (e) => e.tagName === "table" && U(e, "dt")).find((e) => {
			let t = B(e, (e) => e.tagName === "th").map(G);
			return t.length === 5 && /操作/.test(t[0]) && /积分变更|積分變更/.test(t[1]) && /变更时间|變更時間/.test(t[4]);
		});
		if (!c) return {
			ledger: r,
			account: s
		};
		let l = [];
		for (let e of B(c, (e) => e.tagName === "tr")) {
			let n = R(e).filter((e) => "tagName" in e && e.tagName === "td");
			if (n.length !== 5) continue;
			let r = B(n[0], (e) => e.tagName === "a")[0], a = r && K(z(r, "href"), i.href);
			if (!a) continue;
			let o = new URL(a), s = o.searchParams.get("optype");
			o.origin === t && o.pathname === "/home.php" && o.searchParams.get("mod") === "spacecp" && o.searchParams.get("ac") === "credit" && o.searchParams.get("op") === "log" && [
				"HBS",
				"HBR",
				"HBG"
			].includes(s ?? "") && (s === "HBS" || s === "HBR" || s === "HBG") && l.push({
				operation: s,
				change: G(n[1]),
				details: G(n[3]),
				time: G(n[4])
			});
		}
		return {
			ledger: {
				state: "observed",
				rows: l
			},
			account: s
		};
	} catch {
		return {
			ledger: r,
			account: { kind: "unknown" }
		};
	}
}
async function Wi(e, t) {
	if (!t.redPacket) return !0;
	let n = t.options.find((e) => e.name === "hb_appoint")?.value ?? "";
	if (!n.trim()) return !0;
	let r = n.split(",").map((e) => e.trim());
	if (r.some((e) => !e || /[\r\n]/.test(e)) || new Set(r).size !== r.length) return !1;
	for (let n of r) {
		let r = await Li(e, t, n);
		if (r.kind !== "people" || r.people.filter((e) => e.name === n).length !== 1) return !1;
	}
	return !0;
}
//#endregion
//#region src/forum-client/writing-validation.ts
function Gi(e, t = e) {
	let n = [];
	!e.replyTarget && e.titleAvailable !== !1 && !e.title.trim() ? n.push({
		field: "title",
		code: "required"
	}) : /[\r\n]/.test(e.title) && n.push({
		field: "title",
		code: "single-line"
	}), e.source.trim() || n.push({
		field: "source",
		code: "required"
	});
	for (let r of [...e.category ? [e.category] : [], ...e.options]) {
		let i = [...t.category ? [t.category] : [], ...t.options].find((e) => e.name === r.name);
		if (r.disabled) continue;
		let a = r === e.category ? "category" : "option";
		!i || i.disabled || r.kind === "select" && !i.choices.some((e) => e.value === r.value && !e.disabled) ? n.push({
			field: a,
			name: r.name,
			code: "unavailable"
		}) : i.maxLength !== null && r.value.length > i.maxLength ? n.push({
			field: a,
			name: r.name,
			code: "too-long",
			limit: i.maxLength
		}) : e.redPacket && ["hb_total", "hb_shares"].includes(r.name) && !Bi({
			...i,
			value: r.value
		}) && n.push({
			field: a,
			name: r.name,
			code: "native-limit"
		});
	}
	if (e.redPacket && !n.some((e) => e.name === "hb_total" || e.name === "hb_shares")) {
		let r = Vi(t), i = (t) => Number(e.options.find((e) => e.name === t)?.value);
		r !== null && i("hb_total") < i("hb_shares") * r && n.push({
			field: "option",
			name: "hb_total",
			code: "packet-minimum"
		});
	}
	return n;
}
//#endregion
//#region src/forum-client/post-response.ts
function Ki(e) {
	if (e.status !== 200 || e.redirect === "followed" || !/^(?:text|application)\/xml(?:;|$)/i.test(e.contentType) || e.body.length > 262144 || /<!DOCTYPE|<!ENTITY/i.test(e.body)) return null;
	let t = /^\s*(?:<\?xml[^?]*\?>\s*)?<root>\s*<!\[CDATA\[([\s\S]*)\]\]>\s*<\/root>\s*$/.exec(e.body);
	if (!t || t[1].includes("]]>") || t[1].includes("<![CDATA[")) return null;
	let n = B(q(t[1]), (e) => e.tagName === "script");
	if (n.length !== 1 || n[0].attrs.some((e) => !["type", "reload"].includes(e.name)) || z(n[0], "type") && z(n[0], "type") !== "text/javascript") return null;
	let r = R(n[0]).map((e) => "value" in e ? e.value : "").join(""), i = 0, a = () => {
		for (; /\s/.test(r[i] ?? "") && i < r.length;) i++;
	}, o = (e) => {
		if (a(), !r.startsWith(e, i)) throw Error();
		i += e.length;
	}, s = () => {
		a();
		let e = /^[A-Za-z_$][\w$]*/.exec(r.slice(i));
		if (!e) throw Error();
		return i += e[0].length, e[0];
	}, c = () => {
		a();
		let e = r[i++];
		if (e !== "'" && e !== "\"") throw Error();
		let t = "";
		for (; i < r.length;) {
			let n = r[i++];
			if (n === e) return t;
			if (!n || /[\r\n\u2028\u2029]/.test(n)) throw Error();
			if (n !== "\\") {
				t += n;
				continue;
			}
			let a = r[i++], o = {
				n: "\n",
				r: "\r",
				t: "	",
				b: "\b",
				f: "\f",
				v: "\v",
				"\\": "\\",
				"'": "'",
				"\"": "\"",
				"/": "/"
			};
			if (a && Object.hasOwn(o, a)) t += o[a];
			else if (a === "x" || a === "u") {
				let e = a === "x" ? 2 : 4, n = r.slice(i, i + e);
				if (n.length !== e || !/^[0-9a-f]+$/i.test(n)) throw Error();
				t += String.fromCharCode(Number.parseInt(n, 16)), i += e;
			} else throw Error();
		}
		throw Error();
	};
	try {
		let e = "";
		if (a(), r.startsWith("if", i)) {
			if (o("if"), o("("), s() !== "typeof" || (e = s(), a(), o(r.startsWith("===", i) ? "===" : "=="), c() !== "function")) return null;
			o(")"), o("{");
		}
		let t = s();
		if (![
			"succeedhandle_post",
			"errorhandle_post",
			"succeedhandle_"
		].includes(t) || t === "succeedhandle_" && e !== t || e && e !== t) return null;
		let n = t !== "errorhandle_post";
		o("(");
		let l = [c()];
		o(","), n && (l.push(c()), o(",")), o("{");
		let u = Object.create(null);
		if (a(), r[i] !== "}") for (let e = 0;; e++) {
			if (e > 100) return null;
			let t = c();
			if (Object.hasOwn(u, t)) return null;
			if (o(":"), u[t] = c(), a(), r[i] !== ",") break;
			o(",");
		}
		return o("}"), o(")"), a(), r[i] === ";" && o(";"), e && (o("}"), a(), r[i] === ";" && o(";")), a(), i === r.length ? {
			success: n,
			values: l,
			fields: u
		} : null;
	} catch {
		return null;
	}
}
//#endregion
//#region src/forum-client/thread-verification.ts
var qi = (e) => [...e.category ? [e.category] : [], ...e.options];
function Ji(e) {
	if (e.kind !== "checkbox") return null;
	switch (e.name) {
		case "addfeed":
		case "adddynamic":
		case "adddynamic_doing": return e.name;
		default: return null;
	}
}
function Yi(e) {
	return e.options.flatMap((e) => {
		let t = Ji(e);
		return t ? [e.checked ? {
			name: t,
			requested: !0,
			included: !e.disabled,
			outcome: "unknown"
		} : {
			name: t,
			requested: !1,
			included: !1,
			outcome: "not-requested"
		}] : [];
	});
}
function Xi(e, t) {
	if (e.title !== t.title || e.source !== t.source || e.uploadedReferences.some((e) => !t.uploadedReferences.includes(e))) return null;
	let n = [];
	for (let r of e.attachmentFields ?? []) {
		let i = t.attachmentFields?.filter((e) => e.name === r.name) ?? [];
		if (i.length !== 1 || e.attachmentFields.filter((e) => e.name === r.name).length !== 1 || i[0].disabled !== r.disabled) return null;
		let a = i[0];
		if (a.value === r.value) continue;
		let o = /^attachnew\[([1-9]\d*)\]\[price\]$/.exec(r.name);
		if (!o || r.disabled || r.value !== "" || a.value !== "0" || !e.uploadedReferences.includes(o[1])) return null;
		n.push({
			name: r.name,
			submitted: "",
			stored: "0"
		});
	}
	let r = [];
	for (let n of qi(e)) {
		if (Ji(n) || e.redPacket && n.name.startsWith("hb_")) continue;
		let i = qi(t).find((e) => e.name === n.name);
		if (!i || i.kind !== n.kind || i.checked !== n.checked) return null;
		if (i.value !== n.value) {
			if (n.name === "price" && n.kind === "text" && !n.disabled && n.value === "" && i.value === "0") r.push({
				name: "price",
				submitted: "",
				stored: "0"
			});
			else return null;
		}
	}
	return {
		stored: "verified",
		normalizations: r,
		...n.length ? { attachmentNormalizations: n } : {},
		creationEffects: Yi(e)
	};
}
function Zi(e) {
	let t = e.source, n = /* @__PURE__ */ new Set();
	for (let r of e.mentions ?? []) {
		if (n.has(r.name) || !/^[1-9]\d*$/.test(r.id) || !r.name || /[[\]\r\n\u2063\u2064]/.test(r.name)) return null;
		n.add(r.name), t = t.replaceAll(`@\u2063${r.name}\u2063`, `[url=home.php?mod=space&uid=${r.id}]@${r.name}[/url]`);
	}
	return /[\u2063\u2064]/.test(t) ? null : t;
}
function Qi(e, t) {
	if (e.action !== "new-thread" || e.draft || e.replyTarget) return null;
	let n = Xi(e, t);
	if (n) return n;
	let r = Zi(e);
	return r === null ? null : Xi({
		...e,
		source: r
	}, t);
}
function $i(e, t, n) {
	if (!e.replyTarget || !["reply", "quick-quote"].includes(e.action) || t && (t.account.id !== e.account.id || t.account.name !== e.account.name || t.board.id !== e.board.id || JSON.stringify(t.replyTarget) !== JSON.stringify(e.replyTarget)) || n.account.id !== e.account.id || n.account.name !== e.account.name || n.board.id !== e.board.id || JSON.stringify(n.replyTarget) !== JSON.stringify(e.replyTarget)) return null;
	let r = Zi(e);
	if (r === null) return null;
	if (!t) return Xi({
		...e,
		source: r
	}, n);
	let i = n.source.startsWith(`${t.source}\n\n[quote]`), a = `${t.source}\n\n${i ? "[quote]" : "[hr]\n"}[b]${e.account.name} 补充了以下内容 (`;
	if (!n.source.startsWith(a)) return null;
	let o = n.source.slice(a.length), s = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})\)\[\/b\]\n/.exec(o);
	if (!s) return null;
	let [c, l, u, d, f] = s.slice(1).map(Number), p = new Date(Date.UTC(c, l - 1, u, d, f));
	return c < 1e3 || p.getUTCFullYear() !== c || p.getUTCMonth() + 1 !== l || p.getUTCDate() !== u || p.getUTCHours() !== d || p.getUTCMinutes() !== f || o.slice(s[0].length) !== r + (i ? "[/quote]" : "") || !Xi({
		...t,
		source: n.source
	}, n) ? null : Xi({
		...e,
		source: n.source
	}, n);
}
//#endregion
//#region src/forum-client/publish-thread.ts
var ea = (e, t) => JSON.stringify(e) === JSON.stringify(t), ta = (e) => e.kind === "member" ? e.id : null, na = (e) => JSON.parse(JSON.stringify(e)), ra = (e, t) => e.attrs.some((e) => e.name === t);
function ia(e) {
	let t = e.body;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(t)) {
		let e = JSON.parse(t);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		t = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document;
	}
	return q(t);
}
function aa(e) {
	return [...e.category ? [e.category] : [], ...e.options];
}
function oa(e, t) {
	if (ea(e, t)) return !0;
	if (!e || !t) return !1;
	let n = /^目前餘額 (?:0|[1-9]\d*) 天使币$/;
	if (e.hints.filter((e) => n.test(e)).length !== 1 || t.hints.filter((e) => n.test(e)).length !== 1 || e.hints.findIndex((e) => n.test(e)) !== t.hints.findIndex((e) => n.test(e))) return !1;
	let r = (e) => ({
		...e,
		hints: e.hints.map((e) => n.test(e) ? "" : e)
	});
	return ea(r(e), r(t));
}
function sa(e, t) {
	return !!e.existingRedPacket == !!t.existingRedPacket && oa(e.redPacket, t.redPacket) && aa(e).length === aa(t).length && aa(t).every((t) => {
		let n = aa(e).find((e) => e.name === t.name);
		return !n || n.kind !== t.kind || n.disabled !== t.disabled || !ea(n.choices, t.choices) || n.maxLength !== t.maxLength || n.minimum !== t.minimum || n.maximum !== t.maximum || n.step !== t.step ? !1 : t.disabled ? n.value === t.value && n.checked === t.checked : t.kind !== "select" || t.choices.some((e) => e.value === n.value && !e.disabled);
	});
}
function ca(e, t, n = !1, r = [], i) {
	if (!zi(t)) return null;
	let a = ia(e), o = V(a, "postform");
	if (!o) return null;
	let s = K(z(o, "action"), e.url);
	if (!s) return null;
	let c = B(o, (e) => [
		"input",
		"textarea",
		"select",
		"button"
	].includes(e.tagName)), l = t.action === "edit-post" || n && t.draft ? hi(a, o) : [];
	if (!l) return null;
	for (let e of l) c.includes(e) || c.push(e);
	if (B(a, (e) => z(e, "form") === "postform").length || c.some((e) => z(e, "form"))) return null;
	let u = c.filter((e) => z(e, "name") === "formhash");
	if (u.length !== 1 || H(u[0]) || !z(u[0], "value") || c.some((e) => ["subject", "message"].includes(z(e, "name")) && H(e))) return null;
	let d = [], f = t.action === "edit-post" || n && new URL(s).searchParams.get("action") === "edit" ? "editsubmit" : t.replyTarget ? "replysubmit" : "topicsubmit", p = c.filter((e) => z(e, "name") === f && !H(e) && (e.tagName === "button" && ["", "submit"].includes(z(e, "type")) || e.tagName === "input" && z(e, "type") === "submit"));
	if (p.length > 1 || p.some((e) => !["yes", "true"].includes(z(e, "value"))) || !p.length && new URL(s).searchParams.get(f) !== "yes") return null;
	if (p.length && d.push([f, z(p[0], "value")]), n) {
		let e = c.filter((e) => z(e, "name") === "save");
		if (e.length !== 1 || z(e[0], "type") !== "hidden" || z(e[0], "id") !== "postsave" || H(e[0])) return null;
	}
	let m = [
		"rushreplyfrom",
		"rushreplyto",
		"rewardfloor",
		"replylimit",
		"stopfloor",
		"creditlimit"
	];
	if (c.some((e) => z(e, "name") === "rushreply" && ra(e, "checked")) || c.some((e) => m.includes(z(e, "name")) && z(e, "value") !== "")) return null;
	for (let e of c) {
		let r = z(e, "name"), a = z(e, "type").toLowerCase();
		if (!r || H(e) || e.tagName === "button" || [
			"submit",
			"button",
			"reset",
			"image"
		].includes(a)) continue;
		if (a === "file") {
			if (z(e, "value")) return null;
			continue;
		}
		if (["special", "save"].includes(r) && !["", "0"].includes(z(e, "value")) && !(r === "special" && a === "hidden" && (t.redPacket || (t.action === "edit-post" || t.draft) && t.existingRedPacket)) || (t.action === "edit-post" || n) && r === "delattachop" && z(e, "value") !== "0") return null;
		let o = aa(t).find((e) => e.name === r);
		if (["checkbox", "radio"].includes(a) && !(o ? a === "radio" && o.kind === "select" ? z(e, "value") === o.value : o.checked : ra(e, "checked"))) continue;
		let s = n && r === "save" ? n === "save" ? "1" : "" : r === "subject" ? t.title : r === "message" ? t.source : o ? o.value : l.includes(e) ? gi([e])[0].value : e.tagName === "textarea" ? W(e) : e.tagName === "select" ? z(B(e, (e) => e.tagName === "option" && ra(e, "selected"))[0] ?? B(e, (e) => e.tagName === "option")[0] ?? e, "value") : z(e, "value"), c = ra(e, "required") && !s.trim(), u = /^\d+$/.test(z(e, "maxlength")) ? Number(z(e, "maxlength")) : null;
		if (c || u !== null && s.length > u) return (r === "subject" || r === "message" || o) && i?.push({
			field: r === "subject" ? "title" : r === "message" ? "source" : o === t.category ? "category" : "option",
			...o ? { name: r } : {},
			code: c ? "required" : "too-long",
			...!c && u !== null ? { limit: u } : {}
		}), null;
		if (!o && !(n && (/^attachnew\[[1-9]\d*\]\[[a-z_]+\]$/.test(r) || [
			"fid",
			"tid",
			"pid",
			"page",
			"delattachop"
		].includes(r) && a === "hidden")) && ![
			"subject",
			"message",
			"checkbox",
			"rushreply",
			...m
		].includes(r) && !([
			"formhash",
			...t.redPacket || t.existingRedPacket ? ["special", "specialextra"] : [],
			"posttime",
			"wysiwyg",
			"save",
			...t.replyTarget ? [
				"reppid",
				"reppost",
				"noticeauthor",
				"noticeauthormsg",
				"noticetrimstr",
				"handlekey"
			] : []
		].includes(r) && a === "hidden") && !l.includes(e) && (t.action !== "edit-post" || a !== "hidden" || ![
			"fid",
			"tid",
			"pid",
			"page",
			"wysiwyg",
			"delattachop"
		].includes(r) && !/^attachnew\[[1-9]\d*\]\[(?:description|readperm|price)\]$/.test(r))) return null;
		d.push([r, s]);
	}
	for (let e of r) {
		if (d.some(([t]) => t === e.name) || e.disabled) return null;
		d.push([e.name, e.value]);
	}
	let h = new URL(s);
	return h.searchParams.set("inajax", "1"), h.searchParams.delete("tsdmapp"), {
		url: h.href,
		body: new URLSearchParams(d).toString()
	};
}
function la(e, t, n = !1) {
	let r = K(e, t);
	if (!r) return null;
	let i = new URL(r);
	if (i.origin !== t || i.pathname !== "/forum.php" || i.searchParams.get("mod") !== "viewthread" || !/^[1-9]\d*$/.test(i.searchParams.get("tid") ?? "") || [...i.searchParams.keys()].some((e) => ![
		"mod",
		"tid",
		"pid",
		"page",
		"extra"
	].includes(e) || i.searchParams.getAll(e).length !== 1)) return null;
	n && i.searchParams.get("page") === "" && i.searchParams.delete("page");
	let a = i.searchParams.get("pid") || /^#pid([1-9]\d*)$/.exec(i.hash)?.[1];
	return i.searchParams.has("pid") && !/^[1-9]\d*$/.test(i.searchParams.get("pid")) || i.searchParams.has("page") && !/^[1-9]\d*$/.test(i.searchParams.get("page")) || i.hash && (!/^#pid[1-9]\d*$/.test(i.hash) || a && i.hash !== `#pid${a}`) ? null : (i.searchParams.delete("pid"), i.hash = a ? `pid${a}` : "", i.href);
}
function ua(e, t) {
	let n = Ki(e), r = n?.values.join(" ") ?? "";
	if (n?.success && /审核|審核|moderation/i.test(r)) return {
		kind: "moderation",
		message: "The forum reports pending moderation. Public stored source has not been confirmed."
	};
	if (n?.success) {
		let e = la(n.values[0], t, !0);
		if (e) return {
			kind: "candidate",
			url: e,
			message: "The response supplied a candidate. Checking independently…"
		};
	}
	return n && !n.success && /subject_(?:empty|invalid|toolong)|message_(?:empty|toolong)|post_(?:flood|smilies|url|validation)|标题不能为空|標題不能為空|内容不能为空|內容不能為空|验证失败|驗證失敗/.test(r) ? {
		kind: "rejected",
		message: "The forum explicitly refused validation. Nothing is confirmed published."
	} : {
		kind: "unknown",
		message: "The publication outcome is uncertain. Check the original attempt before considering another send."
	};
}
function da(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set();
	async function a(t) {
		if (!t.replyTarget) return null;
		let n = e.generation(), r = new URL("/forum.php", e.origin);
		for (let [e, n] of Object.entries({
			mod: "viewthread",
			tid: t.replyTarget.threadId,
			tsdmapp: "json"
		})) r.searchParams.set(e, n);
		let i = await e.transport.request(r.href, { fresh: !0 });
		if (e.generation() !== n) throw Error("stale");
		let a = oi(i, r.href);
		if (e.observe(a.account), e.generation() !== n || ta(a.account) !== t.account.id || a.kind !== "thread" || !a.thread.parent || new URL(a.thread.parent.url).searchParams.get("fid") !== t.board.id) throw Error("invalid");
		let o = [];
		for (let r of a.thread.posts.filter((e) => e.authorId === t.account.id)) {
			let i = new URL("/forum.php", e.origin);
			for (let [e, n] of Object.entries({
				mod: "post",
				action: "edit",
				fid: t.board.id,
				tid: t.replyTarget.threadId,
				pid: r.id,
				tsdmapp: "json"
			})) i.searchParams.set(e, n);
			let a = await e.transport.request(i.href, { fresh: !0 });
			if (e.generation() !== n) throw Error("stale");
			let s = Z(a, i.href, t.board.id, {
				threadId: t.replyTarget.threadId,
				postId: r.id
			}, t.replyTarget);
			if (e.observe(s.account), e.generation() !== n || ta(s.account) !== t.account.id || s.kind !== "prepared") throw Error("invalid");
			o.push({
				postId: r.id,
				writing: s.prepared
			});
		}
		return {
			pageURL: r.href,
			postIds: a.thread.posts.map((e) => e.id),
			owned: o
		};
	}
	async function o(t, n) {
		let r = (e) => t.status === "confirmed" && t.result ? {
			...t,
			checked: !0,
			message: `Previous stored confirmation retained. This recheck did not verify the current result. ${e}`
		} : {
			...t,
			status: "uncertain",
			checked: !0,
			message: e,
			result: null
		}, i = la(n, e.origin), a = t.publication.submission, o = a.writing;
		if (!i || o.replyTarget && new URL(i).searchParams.get("tid") !== o.replyTarget.threadId) return r("No supported candidate thread URL is available. Enter its thread URL to check this original attempt.");
		let s = e.generation();
		try {
			let n = await e.transport.request(i, { fresh: !0 });
			if (e.generation() !== s) return r("The account changed during result checking. Original writing and possible effects are retained.");
			let c = oi(n, i);
			if (e.observe(c.account), ta(c.account) !== o.account.id) return r("The account changed during result checking. Original writing and possible effects are retained.");
			if (c.kind !== "thread" || c.thread.posts.length < 1) return r("The candidate thread could not be independently read. Publication remains uncertain.");
			let l = c.thread, u = o.replyTarget ? l.posts.filter((e) => e.id === (new URL(i).searchParams.get("pid") || new URL(i).hash.slice(4))) : l.posts.filter((e) => /^1\s*#?$/.test(e.floor));
			if (u.length !== 1 || !o.replyTarget && u[0] !== l.posts[0] || u[0].authorId !== o.account.id || !o.replyTarget && l.title !== o.title || !l.parent || new URL(l.parent.url).searchParams.get("fid") !== o.board.id) return r("Candidate actor, board, title or opening-post identity did not match the submitted revision.");
			let d = u[0], f = new URL("/forum.php", e.origin);
			for (let [e, t] of Object.entries({
				mod: "post",
				action: "edit",
				fid: o.board.id,
				tid: l.id,
				pid: d.id,
				tsdmapp: "json"
			})) f.searchParams.set(e, t);
			let p = e.generation(), m = await e.transport.request(f.href, { fresh: !0 });
			if (e.generation() !== p) return r("The account changed during stored-source readback. Possible publication remains uncertain.");
			let h = Z(m, f.href, o.board.id, {
				threadId: l.id,
				postId: d.id
			}, o.replyTarget);
			if (e.observe(h.account), e.generation() !== p || ta(h.account) !== o.account.id) return r("The account changed during stored-source readback. Possible publication remains uncertain.");
			let g = null;
			if (o.replyTarget && h.kind === "prepared") {
				let e = t.publication.replyBefore?.owned.find((e) => e.postId === d.id)?.writing ?? null;
				if (t = {
					...t,
					replyComparison: {
						postId: d.id,
						before: e,
						observed: na(h.prepared)
					}
				}, g = $i(o, e, h.prepared), e && !g) return r("The returned post existed before sending. Complete before and observed source are retained for comparison; a merged result has not been confirmed.");
			}
			let _ = h.kind === "prepared" ? g ?? (o.replyTarget ? Xi(o, h.prepared) : Qi(o, h.prepared)) : null;
			return _ ? {
				...t,
				status: "confirmed",
				checked: !0,
				candidateURL: i,
				message: `Confirmed stored ${o.replyTarget ? "reply in thread" : "thread"} ${l.id}, post ${d.id}, submitted revision ${a.revision}.`,
				result: {
					threadId: l.id,
					postId: d.id,
					url: `${i.split("#")[0]}#pid${d.id}`,
					verification: _
				}
			} : r("Complete stored source or offered options did not match, or were unavailable. No confirmation is claimed.");
		} catch {
			return r("Independent stored-result readback failed. Publication remains uncertain; no send was repeated.");
		}
	}
	async function s(t, n) {
		let r = await o(t, n);
		if (!t.publication.submission.writing.redPacket) return r;
		let i = la(n, e.origin), a = i && new URL(i).searchParams.get("tid");
		if (!a || ta(e.account()) !== t.publication.submission.writing.account.id) return {
			...r,
			redPacket: {
				state: "unknown",
				conditions: [],
				credit: "unknown"
			}
		};
		let s = e.generation(), c = await Hi(e.transport, e.origin, a), l = await Ui(e.transport, e.origin, t.publication.submission.writing.account.id);
		return l.account.kind !== "unknown" && e.observe(l.account), {
			...r,
			redPacket: s === e.generation() ? {
				...c,
				ledger: l.ledger
			} : {
				state: "unknown",
				conditions: [],
				credit: "unknown"
			}
		};
	}
	return {
		async prepare(r) {
			n.delete(r.contextId);
			for (let [e, n] of t) n.publication.submission.contextId === r.contextId && t.delete(e);
			let i = !1, o = (t, n = "validation") => ({
				kind: n,
				message: t,
				accountVerified: n === "validation" && i,
				account: e.account(),
				generation: e.generation()
			}), s = Gi(r.writing);
			if (s.length) return {
				...o("Correct the highlighted fields before reviewing."),
				validation: {
					source: "local",
					issues: s
				}
			};
			if (!r.contextId || !Number.isSafeInteger(r.revision) || r.revision < 1 || ![
				"new-thread",
				"reply",
				"quick-quote"
			].includes(r.writing.action) || r.writing.action === "new-thread" && r.writing.replyTarget || r.writing.action === "reply" && r.writing.replyTarget?.postId !== null || r.writing.action === "quick-quote" && !/^[1-9]\d*$/.test(r.writing.replyTarget?.postId ?? "") || r.writing.action !== "new-thread" && (!r.writing.replyTarget || !/^[1-9]\d*$/.test(r.writing.replyTarget.threadId)) || r.writing.draft !== void 0 || !/^[1-9]\d*$/.test(r.writing.board.id) || r.writing.action === "new-thread" && !r.writing.title.trim() || !r.writing.source.trim() || /[\r\n]/.test(r.writing.title)) return o("A title, complete source and valid ordinary new-thread revision are required.");
			if (!zi(r.writing)) return o("Red-packet values do not satisfy the current native limits. Review the amount, shares and conditions.");
			r = na(r);
			let c = crypto.randomUUID();
			n.set(r.contextId, c);
			for (let [e, n] of t) n.publication.submission.contextId === r.contextId && t.delete(e);
			let l = na(r.writing), u = new URL("/forum.php", e.origin);
			for (let [e, t] of Object.entries({
				mod: "post",
				action: l.replyTarget ? "reply" : "newthread",
				...l.redPacket ? { specialextra: "hongbao" } : {},
				...l.replyTarget ? {
					tid: l.replyTarget.threadId,
					...l.replyTarget.postId ? { reppost: l.replyTarget.postId } : {}
				} : {},
				fid: l.board.id,
				tsdmapp: "json"
			})) u.searchParams.set(e, t);
			let d = e.generation();
			try {
				let s = await e.transport.request(u.href, { fresh: !0 });
				if (e.generation() !== d || n.get(r.contextId) !== c) return o("The account changed or expired during preparation. Original writing remains paused.", "stale");
				let f = Z(s, u.href, l.board.id, void 0, l.replyTarget);
				if (e.observe(f.account), f.account.kind === "unknown") return o("The current account could not be verified from the preparation response. Check the current account and form again.");
				if (ta(f.account) !== l.account.id) return o("The account changed or expired during preparation. Original writing remains paused.", "stale");
				if (i = !0, f.kind !== "prepared") return o(f.message);
				let p = e.generation();
				if (!await Wi(e, l)) return o("A designated recipient could not be resolved from the current forum identity search.");
				if (!await Ri(e, l)) return o("A selected mention identity changed or could not be revalidated. Resolve the person again.");
				let m = Gi(l, f.prepared);
				if (m.length) return {
					...o("Correct the highlighted fields required by the current native form."),
					validation: {
						source: "form",
						issues: m
					}
				};
				if (!sa(l, f.prepared)) return o("The current native options changed or are unavailable. Review the current form before publication; no values were reset.");
				let h = await Ni(e.transport, l, s);
				if (e.generation() !== p || n.get(r.contextId) !== c) return o("The account or preparation changed during attachment validation. Nothing was sent.", "stale");
				let g = [], _ = h && ca(s, l, !1, h, g);
				if (g.length) return {
					...o("Correct the highlighted fields required by the current native form."),
					validation: {
						source: "form",
						issues: g
					}
				};
				if (!_) return o("The current native form has unsupported successful controls or required values. Nothing was sent.");
				let v = e.generation(), y = await a(l);
				if (e.generation() !== v || n.get(r.contextId) !== c) return o("The account or preparation changed during prior-source observation.", "stale");
				let b = {
					id: c,
					generation: e.generation(),
					submission: na(r),
					...y ? { replyBefore: y } : {}
				};
				return t.set(b.id, {
					publication: na(b),
					request: _
				}), {
					kind: "ready",
					publication: b,
					account: e.account(),
					generation: e.generation()
				};
			} catch {
				return o("Fresh publication preparation failed. Your writing remains here.", "network");
			}
		},
		async publish(n, o) {
			n = na(n), n.publication.submission.writing.redPacket && (n = {
				...n,
				redPacket: {
					state: "unknown",
					conditions: [],
					credit: "unknown"
				}
			});
			let c = t.get(n.publication.id), l = n.publication.submission.contextId, u = (e) => ({
				...n,
				status: "not-sent",
				message: e
			});
			if (!c || !ea(c.publication, n.publication) || n.status !== "pending" || !n.id || r.has(n.id) || i.has(l) || e.generation() !== c.publication.generation || ta(e.account()) !== c.publication.submission.writing.account.id) return u("This preparation, account or attempt is stale or already active. Nothing was sent.");
			r.add(n.id), i.add(l), t.delete(n.publication.id);
			let d = !1;
			try {
				let t = c.publication.submission.writing, r = new URL("/forum.php", e.origin);
				for (let [e, n] of Object.entries({
					mod: "post",
					action: t.replyTarget ? "reply" : "newthread",
					...t.redPacket ? { specialextra: "hongbao" } : {},
					...t.replyTarget ? {
						tid: t.replyTarget.threadId,
						...t.replyTarget.postId ? { reppost: t.replyTarget.postId } : {}
					} : {},
					fid: t.board.id,
					tsdmapp: "json"
				})) r.searchParams.set(e, n);
				if (!await Wi(e, t)) return u("A designated recipient could not be resolved from the current forum identity search.");
				if (!await Ri(e, t)) return u("A selected mention identity changed before send. Nothing was sent.");
				let i = await e.transport.request(r.href, { fresh: !0 });
				if (e.generation() !== c.publication.generation) return u("The account changed or expired before send. Original writing remains retained and paused.");
				let l = Z(i, r.href, t.board.id, void 0, t.replyTarget);
				if (e.observe(l.account), e.generation() !== c.publication.generation || ta(l.account) !== t.account.id) return u("The account changed or expired before send. Original writing remains retained and paused.");
				if (l.kind !== "prepared" || !sa(t, l.prepared)) return u("The current form changed before send. Nothing was sent; review again.");
				let f = await Ni(e.transport, t, i);
				if (e.generation() !== c.publication.generation) return u("The account changed before send. Nothing was sent.");
				let p = f && ca(i, t, !1, f);
				if (!p) return u("The current successful controls changed before send. Nothing was sent.");
				if (t.replyTarget) {
					if (!ea(await a(t), c.publication.replyBefore)) return u("A previously observed post changed before send. Review the current reply again; nothing was sent.");
					if (e.generation() !== c.publication.generation) return u("The account changed before send. Nothing was sent.");
				}
				if (o && (!await o.check() || !o.current())) return u("Local writing or recovery changed during preflight. Nothing was sent.");
				if (e.generation() !== c.publication.generation || ta(e.account()) !== t.account.id) return u("The account changed before send. Nothing was sent.");
				d = !0;
				let m = await e.transport.request(p.url, {
					method: "POST",
					body: p.body,
					fresh: !0
				});
				if (e.generation() !== c.publication.generation || ta(e.account()) !== c.publication.submission.writing.account.id) return {
					...n,
					status: "uncertain",
					message: "The account changed while publication was in flight. It may have been accepted; no rollback or atomic account isolation is guaranteed."
				};
				let h = ua(m, e.origin);
				return h.kind === "candidate" ? await s({
					...n,
					candidateURL: h.url,
					status: "uncertain"
				}, h.url) : {
					...n,
					status: h.kind === "unknown" || t.redPacket && h.kind === "rejected" ? "uncertain" : h.kind,
					message: t.redPacket && h.kind === "rejected" ? "The forum refused validation; thread, packet and credit outcomes remain unconfirmed. Check the original attempt before considering another send." : h.message
				};
			} catch {
				return d ? {
					...n,
					status: "uncertain",
					message: "The response was lost. The forum may have accepted this attempt. Check result; no send was repeated."
				} : u("Fresh preflight failed before publication was sent. Your writing is retained; review again deliberately.");
			} finally {
				i.delete(l);
			}
		},
		check: (e, t) => s(na(e), t || e.candidateURL || "")
	};
}
//#endregion
//#region src/forum-client/drafts.ts
var fa = "/home.php?mod=space&do=thread&view=me&type=thread&filter=save";
function pa(e, t) {
	try {
		let n = new URL(e, t), r = {
			mod: "space",
			do: "thread",
			view: "me",
			type: "thread",
			filter: "save"
		};
		return n.origin !== t || n.pathname !== "/home.php" || n.hash || n.username || n.password || Object.entries(r).some(([e, t]) => n.searchParams.get(e) !== t) || [...n.searchParams.keys()].some((e) => ![
			...Object.keys(r),
			"page",
			"from",
			"tsdmapp"
		].includes(e) || n.searchParams.getAll(e).length !== 1) || n.searchParams.has("page") && !/^[1-9]\d*$/.test(n.searchParams.get("page")) || n.searchParams.has("from") && n.searchParams.get("from") !== "" ? null : (n.searchParams.delete("tsdmapp"), n);
	} catch {
		return null;
	}
}
function ma(e, t) {
	let n = { kind: "unknown" }, r = (e, r = "invalid") => ({
		kind: r,
		account: n,
		message: e,
		sourceURL: t
	}), i = new URL(t).origin, a = pa(e.url, i), o = pa(t, i);
	if (!a || !o || (a.searchParams.get("page") ?? "1") !== (o.searchParams.get("page") ?? "1") || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType)) return r("The forum returned a different or unsupported draft list.");
	let s = e.body;
	try {
		if (/json/i.test(e.contentType) || /^\s*\{/.test(s)) {
			let e = JSON.parse(s);
			if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
			s = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document;
		}
	} catch {
		return r("The draft list could not be interpreted.");
	}
	let c = q(s);
	n = X(c, a.href);
	let l = G(V(c, "messagetext") ?? V(c, "main_message"));
	if (V(c, "challenge-form") || V(c, "cf-challenge-running") || /Just a moment|Checking your browser/.test(G(B(c, (e) => e.tagName === "title")[0]))) return r("Complete native verification before loading drafts.", "challenge");
	if (n.kind === "guest" || e.status === 401) return r("Sign in before loading forum drafts.", "login");
	if (e.status === 403) return r("The current account cannot read these drafts.", "permission");
	if (e.status === 429) return r("The forum is limiting draft requests.", "limited");
	if (e.status !== 200 || n.kind !== "member" || l) return r("A complete current-account draft list is required.");
	let u = V(c, "delform"), d = B(c, (e) => e.tagName === "a" && U(e, "a") && !!pa(z(e, "href"), i));
	if (!u || u.tagName !== "form" || B(c, (e) => z(e, "id") === "delform").length !== 1 || d.length !== 1) return r("The forum draft filter or list structure is unavailable.");
	let f = [], p = B(u, (e) => e.tagName === "tr");
	for (let e of p) {
		let t = B(e, (e) => e.tagName === "a" && !!e.parentNode && "tagName" in e.parentNode && e.parentNode.tagName === "th");
		if (!t.length) {
			if (U(e, "th") || B(e, (e) => U(e, "emp")).length) continue;
			return r("A draft row could not be interpreted; the list is not complete.");
		}
		let n = t[0], a = K(z(n, "href"), i), o = B(e, (e) => e.tagName === "a").map((e) => K(z(e, "href"), i)).filter((e) => !!e && new URL(e).searchParams.get("mod") === "forumdisplay");
		if (t.length !== 1 || !a || o.length !== 1) return r("A draft row has ambiguous identity.");
		let s = new URL(a), c = new URL(o[0]), l = s.searchParams.get("tid") ?? "", u = c.searchParams.get("fid") ?? "";
		if (s.origin !== i || s.pathname !== "/forum.php" || s.searchParams.get("mod") !== "viewthread" || c.origin !== i || !/^[1-9]\d*$/.test(l) || !/^[1-9]\d*$/.test(u) || !G(n) || f.some((e) => e.threadId === l)) return r("A draft row has unsupported or repeated identity.");
		f.push({
			threadId: l,
			boardId: u,
			title: G(n),
			url: a
		});
	}
	let m = B(u, (e) => U(e, "emp"));
	if (!f.length && (m.length !== 1 || !/还没有相关的帖子|還沒有相關的帖子/.test(G(m[0])))) return r("No authoritative empty draft list was returned.");
	let h = B(c, (e) => U(e, "pg")), g = [];
	for (let e of h) for (let t of B(e, (e) => e.tagName === "a" && !!z(e, "href"))) {
		let e = pa(z(t, "href"), i);
		if (!e) return r("The draft pager returned an unsupported destination.");
		g.some((t) => t.url === e.href) || g.push({
			label: G(t),
			url: e.href
		});
	}
	return {
		kind: "drafts",
		account: n,
		sourceURL: t,
		drafts: {
			url: o.href,
			rows: f,
			empty: f.length ? "" : G(m[0]),
			pages: {
				current: o.searchParams.get("page") ?? "1",
				links: g
			}
		}
	};
}
//#endregion
//#region src/forum-client/draft-operations.ts
var ha = (e) => JSON.parse(JSON.stringify(e)), Q = (e) => e.kind === "member" ? e.id : null;
function ga(e) {
	let t = e.body;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(t)) {
		let e = JSON.parse(t);
		t = (e.head ?? "") + e.document;
	}
	return q(t);
}
function _a(e) {
	return (e ?? []).filter((e) => !(/^attachupdate\[[1-9]\d*\]$/.test(e.name) && e.value === "" && !e.disabled));
}
function va(e, t) {
	return e.length === t.length && new Set(e).size === e.length && new Set(t).size === t.length && e.every((e) => /^[1-9]\d*$/.test(e) && t.includes(e));
}
function ya(e, t, n) {
	for (let r of [e ?? [], t ?? []]) {
		if (new Set(r.map((e) => e.name)).size !== r.length) return null;
		for (let e of r) {
			let t = /^attachupdate\[([1-9]\d*)\]$/.exec(e.name), r = /^attachnew\[([1-9]\d*)\]\[(description|readperm|price)\]$/.exec(e.name), i = (t ?? r)?.[1];
			if (!i || !n.includes(i) || t && e.value !== "") return null;
		}
	}
	let r = _a(e), i = new Map(_a(t).map((e) => [e.name, e])), a = [];
	if (r.length !== i.size) return null;
	for (let e of r) {
		let t = i.get(e.name);
		if (!t || e.disabled !== t.disabled) return null;
		if (e.value !== t.value) {
			if (!e.disabled && /^attachnew\[[1-9]\d*\]\[price\]$/.test(e.name) && e.value === "" && t.value === "0") a.push({
				name: e.name,
				submitted: "",
				stored: "0"
			});
			else return null;
		}
	}
	return a;
}
function ba(e, t) {
	for (let n = e; n; n = "parentNode" in n ? n.parentNode : null) if ("tagName" in n && t(n)) return !0;
	return !1;
}
function xa(e) {
	return ba(e, (e) => U(e, "pcb") || U(e, "pcbs") || U(e, "sign") || U(e, "signature") || /^postmessage_|^signature/.test(z(e, "id")));
}
function Sa(e) {
	let t = V(e, "postlist"), n = t && V(t, "thread_subject");
	return !t || !n || n.parentNode && "tagName" in n.parentNode && n.parentNode.tagName !== "h1" || xa(n) ? [] : B(t, (e) => e.tagName === "span" && U(e, "xg1") && !xa(e) && !ba(e, (e) => /^post_[1-9]\d*$/.test(z(e, "id"))) && R(e).filter((e) => !("tagName" in e)).map(W).join("").trim() === "(草稿)" && (e.parentNode === n.parentNode || !!e.parentNode && [
		"plc",
		"ptm",
		"pbn",
		"vwthd"
	].every((t) => U(e.parentNode, t))));
}
function Ca(e, t, n, r) {
	let i = V(e, `post_${t}`);
	return i ? B(i, (e) => e.tagName === "a" && U(e, "psave") && !xa(e) && (ba(e, (e) => U(e, "pob")) && ba(e, (e) => U(e, "po")) || ba(e, (e) => z(e, "id") === "fj") && ba(e, (e) => U(e, "pi"))) && (() => {
		let t = K(z(e, "href"), r);
		if (!t) return !1;
		let i = new URL(t);
		return i.origin === r && i.pathname === "/forum.php" && !i.hash && i.searchParams.get("mod") === "misc" && i.searchParams.get("action") === "pubsave" && i.searchParams.get("tid") === n && [...i.searchParams.keys()].every((e) => [
			"mod",
			"action",
			"tid"
		].includes(e) && i.searchParams.getAll(e).length === 1);
	})()) : [];
}
function wa(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = 0, o = (t, n = "invalid") => ({
		kind: n,
		message: t,
		account: e.account(),
		generation: e.generation(),
		sourceURL: new URL(fa, e.origin).href
	});
	async function s(t) {
		let n = [new URL(fa, e.origin).href], r = /* @__PURE__ */ new Set(), i = [];
		for (; n.length;) {
			let a = n.shift();
			if (r.has(a)) continue;
			r.add(a);
			let o = ma(await e.transport.request(a, { fresh: !0 }), a);
			if (e.observe(o.account), Q(o.account) !== Q(t) || o.kind !== "drafts") throw Error("Draft list unavailable");
			i.push(...o.drafts.rows);
			for (let e of o.drafts.pages.links) r.has(e.url) || n.push(e.url);
		}
		return i;
	}
	async function c(e, t) {
		return (await s(t)).some((t) => t.threadId === e.threadId && t.boardId === e.boardId);
	}
	async function l(t, n) {
		let r = e.account(), i = e.generation();
		try {
			if (!Q(n) || !/^[1-9]\d*$/.test(t.threadId) || !/^[1-9]\d*$/.test(t.boardId) || !await c(t, n)) return o("The same draft is no longer listed for the expected account.");
			if (r.kind === "unknown" && e.generation() === i + 1 && Q(e.account()) === Q(n) && (i = e.generation()), i !== e.generation()) return o("The account changed during draft preparation.", "stale");
			let a = new URL(`/forum.php?mod=viewthread&tid=${t.threadId}`, e.origin).href, s = await e.transport.request(a, { fresh: !0 }), l = oi(s, a);
			if (e.observe(l.account), i !== e.generation() || Q(l.account) !== Q(n)) return o("The account changed during draft preparation.", "stale");
			if (l.kind !== "thread" || l.thread.id !== t.threadId || !l.thread.parent || new URL(l.thread.parent.url).searchParams.get("fid") !== t.boardId) return o("The draft board or thread could not be independently verified.");
			let u = l.thread.posts.filter((e) => /^1\s*#?$/.test(e.floor));
			if (u.length !== 1 || u[0]?.authorId !== Q(n)) return o("The draft opening-post owner is unverified.");
			let d = u[0].id, f = ga(s);
			if (Sa(f).length !== 1 || !Ca(f, d, t.threadId, e.origin).length) return o("The thread is not independently confirmed as an unpublished draft.");
			let p = new URL(`/forum.php?mod=post&action=edit&fid=${t.boardId}&tid=${t.threadId}&pid=${d}`, e.origin).href, m = Z(await e.transport.request(p, { fresh: !0 }), p, t.boardId, {
				threadId: t.threadId,
				postId: d
			});
			return e.observe(m.account), i !== e.generation() || Q(m.account) !== Q(n) ? o("The account changed during saved-source readback.", "stale") : m.kind === "prepared" ? {
				...m,
				generation: e.generation(),
				prepared: {
					...m.prepared,
					...u[0].redPacketThreadId === t.threadId ? { existingRedPacket: !0 } : {},
					draft: {
						threadId: t.threadId,
						postId: d,
						url: a,
						version: xi(m.prepared)
					}
				}
			} : {
				...m,
				generation: e.generation()
			};
		} catch {
			return o("The draft could not be independently read. Existing writing is retained.", "network");
		}
	}
	async function u(e, t) {
		if (e.operation === "publish") return p(e);
		let n = e.submission.writing, r = n.draft ?? e.result;
		if (t ??= r ? {
			threadId: r.threadId,
			boardId: n.board.id,
			title: n.title,
			url: r.url
		} : void 0, !t) {
			try {
				await s(n.account);
			} catch {}
			return {
				...e,
				status: "uncertain",
				message: "The save may have succeeded. Select the actual draft from Drafts to check this original attempt; no save was repeated.",
				result: null
			};
		}
		if (r && (t.threadId !== r.threadId || t.boardId !== n.board.id) || !n.draft && (!e.priorDraftIds || e.priorDraftIds.includes(t.threadId))) return {
			...e,
			status: "uncertain",
			message: "This record predates this save, differs from its original target, or the pre-send list was not retained. It cannot confirm this original attempt. No save was repeated.",
			result: e.result
		};
		let i = await l(t, n.account);
		if (i.kind !== "prepared" || !i.prepared.draft) return {
			...e,
			status: "uncertain",
			message: "The same draft's complete saved revision could not be confirmed. No save was repeated.",
			result: e.result
		};
		let a = i.prepared, o = !!Xi({
			...n,
			uploadedReferences: [],
			attachmentFields: []
		}, {
			...a,
			uploadedReferences: [],
			attachmentFields: []
		}), c = ya(n.attachmentFields, a.attachmentFields, n.uploadedReferences), u = va(n.uploadedReferences, a.uploadedReferences) && c !== null;
		return {
			...e,
			observation: {
				...a.existingRedPacket ? { packetMarker: !0 } : {},
				state: "draft",
				content: o ? "confirmed" : "unknown",
				attachments: u ? "confirmed" : "unknown",
				...u && c?.length ? { attachmentNormalizations: c } : {}
			},
			status: o && u ? "confirmed" : "uncertain",
			message: o && u ? `Confirmed forum draft ${t.threadId}, submitted revision ${e.submission.revision}. Later changes remain unsaved.` : `Draft ${t.threadId} observed; submitted content ${o ? "confirmed" : "unconfirmed"}; attachment associations ${u ? "confirmed" : "unconfirmed"}. No save was repeated.`,
			result: a.draft
		};
	}
	async function d(t, n = !1) {
		let r = t.submission.writing;
		if (!r.redPacket && !r.existingRedPacket) return t;
		let i = {
			state: "unknown",
			conditions: [],
			credit: "unknown"
		}, a = t.result ?? r.draft, o = e.generation();
		if (!a || !n && o !== t.generation || Q(e.account()) !== r.account.id) return {
			...t,
			redPacket: i
		};
		let s = await Hi(e.transport, e.origin, a.threadId), c = await Ui(e.transport, e.origin, r.account.id);
		return c.account.kind !== "unknown" && e.observe(c.account), {
			...t,
			redPacket: e.generation() === o && Q(e.account()) === r.account.id ? {
				...s,
				ledger: c.ledger
			} : i
		};
	}
	async function f(e, t) {
		return d(await u(e, t), !0);
	}
	async function p(t) {
		let n = t.submission.writing, r = n.draft, i = (e) => ({
			...t,
			status: "uncertain",
			message: e,
			result: null
		});
		if (!r || ![
			r.threadId,
			r.postId,
			n.board.id
		].every((e) => /^[1-9]\d*$/.test(e))) return i("The original draft publication identity is unavailable.");
		let a = new URL(`/forum.php?mod=viewthread&tid=${r.threadId}`, e.origin).href, o = {
			threadId: r.threadId,
			boardId: n.board.id,
			title: n.title,
			url: a
		}, s = e.generation();
		try {
			if (await c(o, n.account)) {
				let e = await l(o, n.account);
				return e.kind === "prepared" ? {
					...t,
					status: "remaining-draft",
					message: "The record is still an unpublished forum draft. Publication is not confirmed; no action was repeated.",
					result: e.prepared.draft ?? null
				} : i("The draft remains listed but its current state is unverified.");
			}
			let u = await e.transport.request(a, { fresh: !0 }), d = oi(u, a);
			if (e.observe(d.account), e.generation() !== s || Q(d.account) !== n.account.id || d.kind !== "thread") return i("The actual published thread could not be independently read for the original account.");
			let f = d.thread.posts.filter((e) => /^1\s*#?$/.test(e.floor)), p = ga(u);
			if (d.thread.id !== r.threadId || f.length !== 1 || f[0]?.id !== r.postId || f[0]?.authorId !== n.account.id || d.thread.title !== n.title || !d.thread.parent || new URL(d.thread.parent.url).searchParams.get("fid") !== n.board.id || Sa(p).length || B(V(p, `post_${r.postId}`) ?? p, (e) => e.tagName === "a" && U(e, "psave") && !xa(e)).length) return i("The resulting thread identity, author or published state did not match the original draft.");
			let m = B(V(p, "postlist") ?? p, (e) => !xa(e) && ([
				"modact",
				"locked",
				"fico-lock",
				"attach_nopermission"
			].some((t) => U(e, t)) || z(e, "id") === "messagetext"));
			if (m.some((e) => /审核|審核|moderation/i.test(G(e)))) return {
				...t,
				status: "moderation",
				message: "The forum reports moderation. Public thread publication has not been confirmed.",
				result: null
			};
			if (m.length) return i("The resulting thread has native state restrictions. Public thread publication has not been confirmed.");
			let h = new URL(`/forum.php?mod=post&action=edit&fid=${n.board.id}&tid=${r.threadId}&pid=${r.postId}`, e.origin).href, g = Z(await e.transport.request(h, { fresh: !0 }), h, n.board.id, {
				threadId: r.threadId,
				postId: r.postId
			});
			if (e.observe(g.account), e.generation() !== s || Q(g.account) !== n.account.id || g.kind !== "prepared") return i("The complete published source or account could not be confirmed. No publication was repeated.");
			let _ = g.prepared, v = !!Xi({
				...n,
				uploadedReferences: [],
				attachmentFields: []
			}, {
				..._,
				uploadedReferences: [],
				attachmentFields: []
			}), y = ya(n.attachmentFields, _.attachmentFields, n.uploadedReferences), b = va(n.uploadedReferences, _.uploadedReferences) && y !== null;
			return {
				...t,
				observation: {
					state: "published",
					content: v ? "confirmed" : "unknown",
					attachments: b ? "confirmed" : "unknown",
					...b && y?.length ? { attachmentNormalizations: y } : {}
				},
				status: v && b ? "published" : "uncertain",
				message: v && b ? `Confirmed publication of forum draft ${r.threadId}, post ${r.postId}. The draft list no longer contains this record.` : `Published thread ${r.threadId} observed; submitted content ${v ? "confirmed" : "unconfirmed"}; attachment associations ${b ? "confirmed" : "unconfirmed"}. No publication was repeated.`,
				result: {
					...r,
					url: a
				},
				publishedURL: `${a}#pid${r.postId}`
			};
		} catch {
			return i("Publication may have succeeded, but independent draft and stored-source readback failed. No action was repeated.");
		}
	}
	async function m(r) {
		let i = ha(r), a = i.submission.writing, o = a.draft, s = (e) => ({
			...i,
			status: "not-sent",
			message: e,
			result: null
		});
		if (!o || i.operation !== "publish" || i.status !== "pending" || !i.id || t.has(i.id) || n.has(i.submission.contextId) || e.generation() !== i.generation || Q(e.account()) !== a.account.id) return s("This draft publication is stale or already active. Nothing was sent.");
		t.add(i.id), n.add(i.submission.contextId);
		let c = !1;
		try {
			if (!await Ri(e, a)) return s("A selected mention identity changed before send. Nothing was sent.");
			if (e.generation() !== i.generation || Q(e.account()) !== a.account.id) return s("The saved draft or account changed before publication. Current writing is retained.");
			let t = await l({
				threadId: o.threadId,
				boardId: a.board.id,
				title: a.title,
				url: o.url
			}, a.account);
			if (t.kind !== "prepared" || t.prepared.draft?.version !== o.version || !Xi({
				...a,
				attachmentFields: []
			}, {
				...t.prepared,
				attachmentFields: []
			}) || !va(a.uploadedReferences, t.prepared.uploadedReferences) || ya(a.attachmentFields, t.prepared.attachmentFields, a.uploadedReferences) === null || e.generation() !== i.generation) return s("The saved draft or account changed before publication. Current writing is retained.");
			let n = new URL(`/forum.php?mod=post&action=edit&fid=${a.board.id}&tid=${o.threadId}&pid=${o.postId}`, e.origin).href, r = await e.transport.request(n, { fresh: !0 }), u = Z(r, n, a.board.id, {
				threadId: o.threadId,
				postId: o.postId
			});
			if (e.observe(u.account), e.generation() !== i.generation || Q(u.account) !== a.account.id || u.kind !== "prepared" || xi(u.prepared) !== o.version) return s("The current saved draft changed before publication. Nothing was sent.");
			let d = ca(r, a, "publish");
			if (!d) return s("The current native draft publication controls are unsupported. Nothing was sent.");
			c = !0;
			let f = Ki(await e.transport.request(d.url, {
				method: "POST",
				body: d.body
			}));
			return e.generation() === i.generation ? f?.success && /审核|審核|moderation/i.test(f.values.join(" ")) ? {
				...i,
				status: "moderation",
				message: "The forum reports moderation. Public thread publication has not been confirmed.",
				result: null
			} : p(i) : {
				...i,
				status: "uncertain",
				message: "The account changed during draft publication. Possible effects are retained.",
				result: null
			};
		} catch {
			return c ? {
				...i,
				status: "uncertain",
				message: "Draft publication may have succeeded. Check the original attempt before another deliberate action.",
				result: null
			} : s("Fresh draft publication preparation failed. Nothing was sent.");
		} finally {
			n.delete(i.submission.contextId);
		}
	}
	async function h(o) {
		let c = ha(o), l = c.submission.writing, u = () => ({
			...c,
			status: "not-sent",
			message: "Fresh draft-save preparation failed or the account changed. Nothing was sent.",
			result: null
		});
		if (l.redPacket && (!c.fundingReviewed || !zi(l)) || c.operation === "publish" || c.status !== "pending" || !c.id || t.has(c.id) || n.has(c.submission.contextId) || e.generation() !== c.generation || Q(e.account()) !== l.account.id) return u();
		let d = ++a;
		i.set(c.submission.contextId, d);
		for (let [e, t] of r) t.submission.contextId === c.submission.contextId && r.delete(e);
		try {
			return l.draft || (c.priorDraftIds = [...new Set((await s(l.account)).map((e) => e.threadId))]), i.get(c.submission.contextId) !== d || t.has(c.id) || e.generation() !== c.generation || Q(e.account()) !== l.account.id ? u() : (r.set(c.id, ha(c)), c);
		} catch {
			return u();
		}
	}
	async function g(i) {
		let a = ha(i), o = a.submission, s = o.writing, c = (e) => ({
			...a,
			status: "not-sent",
			message: e,
			result: null
		});
		if (a.operation === "publish" || JSON.stringify(r.get(a.id)) !== JSON.stringify(a) || a.status !== "pending" || !a.id || t.has(a.id) || n.has(o.contextId) || !o.contextId || o.revision < 1 || s.action !== "new-thread" || e.generation() !== a.generation || Q(e.account()) !== s.account.id) return c("This draft attempt is stale or already active. Nothing was sent.");
		t.add(a.id), r.delete(a.id), n.add(o.contextId);
		let d = !1;
		try {
			if (!await Ri(e, s)) return c("A selected mention identity changed before send. Nothing was sent.");
			if (e.generation() !== a.generation || Q(e.account()) !== s.account.id) return c("The account changed before draft saving. Nothing was sent.");
			let t = new URL(`/forum.php?mod=post&action=newthread&fid=${s.board.id}${s.redPacket ? "&specialextra=hongbao" : ""}`, e.origin).href;
			if (s.draft) {
				let n = await l({
					threadId: s.draft.threadId,
					boardId: s.board.id,
					title: s.title,
					url: s.draft.url
				}, s.account);
				if (n.kind !== "prepared" || n.prepared.draft?.version !== s.draft.version) return c("The remote draft changed or is no longer available. Resume its current revision before saving; your local writing is retained.");
				t = new URL(`/forum.php?mod=post&action=edit&fid=${s.board.id}&tid=${s.draft.threadId}&pid=${s.draft.postId}`, e.origin).href;
			}
			let n = await e.transport.request(t, { fresh: !0 }), r = Z(n, t, s.board.id, s.draft ? {
				threadId: s.draft.threadId,
				postId: s.draft.postId
			} : void 0);
			if (e.observe(r.account), e.generation() !== a.generation || Q(r.account) !== s.account.id) return c("The account changed before draft saving. Nothing was sent.");
			if (r.kind !== "prepared" || !r.prepared.draftSaveAvailable || !sa(s.draft ? {
				...s,
				existingRedPacket: !1,
				options: s.options.filter((e) => ![
					"addfeed",
					"adddynamic",
					"adddynamic_doing"
				].includes(e.name) || r.prepared.options.some((t) => t.name === e.name))
			} : s, r.prepared) || s.draft && xi(r.prepared) !== s.draft.version) return c("The current draft form changed. Your writing is retained; nothing was sent.");
			if (!await Wi(e, s)) return c("The designated recipients changed or could not be verified. Nothing was sent.");
			let i = await Ni(e.transport, s, n);
			if (e.generation() !== a.generation || Q(e.account()) !== s.account.id) return c("The account changed during attachment validation. Nothing was sent.");
			let o = (s.uploads ?? []).filter((e) => e.status === "uploaded").map((e) => e.serverId);
			if (!i || !va(s.uploadedReferences.filter((e) => !o.includes(e)), r.prepared.uploadedReferences) || ya((s.attachmentFields ?? []).filter((e) => !o.some((t) => e.name.startsWith(`attachnew[${t}]`))), r.prepared.attachmentFields, s.uploadedReferences.filter((e) => !o.includes(e))) === null) return c("The current attachment references changed before saving. Nothing was sent; original source and metadata are retained.");
			let f = i.length || s.redPacket ? await e.transport.request(t, { fresh: !0 }) : n, p = Z(f, t, s.board.id, s.draft ? {
				threadId: s.draft.threadId,
				postId: s.draft.postId
			} : void 0);
			if (e.observe(p.account), e.generation() !== a.generation || Q(p.account) !== s.account.id) return c("The account changed during attachment validation. Nothing was sent.");
			if (p.kind !== "prepared" || !sa(r.prepared, p.prepared) || xi(p.prepared) !== xi(r.prepared)) return c("The current draft changed during attachment validation. Nothing was sent.");
			let m = ca(f, s, "save", i);
			if (!m) return c("The current native draft-save controls are unsupported. Nothing was sent.");
			d = !0;
			let h = await e.transport.request(m.url, {
				method: "POST",
				body: m.body
			});
			if (e.generation() !== a.generation) return {
				...a,
				status: "uncertain",
				message: "The account changed during saving. Possible effects and original writing are retained.",
				result: null
			};
			let g = Ki(h);
			if (g && !g.success && /subject_(?:empty|invalid|toolong)|message_(?:empty|toolong)/.test(g.values.join(" "))) return {
				...a,
				status: s.redPacket ? "uncertain" : "rejected",
				message: s.redPacket ? "The forum refused validation; draft and funding outcomes remain unconfirmed. Check the original attempt before any deliberate resend." : "The forum rejected draft saving. Your writing is retained.",
				result: null
			};
			let _ = g?.success ? K(g.values[0] ?? "", e.origin) : null, v = _ ? new URL(_) : null;
			return u(a, s.draft ? {
				threadId: s.draft.threadId,
				boardId: s.board.id,
				title: s.title,
				url: s.draft.url
			} : v?.origin === e.origin && v.pathname === "/forum.php" && v.searchParams.get("mod") === "viewthread" && /^[1-9]\d*$/.test(v.searchParams.get("tid") ?? "") ? {
				threadId: v.searchParams.get("tid"),
				boardId: s.board.id,
				title: s.title,
				url: v.href
			} : void 0);
		} catch {
			return d ? {
				...a,
				status: "uncertain",
				message: "Draft saving may have succeeded. Check the original attempt before saving again; your writing is retained.",
				result: null
			} : c("Draft preparation failed. Nothing was sent and writing is retained.");
		} finally {
			n.delete(o.contextId);
		}
	}
	return {
		resume: l,
		prepareSave: h,
		save: async (e) => d(await g(e)),
		check: async (e, t) => ({
			...await f(e, t),
			checked: !0
		}),
		publish: async (e) => d(await m(e))
	};
}
//#endregion
//#region src/forum-client/favorites.ts
function Ta(e, t) {
	let n = { kind: "unknown" }, r = (e, r = "invalid") => ({
		kind: r,
		message: e,
		account: n,
		sourceURL: t
	}), i = J(t), a = J(e.url);
	if (i?.kind !== "favorites" || a?.kind !== "favorites" || i.url.origin !== a.url.origin || !/^(?:text\/html|application\/json)(?:;|$)/i.test(e.contentType)) return r("The favorite list response is unsupported.");
	let o = e.body, s = null;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(o)) try {
		let e = JSON.parse(o);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		o = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document, "uid" in e && typeof e.uid == "number" && Number.isSafeInteger(e.uid) && e.uid >= 0 && (s = e.uid);
	} catch {
		return r("The favorite list could not be interpreted.");
	}
	let c = q(o), l = X(c, e.url);
	n = l.kind === "unknown" && s !== null ? s ? {
		kind: "member",
		id: String(s),
		name: `Member ${s}`
	} : { kind: "guest" } : l, l.kind === "member" && s !== null && l.id !== String(s) && (n = { kind: "unknown" });
	let u = G(V(c, "messagetext"));
	if (V(c, "challenge-form") || V(c, "cf-challenge-running")) return r("Native verification is required.", "challenge");
	if (n.kind === "guest" || /登录|登入|登錄/.test(u) || e.status === 401) return r("Sign in through the native forum to read Saved.", "login");
	if (e.status === 403 || /权限|權限|無權/.test(u)) return r("The current account cannot read these favorites.", "permission");
	if (e.status !== 200 || u || n.kind !== "member") return r("The favorite list or current account could not be confirmed.");
	let d = i.url.searchParams.get("type"), f = a.url.searchParams.get("page") ?? "1";
	if (a.url.searchParams.get("type") !== d || f !== (i.url.searchParams.get("page") ?? "1")) return r("The forum returned a different favorite kind or page.");
	let p = V(c, "ct"), m = V(c, "favorite_ul");
	if (!p) return r("The favorite list is incomplete; it has not been treated as empty.");
	let h = m ? R(m).filter((e) => "tagName" in e && e.tagName === "li") : [], g = [];
	for (let t of h) {
		let n = /^fav_([1-9]\d*)$/.exec(z(t, "id"))?.[1], a = B(t, (e) => e.tagName === "input" && z(e, "name") === "favorite[]"), o = a.length === 1 ? z(a[0], "vid") : "";
		if (!n || !/^[1-9]\d*$/.test(o) || z(a[0], "value") !== n) return r("A favorite has ambiguous record or target identity.");
		let s = B(t, (e) => e.tagName === "a"), c = s.flatMap((t) => {
			let n = K(z(t, "href"), e.url), r = n && J(n);
			return r && r.url.origin === i.url.origin && r.kind === (d === "forum" ? "board" : "thread") ? [{
				node: t,
				url: Y(r.url.href),
				id: r.url.searchParams.get(d === "forum" ? "fid" : "tid")
			}] : [];
		});
		if (c.length > 1 || c.some((e) => e.id !== o)) return r("A favorite target does not match its record.");
		let l = s.some((t) => {
			let r = K(z(t, "href"), e.url);
			if (!r) return !1;
			let a = new URL(r);
			return a.origin === i.url.origin && a.pathname === "/home.php" && a.searchParams.get("mod") === "spacecp" && a.searchParams.get("ac") === "favorite" && a.searchParams.get("op") === "delete" && a.searchParams.get("favid") === n;
		}), u = B(t, (e) => U(e, "xg1"))[0], f = u && B(u, (e) => !!z(e, "title"))[0];
		g.push({
			id: n,
			kind: d,
			targetId: o,
			url: c[0]?.url ?? null,
			title: c[0] ? G(c[0].node) : `Unavailable ${d === "forum" ? "board" : "thread"} ${o}`,
			time: f ? z(f, "title") : G(u),
			note: G(B(t, (e) => e.tagName === "blockquote")[0]),
			removable: l,
			...c.length ? {} : { unavailableText: R(t).filter((e) => !("tagName" in e) || !["a", "input"].includes(e.tagName) && !U(e, "xg1") && !U(e, "quote")).map(G).filter(Boolean).join(" ") }
		});
	}
	if (new Set(g.map((e) => e.id)).size !== g.length || new Set(g.map((e) => e.targetId)).size !== g.length) return r("The favorite list contains duplicate identities.");
	if (!h.length && !B(p, (e) => U(e, "emp")).some((e) => /您还没有添加任何收藏|您還沒有添加任何收藏/.test(G(e)))) return r("The favorite list is incomplete; it has not been treated as empty.");
	if (B(p, (t) => t.tagName === "a" && (() => {
		let n = K(z(t, "href"), e.url), r = n && J(n);
		return !!(r && r.kind === "favorites" && r.url.searchParams.has("page"));
	})()).some((e) => {
		let t = e.parentNode;
		for (; t && t !== p;) {
			if (U(t, "pg")) return !1;
			t = "parentNode" in t ? t.parentNode : null;
		}
		return !0;
	})) return r("The returned favorite pages could not be preserved completely.");
	let _ = B(p, (e) => U(e, "pg")), v = [];
	for (let t of _) {
		let n = G(B(t, (e) => e.tagName === "strong")[0]);
		if (n && n !== f) return r("The favorite page identity is inconsistent.");
		for (let n of B(t, (e) => e.tagName === "a")) {
			let t = K(z(n, "href"), e.url), a = t && J(t);
			if (!a || a.kind !== "favorites" || a.url.origin !== i.url.origin || a.url.searchParams.get("type") !== d || !G(n)) return r("The returned favorite pages could not be preserved completely.");
			v.push({
				url: Y(a.url.href),
				label: G(n)
			});
		}
	}
	return {
		kind: "favorites",
		account: n,
		sourceURL: Y(e.url),
		favorites: {
			kind: d,
			url: Y(e.url),
			records: g,
			pages: {
				current: f,
				links: [...new Map(v.map((e) => [e.url, e])).values()]
			}
		}
	};
}
//#endregion
//#region src/forum-client/favorite-command.ts
var Ea = (e) => e instanceof TypeError ? "The forum could not be reached. Retry or continue in the native forum." : e instanceof Error && e.message ? e.message : "The favorite list is unavailable.", Da = (e) => JSON.parse(JSON.stringify(e)), Oa = (e) => e.kind === "member" ? e.id : null, ka = (e, t) => JSON.stringify(e) === JSON.stringify(t);
function Aa(e) {
	let t = e.body;
	if (/json/i.test(e.contentType)) {
		let e = JSON.parse(t);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		t = ("head" in e && typeof e.head == "string" ? e.head : "") + e.document;
	} else if (/xml/i.test(e.contentType)) {
		let e = /^\s*(?:<\?xml[^?]*\?>\s*)?<root>\s*<!\[CDATA\[([\s\S]*)\]\]>\s*<\/root>\s*$/.exec(t);
		if (!e || /<!DOCTYPE|<!ENTITY/.test(t)) throw Error();
		t = e[1];
	}
	return q(t);
}
function ja(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), a = (t) => `${e.origin}/home.php?mod=space&do=favorite&type=${t}`, o = (t) => `${e.origin}/forum.php?mod=${t.kind === "forum" ? `forumdisplay&fid=${t.targetId}` : `viewthread&tid=${t.targetId}`}`, s = (e) => `${e.accountId}:${e.kind}:${e.targetId}`, c = (e) => [...t.values()].filter((t) => t.status === "uncertain" && s(t.command.intent) === s(e));
	function l(e, t) {
		let n = c(e);
		return n.every((e) => e.checked && t.unresolvedIds.includes(e.id)) && (!n.length || n.some((n) => n.id === t.previousAttemptId && ka(n.command.intent, e)));
	}
	let u = (e) => ["thread", "forum"].includes(e.kind) && ["add", "remove"].includes(e.action) && /^[1-9]\d*$/.test(e.targetId) && /^[1-9]\d*$/.test(e.accountId) && (e.action === "add" ? e.recordId === null : /^[1-9]\d*$/.test(e.recordId ?? ""));
	async function d(t) {
		let n = [a(t.kind)], r = /* @__PURE__ */ new Set(), i = [], o = e.generation(), s = e.account().kind === "unknown";
		for (; n.length;) {
			let a = n.shift();
			if (r.has(a)) continue;
			if (r.add(a), r.size > 100) throw Error("Complete result checking exceeded 100 returned pages. No absence is confirmed.");
			let c = new URL(a);
			c.searchParams.set("tsdmapp", "json");
			let l = await e.transport.request(c.href, { fresh: !0 });
			if (e.generation() !== o) throw Error("The account changed during favorite readback.");
			let u = Ta(l, a);
			if (e.observe(u.account), s && i.length === 0 && Oa(u.account) === t.accountId && (o = e.generation()), e.generation() !== o || Oa(u.account) !== t.accountId) throw Error("The favorite account changed or could not be confirmed.");
			if (u.kind !== "favorites") throw Error("message" in u ? u.message : "The favorite list is unavailable.");
			i.push(u.favorites);
			for (let e of u.favorites.pages.links) r.has(e.url) || n.push(e.url);
		}
		return i;
	}
	function f(e, t) {
		let n = t.flatMap((e) => e.records), r = n.filter((t) => t.targetId === e.targetId), i = e.recordId && n.find((t) => t.id === e.recordId);
		if (i && i.targetId !== e.targetId) throw Error("Favorite record identity no longer matches its target.");
		return e.action === "add" ? r.length > 0 : !i && r.length === 0;
	}
	async function p(t) {
		let n = t.intent, r = e.generation();
		if (n.action === "add") {
			let t = new URL(o(n));
			t.searchParams.set("tsdmapp", "json");
			let i = await e.transport.request(t.href, { fresh: !0 });
			if (e.generation() !== r) throw Error("The account changed before favorite preparation.");
			let a = n.kind === "forum" ? Qr(i, o(n)) : oi(i, o(n));
			if (e.observe(a.account), Oa(a.account) !== n.accountId || e.generation() !== r || !["board", "thread"].includes(a.kind)) throw Error("The current favorite target/account could not be confirmed.");
			let s = B(Aa(i), (e) => z(e, "id") === (n.kind === "forum" ? "a_favorite" : "k_favorite"));
			if (s.length !== 1) throw Error("A current native favorite control is not available.");
			let c = s[0];
			for (; c;) {
				if (/^(?:postmessage_|quote)/.test(z(c, "id")) || [
					"hidden",
					"inert",
					"disabled"
				].some((e) => "attrs" in c && c.attrs.some((t) => t.name === e))) throw Error("The favorite control is not an active native control.");
				c = "parentNode" in c ? c.parentNode : null;
			}
			let l = K(z(s[0], "href"), i.url);
			if (!l) throw Error("The native favorite destination is unavailable.");
			let u = new URL(l), d = u.searchParams;
			if (u.origin !== e.origin || u.pathname !== "/home.php" || d.get("mod") !== "spacecp" || d.get("ac") !== "favorite" || d.get("type") !== n.kind || d.get("id") !== n.targetId || !d.get("formhash") || [...d.keys()].some((e) => ![
				"mod",
				"ac",
				"type",
				"id",
				"formhash",
				"handlekey"
			].includes(e) || d.getAll(e).length !== 1)) throw Error("The current native favorite action is unsupported.");
			return u.searchParams.set("inajax", "1"), u.searchParams.set("infloat", "yes"), u.searchParams.set("handlekey", d.get("handlekey") ?? "k_favorite"), { url: u.href };
		}
		let i = new URL("/home.php", e.origin);
		for (let [e, t] of Object.entries({
			mod: "spacecp",
			ac: "favorite",
			op: "delete",
			favid: n.recordId,
			infloat: "yes",
			handlekey: `a_delete_${n.recordId}`,
			inajax: "1"
		})) i.searchParams.set(e, t);
		let a = await e.transport.request(i.href, { fresh: !0 });
		if (e.generation() !== r || a.status !== 200 || a.redirect === "followed") throw Error("The current favorite removal form is unavailable.");
		let s = B(Aa(a), (e) => e.tagName === "form");
		if (s.length !== 1) throw Error("The current favorite removal form is unavailable.");
		let c = s[0], l = K(z(c, "action"), a.url);
		if (!l || z(c, "method").toLowerCase() !== "post" || z(c, "target") || z(c, "enctype") && z(c, "enctype") !== "application/x-www-form-urlencoded") throw Error("Unsupported favorite removal form.");
		let u = new URL(l), d = u.searchParams;
		if (u.origin !== e.origin || u.pathname !== "/home.php" || d.get("mod") !== "spacecp" || d.get("ac") !== "favorite" || d.get("op") !== "delete" || d.get("favid") !== n.recordId || [...d.keys()].some((e) => ![
			"mod",
			"ac",
			"op",
			"favid",
			"type"
		].includes(e) || d.getAll(e).length !== 1)) throw Error("The removal form does not identify this favorite record.");
		let f = B(c, (e) => [
			"input",
			"textarea",
			"select",
			"button"
		].includes(e.tagName)), p = [];
		for (let e of f) {
			let t = z(e, "name"), n = z(e, "type");
			if (z(e, "form") || e.attrs.some((e) => e.name.startsWith("form")) || H(e)) throw Error("The removal form contains unsupported controls.");
			if (n !== "submit" && e.tagName !== "button") {
				if (![
					"referer",
					"deletesubmit",
					"formhash",
					"handlekey"
				].includes(t) || n !== "hidden" || p.some(([e]) => e === t)) throw Error("The removal form contains unsupported controls.");
				p.push([t, z(e, "value")]);
			}
		}
		let m = new URLSearchParams(p);
		if (!m.get("formhash") || m.get("deletesubmit") !== "true" || m.get("handlekey") !== `a_delete_${n.recordId}`) throw Error("The removal form is incomplete.");
		return u.searchParams.set("inajax", "1"), {
			url: u.href,
			method: "POST",
			body: m.toString()
		};
	}
	async function m(e) {
		e = Da(e);
		try {
			if (!u(e.command.intent)) throw Error("The original favorite attempt is invalid.");
			let t = await d(e.command.intent);
			if (!f(e.command.intent, t)) throw Error("The desired favorite presence/absence is not established. No action was resent.");
			return {
				...e,
				status: "confirmed",
				checked: !0,
				message: e.command.intent.action === "add" ? "Confirmed favorite present." : "Confirmed favorite absent.",
				pages: t
			};
		} catch (t) {
			return {
				...e,
				status: e.status === "confirmed" ? "confirmed" : "uncertain",
				checked: !0,
				message: e.status === "confirmed" ? `Previous confirmation retained. This recheck is inconclusive. ${Ea(t)}` : `Favorite result is uncertain. ${Ea(t)}`
			};
		}
	}
	async function h(e) {
		let n = await m(e);
		return t.set(n.id, Da(n)), n;
	}
	return {
		async prepare(t, r) {
			t = Da(t);
			let i = {
				previousAttemptId: r,
				unresolvedIds: c(t).map((e) => e.id)
			};
			if (!l(t, i)) return {
				kind: "unavailable",
				message: "Check the original uncertain attempt and explicitly authorize a new attempt first."
			};
			if (!u(t) || Oa(e.account()) !== t.accountId) return {
				kind: "unavailable",
				message: "A current member and valid favorite target are required."
			};
			try {
				let r = await d(t), a = {
					id: crypto.randomUUID(),
					generation: e.generation(),
					intent: t
				};
				if (f(t, r)) return {
					kind: "already",
					message: t.action === "add" ? "Already saved." : "Already absent.",
					pages: r
				};
				if (t.action === "remove" && !r.flatMap((e) => e.records).some((e) => e.id === t.recordId && e.removable)) throw Error("The favorite cannot currently be removed.");
				if (await p(a), a.generation !== e.generation() || Oa(e.account()) !== t.accountId) throw Error("The account changed during preparation.");
				if (!l(t, i)) throw Error("Check the original uncertain attempt and explicitly authorize a new attempt first.");
				return n.set(a.id, {
					command: Da(a),
					authorization: i
				}), {
					kind: "ready",
					command: a
				};
			} catch (e) {
				return {
					kind: "unavailable",
					message: Ea(e)
				};
			}
		},
		async execute(a) {
			a = Da(a);
			let o = a.command, c = n.get(o.id), u = s(o.intent), m = (e) => ({
				...a,
				status: "not-sent",
				message: e
			});
			if (!c || !ka(c.command, o) || !l(o.intent, c.authorization) || a.status !== "pending" || r.has(a.id) || i.has(u) || e.generation() !== o.generation || Oa(e.account()) !== o.intent.accountId) return m("This favorite preparation/account is stale or already active. Nothing was sent.");
			r.add(a.id), i.add(u), n.delete(o.id);
			let g = !1;
			try {
				let n = await d(o.intent);
				if (f(o.intent, n)) return {
					...a,
					status: "confirmed",
					checked: !0,
					pages: n,
					message: o.intent.action === "add" ? "Already saved." : "Already absent."
				};
				let r = await p(o);
				return e.generation() !== o.generation || Oa(e.account()) !== o.intent.accountId ? m("The account changed before send. Nothing was sent.") : l(o.intent, c.authorization) ? (t.set(a.id, {
					...a,
					status: "uncertain"
				}), g = !0, await e.transport.request(r.url, {
					fresh: !0,
					...r.method ? {
						method: r.method,
						body: r.body
					} : {}
				}), e.generation() === o.generation ? await h({
					...a,
					status: "uncertain"
				}) : {
					...a,
					status: "uncertain",
					message: "The account changed while the favorite action was in flight. Possible effects remain uncertain."
				}) : m("This favorite preparation/account is stale or already active. Nothing was sent.");
			} catch (e) {
				return g && t.set(a.id, {
					...a,
					status: "uncertain"
				}), g ? {
					...a,
					status: "uncertain",
					message: "The response was lost. The favorite may have changed; check result before considering a new attempt."
				} : m(`Favorite preflight failed before send. ${Ea(e)}`);
			} finally {
				i.delete(u);
			}
		},
		check: h
	};
}
//#endregion
//#region src/forum-client/download.ts
function Ma(e) {
	let t = e.bytes[0] === 255 && e.bytes[1] === 254 ? "utf-16le" : e.bytes[0] === 254 && e.bytes[1] === 255 ? "utf-16be" : "utf-8", n = new TextDecoder(t).decode(e.bytes.subarray(0, 16384)), r = /(?:text\/html|application\/xhtml\+xml)/i.test(e.contentType) || /^\s*</.test(n);
	return e.status === 401 || r && /loginform|name=["']?password|请先登录|尚未登录/i.test(n) ? {
		kind: "login",
		message: "The forum returned a login page instead of a file. Sign in through the native forum, then try again."
	} : r && /captcha|security verification|验证码|安全验证|challenge/i.test(n) ? {
		kind: "challenge",
		message: "The forum returned a verification challenge instead of a file. Complete it in the native forum."
	} : r && /需要付费|付费后下载|购买|payment required/i.test(n) ? {
		kind: "permission",
		message: "The forum requires payment before download. No purchase was attempted and no file is ready to save."
	} : e.status === 403 || r && /没有权限|无权|权限不足|permission|拒绝访问/i.test(n) ? {
		kind: "permission",
		message: "The forum refused download permission. No file is ready to save."
	} : e.status === 404 || e.status === 410 || r && /附件不存在|文件不存在|file not found/i.test(n) ? {
		kind: "missing",
		message: "The attachment file is missing. No file is ready to save."
	} : r ? {
		kind: "invalid",
		message: "The forum returned an HTML page instead of a confirmed file. Nothing is ready to save."
	} : /(?:application\/(?:json|[^;]+\+json)|text\/xml)/i.test(e.contentType) ? {
		kind: "invalid",
		message: "The forum returned a response document instead of a confirmed file. Nothing is ready to save."
	} : e.status !== 200 || e.redirected ? {
		kind: "invalid",
		message: "The forum did not return a complete file. Nothing is ready to save."
	} : !e.bytes.length || e.contentLength !== null && !e.contentEncoding && (!/^\d+$/.test(e.contentLength) || Number(e.contentLength) !== e.bytes.length) ? {
		kind: "invalid",
		message: "The file response was empty or incomplete. Nothing is ready to save."
	} : null;
}
//#endregion
//#region src/forum-client/messages.ts
function Na(e, t) {
	let n = { kind: "unknown" }, r = (e, r = "invalid") => ({
		kind: r,
		message: e,
		account: n,
		sourceURL: t
	}), i = J(t), a = J(e.url);
	if (i?.kind !== "messages" || a?.kind !== "messages" || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType) || i.url.origin !== a.url.origin || (i.url.searchParams.get("page") ?? "1") !== (a.url.searchParams.get("page") ?? "1")) return r("The forum returned an unsupported private-message list. The new-message prompt may still have been cleared.");
	let o = e.body, s = null;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(o)) try {
		let e = JSON.parse(o);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		"uid" in e && typeof e.uid == "number" && Number.isSafeInteger(e.uid) && e.uid >= 0 && (s = e.uid), o = `${"head" in e && typeof e.head == "string" ? e.head : ""}${e.document}`;
	} catch {
		return r("The private-message response could not be interpreted. The new-message prompt may still have been cleared.");
	}
	let c = q(o), l = X(c, e.url), u = s === null ? { kind: "unknown" } : s === 0 ? { kind: "guest" } : {
		kind: "member",
		id: String(s),
		name: `Member ${s}`
	}, d = (e) => e.kind === "member" ? `member:${e.id}` : e.kind;
	n = l.kind === "unknown" ? u : u.kind !== "unknown" && d(l) !== d(u) ? { kind: "unknown" } : l;
	let f = G(V(c, "messagetext") ?? V(c, "main_message")), p = G(B(c, (e) => e.tagName === "title")[0]);
	if (V(c, "challenge-form") || V(c, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(p)) return r("Native verification is required before loading messages.", "challenge");
	if (e.status === 401 || n.kind === "guest" || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(f)) return r("Sign in through the native forum before loading messages deliberately.", "login");
	if (e.status === 403 || /权限|權限|用户组|用戶組|無權/.test(f)) return r("The current account cannot read these messages.", "permission");
	if (e.status === 429) return r("The forum is limiting message requests. Retry only deliberately.", "limited");
	if (e.status < 200 || e.status >= 300 || f || n.kind !== "member") return r("The private-message list or its current account could not be confirmed.");
	let m = V(c, "ct"), h = m && B(m, (e) => e.tagName === "a" && !!z(e, "href")).some((t) => {
		let n = K(z(t, "href"), e.url), r = n && J(n);
		return r && r.kind === "messages" && r.url.origin === i.url.origin && r.url.searchParams.get("filter") === "privatepm";
	});
	if (!m || !h) return r("The private-message list could not be recognized. Continue in the native forum.");
	let g = B(m, (e) => U(e, "pml")), _ = g.flatMap((e) => R(e).filter((e) => "tagName" in e && e.tagName === "dl")).map((t) => {
		let n = /^pmlist_([1-9]\d*)$/.exec(z(t, "id"))?.[1], r = B(t, (e) => e.tagName === "dd" && U(e, "pm_c"))[0], a = B(t, (e) => e.tagName === "dd" && U(e, "avt"))[0], o = a && B(a, (e) => e.tagName === "a")[0], s = o && K(z(o, "href"), e.url), c = s && new URL(s).searchParams.get("uid"), l = r && R(r).find((t) => {
			if (!("tagName" in t) || t.tagName !== "a") return !1;
			let n = K(z(t, "href"), e.url);
			if (!n) return !1;
			let r = new URL(n);
			return r.origin === i.url.origin && r.pathname === "/home.php" && r.searchParams.get("mod") === "space" && r.searchParams.get("uid") === c;
		}), u = l && K(z(l, "href"), e.url), d = G(l), f = n && V(t, `pmlist_${n}_a`), p = f && K(z(f, "href"), e.url), m = p ? new URL(p) : null, h = r && B(r, (e) => e.tagName === "span" && U(e, "xg1"))[0], g = h && B(h, (e) => !!z(e, "title"))[0], _ = g ? z(g, "title") : G(h), v = !1, y = "";
		for (let e of r ? R(r) : []) if ("tagName" in e && e.tagName === "br") {
			if (v) break;
			v = !0;
		} else if (v) {
			if (U(e, "xg1") || U(e, "pm_o")) break;
			y += W(e);
		}
		let b = (e) => e && new URL(e).origin === i.url.origin && new URL(e).pathname === "/home.php" && new URL(e).searchParams.get("mod") === "space" && new URL(e).searchParams.get("uid") === c;
		return !n || !c || !/^[1-9]\d*$/.test(c) || !b(s) || !b(u) || !d || !v || !_ || !m || m.origin !== i.url.origin || m.pathname !== "/home.php" || m.searchParams.get("mod") !== "space" || m.searchParams.get("do") !== "pm" || m.searchParams.get("subop") !== "view" || m.searchParams.get("touid") !== c || [...m.searchParams.keys()].some((e) => ![
			"mod",
			"do",
			"subop",
			"touid"
		].includes(e) || m.searchParams.getAll(e).length !== 1) ? null : {
			id: n,
			peerId: c,
			name: d,
			url: m.href,
			preview: y.replaceAll("\xA0", " ").trim(),
			time: _,
			unread: U(t, "newpm")
		};
	}), v = B(m, (e) => U(e, "emp")).map(G).filter(Boolean).join(" ");
	if (_.some((e) => e === null) || new Set(_.map((e) => e?.peerId)).size !== _.length || new Set(_.map((e) => e?.id)).size !== _.length || _.length && g.length !== 1 || !_.length && !v) return r("The private-message peers could not be identified completely. Continue in the native forum.");
	let y = B(m, (e) => U(e, "pg")), b = y.flatMap((e) => B(e, (e) => e.tagName === "a")).map((t) => {
		let n = K(z(t, "href"), e.url), r = n && J(n);
		return r && r.kind === "messages" && r.url.origin === i.url.origin && G(t) ? {
			url: Y(r.url.href),
			label: G(t)
		} : null;
	}), x = a.url.searchParams.get("page") ?? "1";
	return b.some((e) => !e) || y.some((e) => {
		let t = G(B(e, (e) => e.tagName === "strong")[0]);
		return t && t !== x;
	}) ? r("The returned private-message pagination could not be preserved completely. Continue in the native forum.") : {
		kind: "messages",
		account: n,
		sourceURL: Y(e.url),
		messages: {
			url: Y(e.url),
			peers: _.filter((e) => e !== null),
			pages: {
				current: x,
				links: [...new Map(b.filter((e) => e !== null).map((e) => [e.url, e])).values()]
			},
			empty: v
		}
	};
}
//#endregion
//#region src/forum-client/notices.ts
function Pa(e, t) {
	let n = e;
	for (; n && "tagName" in n;) {
		if (t(n)) return !0;
		n = n.parentNode;
	}
	return !1;
}
function Fa(e) {
	return e.some((e) => e.kind === "text" ? !!e.text.trim() : e.kind === "unsupported" || e.tag === "img" || Fa(e.children));
}
function Ia(e) {
	return e.map((e) => {
		if (e.kind === "text") return e;
		let t = Ia([...e.children]);
		return e.kind === "element" && [e.attributes.href, e.attributes.src].some((e) => e && [...new URL(e).searchParams.keys()].some((e) => e.toLowerCase() === "formhash")) ? {
			kind: "unsupported",
			description: "This action requires current native forum controls.",
			children: t
		} : {
			...e,
			children: t
		};
	});
}
function La(e, t) {
	return (e.searchParams.get("view") ?? "all") === (t.searchParams.get("view") ?? "all") && (e.searchParams.get("type") ?? "") === (t.searchParams.get("type") ?? "");
}
function Ra(e, t) {
	let n = { kind: "unknown" }, r = (e, r = "invalid") => ({
		kind: r,
		message: e,
		account: n,
		sourceURL: t
	}), i = J(t), a = J(e.url);
	if (i?.kind !== "notices" || a?.kind !== "notices" || i.url.origin !== a.url.origin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType)) return r("The forum returned an unsupported notice response. This request may still have marked notices read.");
	let o = e.body, s = null;
	if (/json/i.test(e.contentType) || /^\s*\{/.test(o)) try {
		let e = JSON.parse(o);
		if (!e || typeof e != "object" || !("document" in e) || typeof e.document != "string") throw Error();
		"uid" in e && typeof e.uid == "number" && Number.isSafeInteger(e.uid) && e.uid >= 0 && (s = e.uid), o = `${"head" in e && typeof e.head == "string" ? e.head : ""}${e.document}`;
	} catch {
		return r("The notice response could not be interpreted. This request may still have marked notices read.");
	}
	let c = q(o), l = X(c, e.url), u = s === null ? { kind: "unknown" } : s === 0 ? { kind: "guest" } : {
		kind: "member",
		id: String(s),
		name: `Member ${s}`
	}, d = (e) => e.kind === "member" ? `member:${e.id}` : e.kind;
	n = l.kind === "unknown" ? u : u.kind !== "unknown" && d(u) !== d(l) ? { kind: "unknown" } : l;
	let f = G(V(c, "messagetext") ?? V(c, "main_message")), p = G(B(c, (e) => e.tagName === "title")[0]);
	if (V(c, "challenge-form") || V(c, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(p)) return r("Native verification is required. This request may still have marked notices read.", "challenge");
	if (e.status === 401 || n.kind === "guest" || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(f)) return r("Sign in through the native forum before loading notices deliberately. This request may still have had read effects.", "login");
	if (e.status === 403 || /权限|權限|用户组|用戶組|無權/.test(f)) return r("The current account cannot read these notices. This request may still have had read effects.", "permission");
	if (e.status === 429) return r("The forum is limiting requests. Retry notices only deliberately; this request may still have had read effects.", "limited");
	if (e.status < 200 || e.status >= 300 || f) return r("The notices could not be displayed reliably. This request may still have marked notices read.");
	if (n.kind !== "member") return r("The current notice account could not be confirmed. This request may still have had read effects.");
	if (!La(i.url, a.url) || (i.url.searchParams.get("page") ?? "1") !== (a.url.searchParams.get("page") ?? "1") || i.url.searchParams.get("isread") !== a.url.searchParams.get("isread")) return r("The forum returned a different notice category or page. This request may still have had read effects.");
	let m = V(c, "ct");
	if (!m) return r("The complete notice list could not be recognized. Continue in the native forum; this request may still have marked notices read.");
	let h = B(m, (e) => U(e, "nts")), g = h.length === 1 ? h[0] : void 0, _ = (g ? R(g).filter((e) => "tagName" in e && e.tagName === "dl") : []).map((t) => {
		let n = z(t, "notice") || /^notice_([1-9]\d*)$/.exec(z(t, "id"))?.[1] || "", r = B(t, (e) => e.tagName === "dd" && U(e, "ntc_body")), i = R(t).find((e) => "tagName" in e && e.tagName === "dt"), a = i && B(i, (e) => e.tagName === "span" && !!z(e, "title"))[0], o = i && B(i, (e) => e.tagName === "span")[0], s = a && z(a, "title") || G(o), c = r.length === 1 ? Ia(Br(r[0], e.url)) : [];
		return /^[1-9]\d*$/.test(n) && s && Fa(c) ? {
			id: n,
			time: s,
			body: c
		} : null;
	});
	if (_.some((e) => e === null) || new Set(_.map((e) => e?.id)).size !== _.length) return r("A notice has incomplete or ambiguous content. Continue in the native forum for the complete list; this request may still have marked notices read.");
	let v = B(m, (e) => U(e, "emp")).map(G).filter(Boolean).join(" ");
	if ((!g || !_.length) && !v) return r("The complete notice list could not be recognized. Continue in the native forum; this request may still have marked notices read.");
	let y = [...B(m, (e) => e.tagName === "a" && Pa(e, (e) => U(e, "tbn") || U(e, "tb") || U(e, "subsub")) && !Pa(e, (e) => U(e, "nts"))).flatMap((t) => {
		let n = K(z(t, "href"), e.url), r = n && J(n);
		return r && r.kind === "notices" && r.url.origin === i.url.origin && G(t) ? [{
			url: Y(r.url.href),
			label: G(t),
			current: Pa(t, (e) => e.tagName === "li" && U(e, "a"))
		}] : [];
	}).reduce((e, t) => {
		let n = e.get(t.url);
		return e.set(t.url, {
			...t,
			current: t.current || n?.current === !0
		}), e;
	}, /* @__PURE__ */ new Map()).values()];
	if (!y.length) return r("The returned notice categories could not be recognized. Continue in the native forum for the complete inbox; this request may still have marked notices read.");
	let b = {
		current: a.url.searchParams.get("page") ?? "1",
		links: []
	}, x = B(m, (e) => (U(e, "pg") || U(e, "page")) && !Pa(e, (e) => U(e, "nts"))), S = x.flatMap((e) => B(e, (e) => e.tagName === "a")), C = S.map((t) => {
		let n = K(z(t, "href"), e.url);
		return n ? J(n) : null;
	}), w = a.url.searchParams.get("isread") ?? C[0]?.url.searchParams.get("isread") ?? null;
	if (C.some((e) => !e || e.kind !== "notices" || e.url.origin !== i.url.origin || !La(e.url, a.url) || e.url.searchParams.get("isread") !== w)) return r("The returned notice pagination could not be preserved completely. Continue in the native forum; this request may still have marked notices read.");
	if (x.length) {
		let t = x.map((e) => G(B(e, (e) => e.tagName === "strong")[0]) || b.current);
		if (new Set(t).size !== 1) return r("The returned notice pagination could not be preserved completely. Continue in the native forum; this request may still have marked notices read.");
		b.current = t[0], b.links = [...new Map(S.map((t) => {
			let n = Y(K(z(t, "href"), e.url));
			return [n, {
				url: n,
				label: G(t)
			}];
		})).values()];
	} else b.links = [];
	let T = B(c, (e) => z(e, "id") === "myprompt" && !Pa(e, (e) => U(e, "nts"))), ee = T.length === 1 ? /[（(]\s*(\d+)\s*[）)]\s*$/.exec(G(T[0]))?.[1] : void 0, te = T.length ? ee !== void 0 && Number.isSafeInteger(Number(ee)) ? {
		kind: "observed",
		count: Number(ee)
	} : { kind: "unknown" } : { kind: "absent" };
	return {
		kind: "notices",
		account: n,
		sourceURL: Y(e.url),
		notices: {
			url: Y(e.url),
			categories: y,
			entries: _.filter((e) => e !== null),
			pages: b,
			empty: _.length ? "" : v,
			unread: te
		}
	};
}
//#endregion
//#region src/forum-client/search.ts
var za = {
	srchtxt: "Keywords",
	srchuname: "Author",
	srchfrom: "Time range",
	before: "Time relation",
	orderby: "Order",
	ascdesc: "Direction",
	"srchfid[]": "Boards",
	srchfilter: "Search scope",
	"special[]": "Thread types",
	seltableid: "Search index"
}, Ba = (e, t) => e.attrs.some((e) => e.name === t);
function Va(e) {
	if (Ba(e, "disabled")) return !0;
	let t = e.parentNode;
	for (; t && "tagName" in t;) {
		if (["fieldset", "optgroup"].includes(t.tagName) && Ba(t, "disabled")) return !0;
		t = t.parentNode;
	}
	return !1;
}
var Ha = (e) => Ba(e, "selected") || Ba(e, "checked");
function Ua(e) {
	let t = e;
	for (; t && "tagName" in t;) {
		if (Ba(t, "hidden") || /(?:^|;)\s*display\s*:\s*none\s*(?:;|$)/i.test(z(t, "style"))) return !0;
		t = t.parentNode;
	}
	return !1;
}
function Wa(e, t) {
	let n = B(t, (t) => t.tagName === "label" && z(t, "for") === z(e, "id") && !!z(e, "id"))[0];
	return {
		label: n ? G(n) : za[z(e, "name")] ?? z(e, "name"),
		labelFromForum: !!n
	};
}
function Ga(e, t, n = { kind: "unknown" }, r) {
	return {
		kind: "invalid",
		message: t,
		account: n,
		sourceURL: e,
		...r === void 0 ? {} : { nativeText: r }
	};
}
function Ka(e, t) {
	let n = B(e, (e) => e.tagName === "head")[0];
	if (!n) return null;
	let r = R(n).filter((e) => "tagName" in e && e.tagName === "script" && !Ba(e, "src")).map((e) => R(e).map((e) => "value" in e ? e.value : "").join("")).filter((e) => /^\s*var\s+STYLEID\s*=/.test(e));
	if (!r.length) return null;
	let i = { kind: "unknown" };
	if (r.length !== 1) return i;
	let a = r[0].replace(/^\s*var\s+/, ""), o = /\s*([A-Za-z_$][\w$]*)\s*=\s*(?:'([^'\\\r\n]*)'|"([^"\\\r\n]*)")\s*([,;])/gy, s = /* @__PURE__ */ new Map(), c;
	for (;;) {
		let e = o.exec(a);
		if (!e || s.has(e[1])) return i;
		if (s.set(e[1], e[2] ?? e[3]), c = o.lastIndex, e[4] === ";") break;
	}
	if (a.slice(c).trim() || [...s.keys()].slice(0, 6).join(",") !== "STYLEID,STATICURL,IMGDIR,VERHASH,charset,discuz_uid") return i;
	let l = s.get("discuz_uid") ?? "";
	return !/^(?:0|[1-9]\d*)$/.test(l) || !Number.isSafeInteger(Number(l)) || s.get("SITEURL") !== `${new URL(t).origin}/` ? i : l === "0" ? { kind: "guest" } : {
		kind: "member",
		id: l,
		name: `Member ${l}`
	};
}
function qa(e, t) {
	try {
		if (new URL(e.url).origin !== new URL(t).origin || !/^(?:text\/html|application\/(?:json|[^;]+\+json))(?:;|$)/i.test(e.contentType)) return null;
		let n = e.body, r = null;
		if (/json/i.test(e.contentType) || /^\s*\{/.test(n)) {
			let e = JSON.parse(n);
			if (!e || typeof e != "object" || "type" in e && e.type === "result" || "kind" in e && e.kind === "redirect" || !("document" in e) || typeof e.document != "string") return null;
			"uid" in e && typeof e.uid == "number" && Number.isSafeInteger(e.uid) && e.uid >= 0 && (r = e.uid === 0 ? { kind: "guest" } : {
				kind: "member",
				id: String(e.uid),
				name: `Member ${e.uid}`
			}), n = `${"head" in e && typeof e.head == "string" ? e.head : ""}${e.document}`;
		}
		let i = q(n), a = X(i, e.url), o = Ka(i, e.url), s = [
			a,
			r,
			o
		].filter((e) => e !== null && e.kind !== "unknown"), c = s[0] ?? { kind: "unknown" };
		return {
			doc: i,
			account: o?.kind === "unknown" || s.some((e) => e.kind !== c.kind || e.kind === "member" && c.kind === "member" && e.id !== c.id) ? { kind: "unknown" } : c
		};
	} catch {
		return null;
	}
}
function Ja(e, t, n, r) {
	let i = G(V(e, "messagetext") ?? V(e, "main_message")), a = G(B(e, (e) => e.tagName === "title")[0]), o = (e, t, i) => ({
		kind: e,
		message: t,
		account: r,
		sourceURL: n,
		...i === void 0 ? {} : { nativeText: i }
	});
	return V(e, "challenge-form") || V(e, "cf-challenge-running") || /Just a moment|Checking your browser|安全验证|驗證您的瀏覽器/i.test(a) ? o("challenge", "Native verification is required before another deliberate search.") : t.status === 401 || r.kind === "guest" || /未登录|未登錄|先登录|先登錄|登录后|登入後/.test(i) ? o("login", "Sign in through the native forum before another deliberate search.") : /过期|過期|失效|expired/i.test(i) ? o("expired", "Search results expired. Your criteria are retained; rerun explicitly if you accept possible credits or quota use.") : /积分|積分|金币|金幣|天使币|天使幣|花费|花費|credits?|cost/i.test(i) ? o("cost", `Search cost restriction: ${i}`, i) : t.status === 429 || /秒内|秒內|频繁|頻繁|间隔|間隔|稍后|稍後|throttl|frequency|rate limit/i.test(i) ? o("throttle", `Search frequency restriction: ${i || "The forum is limiting requests. Retry explicitly later."}`, i || null) : t.status === 403 || /权限|權限|用户组|用戶組|無權/.test(i) ? o("permission", `Search permission denied: ${i || "The current account cannot search."}`, i || null) : t.status < 200 || t.status >= 300 || i ? o("invalid", `The search response could not be interpreted: ${i || "Unexpected HTTP response."}`, i || null) : null;
}
function Ya(e, t) {
	let n = B(e, (e) => e.tagName === "form" && B(e, (e) => z(e, "name") === "srchuname").length > 0);
	if (n.length !== 1) return null;
	let r = n[0], i = K(z(r, "action"), t);
	if (!i || new URL(i).origin !== new URL(t).origin || new URL(i).pathname !== "/search.php" || new URL(i).searchParams.get("mod") !== "forum" || z(r, "method").toLowerCase() !== "post" || [...new URL(i).searchParams].some(([e, t]) => e !== "mod" || t !== "forum") || z(r, "enctype") !== "" && z(r, "enctype").toLowerCase() !== "application/x-www-form-urlencoded") return null;
	let a = B(r, (e) => [
		"input",
		"select",
		"textarea",
		"button"
	].includes(e.tagName)).filter((e) => !Va(e));
	for (let e of ["formhash", "searchsubmit"]) {
		let t = a.filter((t) => z(t, "name") === e);
		if (t.length !== 1 || z(t[0], "type") !== "hidden" || !z(t[0], "value") || e === "searchsubmit" && z(t[0], "value") !== "yes") return null;
	}
	let o = /* @__PURE__ */ new Map();
	for (let e of a) {
		if ([
			"formaction",
			"formmethod",
			"formenctype"
		].some((t) => Ba(e, t))) return null;
		let t = z(e, "name"), n = z(e, "type") || "text";
		if (!t || e.tagName === "button" || ["submit", "button"].includes(n)) continue;
		if (e.tagName === "textarea" || e.tagName === "input" && ![
			"text",
			"hidden",
			"radio",
			"checkbox"
		].includes(n)) return null;
		let r = e.tagName === "select" ? "select" : n, i = o.get(t);
		if (i && (!["radio", "checkbox"].includes(r) || i !== r)) return null;
		o.set(t, r);
	}
	let s = [];
	for (let t of B(r, (e) => [
		"input",
		"select",
		"textarea"
	].includes(e.tagName))) {
		let n = z(t, "name"), r = z(t, "type") || "text";
		if (!n || ["submit", "button"].includes(r) || r === "hidden" && [
			"formhash",
			"searchsubmit",
			"seltableid"
		].includes(n) || n === "seltableid" && Ua(t)) continue;
		if (!Object.hasOwn(za, n) && !Va(t)) return null;
		if (Va(t) && s.some((e) => e.name === n && !e.disabled)) continue;
		let i = ["checkbox", "radio"].includes(r), a = i && s.find((e) => e.name === n), o = {
			value: z(t, "value"),
			label: G(t.parentNode ?? t) || z(t, "value"),
			disabled: Va(t)
		};
		if (a) {
			a.options.push(o), Ha(t) && !Va(t) && a.values.push(z(t, "value"));
			continue;
		}
		let c = t.tagName === "select" ? B(t, (e) => e.tagName === "option").map((e) => ({
			value: Ba(e, "value") ? z(e, "value") : G(e),
			label: G(e),
			disabled: Va(e),
			selected: Ha(e)
		})) : [], l = t.tagName === "select" ? c.filter((e) => e.selected && !e.disabled).map((e) => e.value) : i ? Ha(t) && !Va(t) ? [z(t, "value")] : [] : [z(t, "value")], u = r === "checkbox" || Ba(t, "multiple");
		if (t.tagName === "select" && !u && !l.length) {
			let e = c.find((e) => !e.disabled);
			e && l.push(e.value);
		}
		s.push({
			name: n,
			...Wa(t, e),
			kind: t.tagName === "select" ? "select" : i ? "choices" : "text",
			multiple: u,
			disabled: Va(t),
			readOnly: Ba(t, "readonly"),
			maxLength: /^\d+$/.test(z(t, "maxlength")) ? Number(z(t, "maxlength")) : null,
			options: i ? [o] : c.map(({ value: e, label: t, disabled: n }) => ({
				value: e,
				label: t,
				disabled: n
			})),
			values: l
		});
	}
	let c = B(r, (e) => U(e, "search-restrictions") || U(e, "xg1")).map(G).filter(Boolean);
	return {
		form: {
			url: Y(t),
			fields: s,
			restrictions: c
		},
		node: r
	};
}
function Xa(e, t) {
	let n = qa(e, t);
	if (!n) return Ga(t, "The search form response could not be displayed reliably.");
	let { doc: r, account: i } = n, a = Ja(r, e, t, i);
	if (a) return a;
	let o = Ya(r, t);
	return o ? {
		kind: "search",
		account: i,
		sourceURL: Y(t),
		search: {
			form: o.form,
			edited: Object.fromEntries(o.form.fields.filter((e) => !e.disabled).map((e) => [e.name, e.values])),
			effective: null,
			submitted: null,
			results: null
		}
	} : Ga(t, "The current advanced search form is unavailable. Continue in the native forum.", i);
}
function Za(e, t, n) {
	let r = Xa(e, t);
	if (r.kind !== "search") return r;
	let { doc: i } = qa(e, t), a = Ya(i, t), o = (e, n) => Ga(t, e, r.account, n);
	if (!n.srchtxt?.[0]?.trim() && !n.srchuname?.[0]?.trim()) return o("Enter keywords or an author before searching.");
	let s = a.form.fields.filter((e) => !e.disabled);
	if (Object.keys(n).some((e) => !s.some((t) => t.name === e)) || s.some((e) => !Object.hasOwn(n, e.name))) return o("Search controls changed. Refresh the form and review your criteria.");
	for (let e of s) {
		let t = n[e.name] ?? e.values;
		if (e.readOnly && JSON.stringify(t) !== JSON.stringify(e.values) || !e.multiple && t.length > 1 || new Set(t).size !== t.length || (e.kind === "text" ? t.length !== 1 || e.maxLength !== null && t[0].length > e.maxLength : t.some((t) => !e.options.some((e) => !e.disabled && e.value === t)))) return o(`The current ${e.label} restriction does not allow this value. Review your criteria.`, e.labelFromForum === !1 ? null : e.label);
	}
	let c = [];
	for (let e of B(a.node, (e) => ["input", "select"].includes(e.tagName))) {
		let t = z(e, "name"), r = z(e, "type") || "text";
		if (!t || Va(e) || ["button", "submit"].includes(r)) continue;
		if (r === "hidden") {
			c.push([t, z(e, "value")]);
			continue;
		}
		let i = t === "seltableid" && Ua(e) ? B(e, (e) => e.tagName === "option" && Ha(e) && !Va(e)).map((e) => z(e, "value")) : n[t] ?? s.find((e) => e.name === t)?.values ?? [];
		if (e.tagName === "select") for (let n of B(e, (e) => e.tagName === "option")) {
			let e = Ba(n, "value") ? z(n, "value") : G(n);
			!Va(n) && i.includes(e) && c.push([t, e]);
		}
		else ["checkbox", "radio"].includes(r) ? i.includes(z(e, "value")) && c.push([t, z(e, "value")]) : c.push([t, i[0] ?? ""]);
	}
	let l = new URL(z(a.node, "action"), t);
	return l.searchParams.set("tsdmapp", "json"), {
		kind: "prepared",
		form: a.form,
		account: r.account,
		url: l.href,
		body: new URLSearchParams(c).toString()
	};
}
function Qa(e, t) {
	try {
		if (e.status !== 200 || e.url !== t || !/^application\/(?:json|[^;]+\+json)(?:;|$)/i.test(e.contentType)) return null;
		let n = JSON.parse(e.body);
		if (!n || typeof n != "object" || Array.isArray(n) || !("ok" in n) || n.ok !== 1 || !("api" in n) || n.api !== 1 || !("type" in n) || n.type !== "result" || !("schema" in n) || n.schema !== 13 || !("kind" in n) || n.kind !== "redirect" || !("message" in n) || n.message !== "" || !("message_key" in n) || n.message_key !== "" || !("handlekey" in n) || n.handlekey !== "" || !("login" in n) || n.login !== 0 || !("alert" in n) || n.alert !== "" || !("values" in n) || !n.values || typeof n.values != "object" || Array.isArray(n.values) || Object.keys(n.values).length !== 0 || "document" in n || "head" in n || !("uid" in n) || typeof n.uid != "number" || !Number.isSafeInteger(n.uid) || n.uid < 0 || !("url" in n) || typeof n.url != "string") return null;
		let r = J(new URL(n.url, t).href);
		return r?.kind !== "search" || r.url.origin !== new URL(t).origin || r.url.hash || !r.url.searchParams.has("searchid") || r.url.searchParams.get("searchsubmit") !== "yes" ? null : {
			url: r.url,
			id: r.url.searchParams.get("searchid"),
			account: n.uid === 0 ? { kind: "guest" } : {
				kind: "member",
				id: String(n.uid),
				name: `Member ${n.uid}`
			}
		};
	} catch {
		return null;
	}
}
function $a(e, t, n, r) {
	let i = qa(e, t);
	if (!i) return Ga(t, "The search result could not be displayed reliably. The request may still have used credits or quota.");
	let { doc: a, account: o } = i, s = Ja(a, e, t, o);
	if (s) return s;
	let c = (e) => Ga(t, e, o), l = [e.url, ...B(a, (e) => e.tagName === "a").map((t) => K(z(t, "href"), e.url)).filter((e) => e !== null)].map((e) => J(e)).filter((e) => e?.kind === "search" && e.url.origin === new URL(t).origin && e.url.searchParams.has("searchid"))[0];
	if (!l) return c("The forum did not return a usable search identity. It will not be searched again automatically.");
	let u = l.url.searchParams.get("searchid"), d = V(a, "threadlist"), f = d ? B(d, (e) => e.tagName === "li") : [], p = f.map((n) => {
		let r = B(n, (e) => e.tagName === "h3")[0], i = r && B(r, (e) => e.tagName === "a")[0], a = i && K(z(i, "href"), e.url), o = a && J(a), s = B(n, (e) => e.tagName === "a"), c = s.find((t) => {
			let n = K(z(t, "href"), e.url);
			return n && new URL(n).pathname === "/home.php" && new URL(n).searchParams.get("mod") === "space" && /^[1-9]\d*$/.test(new URL(n).searchParams.get("uid") ?? "");
		}), l = s.find((t) => {
			let n = K(z(t, "href"), e.url);
			return n && J(n)?.kind === "board";
		}), u = R(n).filter((e) => "tagName" in e && e.tagName === "p");
		if (!U(n, "pbw") || !i || !o || o.kind !== "thread" || o.url.origin !== new URL(t).origin || !c || !l || !G(i)) return null;
		let d = u.at(-1), f = d && B(d, (e) => e.tagName === "span")[0];
		return {
			id: o.url.searchParams.get("tid"),
			url: o.url.href,
			label: G(i),
			author: {
				label: G(c),
				url: K(z(c, "href"), e.url)
			},
			board: {
				label: G(l),
				url: K(z(l, "href"), e.url)
			},
			date: G(f),
			snippet: G(u[1]),
			stats: G(u[0])
		};
	}), m = B(a, (e) => U(e, "sttl"))[0], h = G(m && B(m, (e) => e.tagName === "em")[0]), g = B(a, (e) => U(e, "emp")).map(G).some((e) => /没有找到匹配结果|沒有找到匹配結果|no (?:matching|results)/i.test(e)), _ = /(?:内容|內容|主题|主題)\s*0\s*个|0\s+(?:results|matches)/i.test(h) && g && f.length === 0;
	if (!p.length && !_ || p.some((e) => !e)) return c("The search contains unrecognized or incomplete results. It has not been treated as zero matches.");
	let v = B(a, (e) => U(e, "pg"))[0], y = v ? B(v, (e) => e.tagName === "a").map((t) => ({
		label: G(t),
		url: K(z(t, "href"), e.url) ?? ""
	})) : [];
	if (y.some((e) => {
		let n = J(e.url);
		return n?.kind !== "search" || n.url.origin !== new URL(t).origin || n.url.searchParams.get("searchid") !== u;
	})) return c("The search contains an unsupported result-page link.");
	let b = { ...r };
	for (let e of ["orderby", "ascdesc"]) {
		let t = l.url.searchParams.get(e);
		t !== null && (b[e] = [t]);
	}
	let x = Y(e.url).includes("searchid=") ? Y(e.url) : l.url.href;
	return {
		kind: "search",
		account: o,
		sourceURL: x,
		search: {
			form: n,
			edited: r,
			effective: b,
			submitted: r,
			results: {
				id: u,
				url: x,
				summary: h,
				rows: p.filter((e) => e !== null),
				pages: {
					current: G(v && B(v, (e) => e.tagName === "strong")[0]) || "1",
					links: y
				}
			}
		}
	};
}
//#endregion
//#region src/forum-client/edit-post.ts
var eo = (e) => JSON.parse(JSON.stringify(e)), to = (e, t) => JSON.stringify(e) === JSON.stringify(t);
function no(e, t) {
	return e.length === t.length && new Set(e).size === e.length && new Set(t).size === t.length && e.every((e) => /^[1-9]\d*$/.test(e) && t.includes(e));
}
function ro(e, t) {
	let { uploadedReferences: n, attachmentFields: r = [], ...i } = e, { uploadedReferences: a, attachmentFields: o = [], ...s } = t;
	return to(i, s) && no(n, a) && r.length === o.length && new Set(r.map((e) => e.name)).size === r.length && new Set(o.map((e) => e.name)).size === o.length && r.every((e) => o.some((t) => t.name === e.name && t.value === e.value && t.disabled === e.disabled));
}
var io = (e) => eo({
	title: e.title,
	titleAvailable: e.titleAvailable ?? !0,
	source: e.source,
	category: e.category,
	options: e.options,
	uploadedReferences: e.uploadedReferences,
	attachmentFields: (e.attachmentFields ?? []).filter((e) => !/^attachupdate\[[1-9]\d*\]$/.test(e.name))
});
function ao(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Set(), r = 0;
	function i(t) {
		let n = new URL("/forum.php", e.origin);
		for (let [e, r] of Object.entries({
			mod: "post",
			action: "edit",
			fid: t.board.id,
			tid: t.editTarget.threadId,
			pid: t.editTarget.postId,
			tsdmapp: "json"
		})) n.searchParams.set(e, r);
		return n.href;
	}
	async function a(t, n) {
		let r = i(t), a = e.generation(), o = oi(await e.transport.request(t.editTarget.threadURL, { fresh: !0 }), t.editTarget.threadURL);
		if (a !== e.generation() || (e.observe(o.account), o.kind !== "thread" || o.account.kind !== "member" || o.account.id !== t.account.id || o.thread.id !== t.editTarget.threadId || o.thread.posts.find((e) => e.id === t.editTarget.postId)?.authorId !== t.account.id)) return null;
		a = e.generation();
		let s = await e.transport.request(r, { fresh: !0 }), c = Z(s, r, t.board.id, t.editTarget);
		return a !== e.generation() || (e.observe(c.account), n?.(e.generation() === a && c.account.kind === "member" && c.account.id === t.account.id), e.generation() !== a || c.account.kind !== "member" || c.account.id !== t.account.id || c.kind !== "prepared") ? null : {
			response: s,
			latest: {
				...c.prepared,
				action: "edit-post",
				draftSaveAvailable: !1,
				...o.thread.posts.find((e) => e.id === t.editTarget.postId)?.redPacketThreadId === t.editTarget.threadId ? { existingRedPacket: !0 } : {},
				editTarget: {
					...t.editTarget,
					baseline: io(c.prepared)
				}
			}
		};
	}
	async function o(t, n) {
		let o = ++r, s = (n) => ({
			kind: "invalid",
			message: n,
			account: e.account(),
			generation: e.generation(),
			sourceURL: t
		}), c;
		try {
			c = new URL(t);
		} catch {
			return s("A valid owned-post destination is required.");
		}
		if (c.origin !== e.origin || c.pathname !== "/forum.php" || c.searchParams.get("mod") !== "viewthread" || !/^[1-9]\d*$/.test(c.searchParams.get("tid") ?? "") || !/^[1-9]\d*$/.test(n)) return s("A valid owned-post destination is required.");
		try {
			let t = e.generation(), l = await e.transport.request(c.href, { fresh: !0 });
			if (o !== r || t !== e.generation()) return s("A newer account request replaced this edit preparation.");
			let u = oi(l, c.href);
			if (e.observe(u.account), u.kind !== "thread" || u.account.kind !== "member" || !u.thread.parent) return s("The owned post could not be established. Your writing is retained.");
			let d = u.thread.posts.find((e) => e.id === n), f = new URL(u.thread.parent.url).searchParams.get("fid");
			if (!d || d.authorId !== u.account.id || !f) return s("Only the current account's own post can be edited.");
			let p = {
				action: "edit-post",
				draftSaveAvailable: !1,
				title: "",
				source: "",
				category: null,
				options: [],
				uploadedReferences: [],
				account: u.account,
				board: {
					id: f,
					label: u.thread.parent.label,
					url: u.thread.parent.url
				},
				editTarget: {
					threadId: u.thread.id,
					postId: n,
					threadURL: c.href,
					baseline: {
						title: "",
						source: "",
						category: null,
						options: [],
						uploadedReferences: []
					}
				}
			}, m = await a(p);
			return o !== r || !m ? s("Actual editable source and current options are unavailable. Rendered content cannot replace complete source.") : {
				kind: "prepared",
				prepared: m.latest,
				account: e.account(),
				generation: e.generation(),
				sourceURL: i(p)
			};
		} catch {
			return s("The editable source could not be reached. Your writing is retained.");
		}
	}
	async function s(n) {
		for (let [e, r] of t) r.submission.contextId === n.contextId && t.delete(e);
		let r = !1, i = (t, n = "validation") => ({
			kind: n,
			accountVerified: n === "validation" && r,
			message: t,
			account: e.account(),
			generation: e.generation()
		});
		n = eo(n);
		let o = n.writing, s = Gi(o);
		if (s.length) return {
			...i("Correct the highlighted fields before reviewing."),
			validation: {
				source: "local",
				issues: s
			}
		};
		if (o.action !== "edit-post" || !o.editTarget || !n.contextId || !Number.isSafeInteger(n.revision) || n.revision < 1 || !o.source.trim()) return i("A complete owned-post edit revision is required.");
		for (let [e, r] of t) r.submission.contextId === n.contextId && t.delete(e);
		try {
			let s = await a(o, (e) => {
				r = e;
			});
			if (!s) return i("Actual current source, options or original account are unavailable. Editing remains paused.");
			if (r = !0, o.mentions?.length) {
				let t = e.generation();
				if (!await Ri(e, o) || e.generation() !== t) return i("A selected mention identity changed or could not be revalidated. Resolve the person again.");
				if (s = await a(o, (e) => {
					r = e;
				}), !s || e.generation() !== t) return i("Actual current source, options or original account are unavailable. Editing remains paused.");
			}
			if (!ro(o.editTarget.baseline, io(s.latest))) return {
				kind: "conflict",
				latest: s.latest,
				message: "The server post changed. Review latest source, options and attachments before saving your version.",
				account: e.account(),
				generation: e.generation()
			};
			let c = Gi(o, s.latest);
			if (c.length) return {
				...i("Correct the highlighted fields required by the current native form."),
				validation: {
					source: "form",
					issues: c
				}
			};
			let l = e.generation(), u = await Ni(e.transport, o, s.response);
			if (e.generation() !== l) return i("The account changed during attachment validation. Review again; nothing was sent.");
			let d = (o.uploads ?? []).filter((e) => e.status === "uploaded").map((e) => e.serverId), f = [], p = u && ca(s.response, o, !1, u, f);
			if (f.length) return {
				...i("Correct the highlighted fields required by the current native form."),
				validation: {
					source: "form",
					issues: f
				}
			};
			if (s.latest.titleAvailable === !1 && o.title !== "" || bi(o).length || !sa(o, s.latest) || !no(o.uploadedReferences.filter((e) => !d.includes(e)), s.latest.uploadedReferences) || !u || !p) return i("Required current form content or attachment references cannot be preserved. Nothing was sent.");
			let m = {
				id: crypto.randomUUID(),
				generation: e.generation(),
				submission: n
			};
			return t.set(m.id, eo(m)), {
				kind: "ready",
				publication: m,
				account: e.account(),
				generation: e.generation()
			};
		} catch {
			return i("Fresh edit preparation failed. Local writing is retained.", "network");
		}
	}
	async function c(t) {
		t = eo(t);
		let n = t.publication.submission.writing, r = n.editTarget, i = (e) => t.status === "confirmed" && t.result ? {
			...t,
			checked: !0,
			message: `Previous stored confirmation retained. This recheck did not verify the current result. ${e}`
		} : {
			...t,
			status: t.status === "moderation" ? "moderation" : "uncertain",
			checked: !0,
			message: t.status === "moderation" ? `Moderation remains pending. ${e}` : e,
			result: null
		};
		if (!r || n.action !== "edit-post") return i("The original edit target is unavailable.");
		try {
			let o = e.generation(), s = await e.transport.request(r.threadURL, { fresh: !0 });
			if (o !== e.generation()) return i("The account changed while checking the saved post.");
			let c = oi(s, r.threadURL);
			if (e.observe(c.account), c.kind !== "thread" || c.account.kind !== "member" || c.account.id !== n.account.id || c.thread.id !== r.threadId || c.thread.posts.find((e) => e.id === r.postId)?.authorId !== n.account.id) return i("Saved actor or post could not be independently established.");
			let l = await a(n), u = l && no(n.uploadedReferences, l.latest.uploadedReferences) ? Xi(n, l.latest) : null;
			return u ? t.status === "moderation" ? {
				...t,
				checked: !0,
				result: null,
				message: "Moderation remains pending. Saved source matches, but the existing public post does not prove this edited revision was released."
			} : {
				...t,
				status: "confirmed",
				checked: !0,
				candidateURL: r.threadURL,
				message: `Confirmed saved post ${r.postId}, submitted revision ${t.publication.submission.revision}.`,
				result: {
					threadId: r.threadId,
					postId: r.postId,
					url: `${r.threadURL.split("#")[0]}#pid${r.postId}`,
					verification: u
				}
			} : i("Complete saved source, options or attachment references are unavailable or differ. No confirmation is claimed.");
		} catch {
			return i("Saved post readback failed. Check this original attempt; nothing was repeated.");
		}
	}
	async function l(t) {
		let n = await c(t), r = t.publication.submission.writing;
		if (!r.existingRedPacket || !r.editTarget || e.account().kind !== "member") return n;
		let i = e.generation(), a = await Hi(e.transport, e.origin, r.editTarget.threadId), o = await Ui(e.transport, e.origin, r.account.id);
		return o.account.kind !== "unknown" && e.observe(o.account), {
			...n,
			redPacket: i === e.generation() ? {
				...a,
				ledger: o.ledger
			} : {
				state: "unknown",
				conditions: [],
				credit: "unknown"
			}
		};
	}
	async function u(r) {
		r = eo(r);
		let i = t.get(r.publication.id), o = r.publication.submission.contextId, s = (e) => ({
			...r,
			status: "not-sent",
			message: e
		});
		if (!i || !to(i, r.publication) || r.status !== "pending" || n.has(o) || e.generation() !== i.generation) return s("This edit preparation is stale or already active. Nothing was sent.");
		t.delete(i.id), n.add(o);
		let c = !1;
		try {
			let t = i.submission.writing;
			if (!await Ri(e, t)) return s("A selected mention identity changed before send. Nothing was sent.");
			if (e.generation() !== i.generation) return s("The account changed before save. Nothing was sent.");
			let n = await a(t);
			if (!n || e.generation() !== i.generation) return s("Current source or original account changed before save. Review again.");
			if (!ro(t.editTarget.baseline, io(n.latest)) || !sa(t, n.latest)) return s("The server post changed before save. Review latest source again; nothing was sent.");
			let o = await Ni(e.transport, t, n.response);
			if (e.generation() !== i.generation) return s("The account changed before save. Nothing was sent.");
			let u = o && ca(n.response, t, !1, o);
			if (!u) return s("Required current form content cannot be preserved. Nothing was sent.");
			c = !0;
			let d = await e.transport.request(u.url, {
				method: "POST",
				body: u.body,
				fresh: !0
			});
			if (e.generation() !== i.generation) return {
				...r,
				status: "uncertain",
				message: "The account changed during save. The edit may have been accepted; no rollback is guaranteed."
			};
			let f = ua(d, e.origin);
			return f.kind === "candidate" ? l({
				...r,
				candidateURL: t.editTarget.threadURL,
				status: "uncertain"
			}) : {
				...r,
				status: f.kind === "unknown" ? "uncertain" : f.kind,
				message: f.message,
				candidateURL: t.editTarget.threadURL
			};
		} catch {
			return c ? {
				...r,
				status: "uncertain",
				candidateURL: i.submission.writing.editTarget.threadURL,
				message: "The edit response was lost. Check the original saved post; nothing was repeated."
			} : s("Fresh edit preflight failed. Your source remains retained.");
		} finally {
			n.delete(o);
		}
	}
	return {
		load: o,
		prepare: s,
		save: u,
		check: l
	};
}
//#endregion
//#region src/forum-client/private-writing.ts
var oo = class extends Error {
	issue;
	constructor(e, t) {
		super(e), this.issue = t;
	}
};
function so(e) {
	let t = /* @__PURE__ */ new Map(), n = 0;
	async function r(t, n) {
		let r = J(t);
		if (r?.kind !== "private-conversation" || r.url.origin !== e.origin || n.kind !== "member") throw Error("Choose a current one-to-one private conversation while signed in.");
		let i = e.generation();
		r.url.searchParams.set("tsdmapp", "json");
		let a = await e.transport.request(r.url.href, { fresh: !0 });
		if (i !== e.generation()) throw Error("The account changed during preparation. Review again.");
		let o = mi(a, t);
		if (e.observe(o.account), o.kind !== "private-conversation" || o.account.kind !== "member" || o.account.id !== n.id) throw Error("The current sender or private recipient could not be confirmed. Your text is retained.");
		let s = a.body;
		if (/json/i.test(a.contentType) || /^\s*\{/.test(s)) {
			let e = JSON.parse(s);
			s = (typeof e.head == "string" ? e.head : "") + e.document;
		}
		let c = q(s), l = B(c, (e) => e.tagName === "form" && z(e, "id") === "pmform"), u = () => {
			throw Error("The current private-message form is not supported. Keep your text and continue in the native forum.");
		};
		if (l.length !== 1) return u();
		let d = l[0], f = new URL(z(d, "action"), a.url);
		if (z(d, "method").toLowerCase() !== "post" || f.origin !== e.origin || f.pathname !== "/home.php" || f.hash || f.username || f.password) return u();
		let p = {
			mod: "spacecp",
			ac: "pm",
			op: "send",
			daterange: "0",
			handlekey: "pmsend",
			pmsubmit: "yes"
		};
		if (Object.entries(p).some(([e, t]) => f.searchParams.getAll(e).length !== 1 || f.searchParams.get(e) !== t) || !/^[1-9]\d*$/.test(f.searchParams.get("pmid") ?? "") || f.searchParams.getAll("pmid").length !== 1 || [...f.searchParams.keys()].some((e) => !(e in p) && e !== "pmid") || !o.conversation.messages.some((e) => e.id === f.searchParams.get("pmid"))) return u();
		let m = B(d, (e) => [
			"input",
			"textarea",
			"select",
			"button"
		].includes(e.tagName));
		if (B(c, (e) => z(e, "form") === "pmform").length || m.some((e) => z(e, "form") || H(e))) return u();
		let h = (e) => m.filter((t) => z(t, "name") === e), g = h("formhash"), _ = h("topmuid"), v = h("message"), y = h("pmsubmit");
		if (g.length !== 1 || _.length !== 1 || v.length !== 1 || y.length !== 1 || m.some((e) => ![
			"formhash",
			"topmuid",
			"message",
			"pmsubmit"
		].includes(z(e, "name"))) || g[0].tagName !== "input" || z(g[0], "type") !== "hidden" || z(_[0], "type") !== "hidden" || _[0].tagName !== "input" || v[0].tagName !== "textarea" || !z(g[0], "value") || z(_[0], "value") !== o.conversation.peerId || v[0].attrs.some((e) => e.name === "readonly")) return u();
		let b = z(v[0], "maxlength");
		return b && (!/^[1-9]\d*$/.test(b) || !Number.isSafeInteger(Number(b))) ? u() : {
			prepared: {
				action: "private-message",
				account: o.account,
				recipient: {
					id: o.conversation.peerId,
					name: o.conversation.peerName,
					url: t
				},
				source: "",
				maxLength: b ? Number(b) : null
			},
			token: z(g[0], "value"),
			action: f.href,
			conversation: o.conversation,
			exactText: new Map(o.conversation.messages.map((e) => [e.id, co(c, e.id, a.url)]))
		};
	}
	let i = (t) => ({
		kind: "refused",
		message: t instanceof Error ? t.message : "The private-message form could not be reached. Your text is retained.",
		account: e.account(),
		generation: e.generation()
	});
	function a(t) {
		let n = e.account();
		return n.kind === "member" && n.id === t.submission.writing.account.id && e.generation() === t.generation;
	}
	async function o(e) {
		let t = structuredClone(e);
		if (mo(t) && t.status === "not-sent") return t;
		let n = (e) => ({
			...t,
			status: "uncertain",
			checked: !0,
			message: e,
			result: null
		});
		if (!mo(t) || !t.before.length) return n("The original pre-send history is unavailable. Continue in the native forum; nothing was resent.");
		try {
			let e = t.submission.writing, i = await r(e.recipient.url, e.account);
			if (!i.conversation.beginning || !i.conversation.end) return n("The current history is incomplete. The outcome remains uncertain; nothing was resent.");
			let a = i.conversation.messages.filter((n) => !t.before.includes(n.id) && n.senderId === e.account.id && i.exactText.get(n.id) === e.source);
			if (a.length !== 1) return n("The stored sender, recipient and exact text could not be uniquely confirmed. Check the original attempt deliberately; do not resend automatically.");
			let o = a[0];
			return {
				...t,
				status: "confirmed",
				checked: !0,
				message: "Stored private message independently verified. Delivery and read status are unknown.",
				result: {
					messageId: o.id,
					url: o.url,
					senderId: o.senderId,
					recipientId: i.conversation.peerId,
					source: e.source
				}
			};
		} catch {
			return n("Independent result checking could not confirm the private message. Your original attempt and current text are retained; nothing was resent.");
		}
	}
	return {
		check: o,
		async send(i, s, c) {
			let l = n, u = structuredClone(s), d = (e) => ({
				...u,
				status: "not-sent",
				checked: !1,
				message: e,
				result: null
			}), f = i?.id, p = t.get(f);
			if (t.delete(f), !mo(u) || u.status !== "pending" || !p || p !== JSON.stringify(i) || JSON.stringify(u.submission) !== JSON.stringify(i.submission) || !a(i)) return d("Private message was not sent: review approval is missing, used or stale.");
			let m;
			try {
				let e = u.submission.writing;
				if (m = await r(e.recipient.url, e.account), l !== n || !a(i) || m.prepared.recipient.id !== e.recipient.id || m.prepared.maxLength !== e.maxLength || !m.conversation.beginning || !m.conversation.end) return d("Private message was not sent because the current sender, recipient, restrictions or complete history changed. Review again.");
				if (u = {
					...u,
					before: m.conversation.messages.map((e) => e.id)
				}, !await c(structuredClone(u)) || l !== n || !a(i)) return d("Private message was not sent because recovery or the account changed. Your text is retained.");
			} catch {
				return d("Private message was not sent because the current form could not be verified. Keep your text and continue in the native forum.");
			}
			try {
				let t = new URL(m.action);
				t.searchParams.set("inajax", "1"), await e.transport.request(t.href, {
					method: "POST",
					body: new URLSearchParams([
						["message", u.submission.writing.source.replaceAll("\n", "\r\n")],
						["formhash", m.token],
						["topmuid", m.prepared.recipient.id]
					]).toString()
				});
			} catch {}
			return o({
				...u,
				status: "uncertain"
			});
		},
		async prepare(a, o) {
			let s = ++n;
			t.clear();
			try {
				let t = await r(a, o);
				if (s !== n) throw Error("Writing changed during review. Review the current text again.");
				return {
					kind: "prepared",
					prepared: t.prepared,
					account: e.account(),
					generation: e.generation()
				};
			} catch (e) {
				return i(e);
			}
		},
		async review(a) {
			let o = ++n;
			t.clear();
			try {
				let i = structuredClone(a);
				if (!po(i.writing)) throw Error("The private writing contains unsupported fields or a different recipient.");
				if (/\[(?:\/?[a-z][^\]\r\n]*|\*)\]/i.test(i.writing.source)) throw Error("Private formatting syntax has not been qualified. Keep the exact text and continue in the native forum.");
				if (!i.writing.source.trim()) throw new oo("Enter private message text before review.", {
					field: "source",
					code: "required"
				});
				if (i.writing.source.includes("\r") || i.writing.source.includes("\0")) throw Error("Use plain text and line breaks. Unsupported control characters must be removed before review.");
				let s = await r(i.writing.recipient.url, i.writing.account);
				if (o !== n) throw Error("Writing changed during review. Review the current text again.");
				if (s.prepared.recipient.id !== i.writing.recipient.id) throw Error("The recipient changed. Keep your text and review the current form.");
				if (s.prepared.maxLength !== null && i.writing.source.length > s.prepared.maxLength) throw new oo("The private message exceeds the current text limit.", {
					field: "source",
					code: "too-long",
					limit: s.prepared.maxLength
				});
				if (!s.conversation.beginning || !s.conversation.end) throw Error("The complete current private history is required for reliable result checking. Continue in the native forum.");
				i.writing.maxLength = s.prepared.maxLength;
				let c = {
					id: crypto.randomUUID(),
					generation: e.generation(),
					submission: i
				};
				return t.set(c.id, JSON.stringify(c)), {
					kind: "ready",
					review: c,
					account: e.account(),
					generation: e.generation()
				};
			} catch (e) {
				return {
					...i(e),
					...e instanceof oo ? { issue: e.issue } : {}
				};
			}
		}
	};
}
function co(e, t, n) {
	let r = V(e, `pmlist_${t}`), i = r && B(r, (e) => e.tagName === "dd" && U(e, "ptm"))[0];
	if (!i) return null;
	let a = R(i), o = a.findIndex((e) => L(e) && e.tagName === "br"), s = a.findIndex((e, t) => t > o && U(e, "xg1"));
	if (o < 0 || s < 0) return null;
	let c = "", l = !0;
	for (let e of a.slice(o + 1, s)) if ("value" in e) {
		let t = e.value;
		l && t.startsWith("\n") && (t = t.slice(1)), c += t, t && (l = !1);
	} else if (L(e) && e.tagName === "br" && !e.attrs.length) c += "\n", l = !0;
	else if (L(e) && e.tagName === "a" && e.attrs.every((e) => [
		"href",
		"target",
		"rel"
	].includes(e.name)) && R(e).every((e) => "value" in e)) {
		let t = R(e).map((e) => "value" in e ? e.value : "").join("");
		if (K(t, n) !== K(z(e, "href"), n)) return null;
		c += t, l = !1;
	} else return null;
	return c.endsWith("\n") ? c.slice(0, -1) : null;
}
var lo = (e) => !!e && typeof e == "object" && !Array.isArray(e), uo = (e, t) => Object.keys(e).every((e) => t.includes(e)), fo = (e) => typeof e == "string" && /^[1-9]\d*$/.test(e);
function po(e) {
	if (!lo(e) || !uo(e, [
		"action",
		"account",
		"recipient",
		"source",
		"maxLength"
	]) || e.action !== "private-message" || typeof e.source != "string" || !(e.maxLength === null || Number.isSafeInteger(e.maxLength) && Number(e.maxLength) > 0) || !lo(e.account) || !uo(e.account, [
		"kind",
		"id",
		"name"
	]) || e.account.kind !== "member" || !fo(e.account.id) || typeof e.account.name != "string" || !lo(e.recipient) || !uo(e.recipient, [
		"id",
		"name",
		"url"
	]) || !fo(e.recipient.id) || e.recipient.id === e.account.id || typeof e.recipient.name != "string" || typeof e.recipient.url != "string") return !1;
	let t = J(e.recipient.url);
	return t?.kind === "private-conversation" && t.url.searchParams.get("touid") === e.recipient.id && !t.url.hash && [...t.url.searchParams.keys()].every((e) => [
		"mod",
		"do",
		"subop",
		"touid",
		"page",
		"daterange"
	].includes(e));
}
function mo(e) {
	if (!lo(e) || !uo(e, [
		"id",
		"submission",
		"before",
		"status",
		"checked",
		"message",
		"result"
	]) || typeof e.id != "string" || !e.id || !lo(e.submission) || !uo(e.submission, [
		"contextId",
		"revision",
		"writing"
	]) || typeof e.submission.contextId != "string" || !Number.isSafeInteger(e.submission.revision) || Number(e.submission.revision) < 1 || !po(e.submission.writing) || !Array.isArray(e.before) || !e.before.every(fo) || new Set(e.before).size !== e.before.length || ![
		"pending",
		"not-sent",
		"uncertain",
		"confirmed"
	].includes(String(e.status)) || typeof e.checked != "boolean" || typeof e.message != "string") return !1;
	if (e.status !== "confirmed") return e.result === null;
	let t = e.result, n = e.submission.writing;
	if (!lo(t) || !uo(t, [
		"messageId",
		"url",
		"senderId",
		"recipientId",
		"source"
	]) || !fo(t.messageId) || e.before.includes(t.messageId) || t.senderId !== n.account.id || t.recipientId !== n.recipient.id || t.source !== n.source || typeof t.url != "string") return !1;
	let r = J(t.url);
	return r?.kind === "private-conversation" && r.url.origin === new URL(n.recipient.url).origin && r.url.searchParams.get("touid") === n.recipient.id && r.url.hash === `#pmlist_${t.messageId}`;
}
//#endregion
//#region src/forum-client/index.ts
function ho(e) {
	let t = J(e);
	return t ? {
		kind: t.kind,
		url: t.url.href
	} : null;
}
var $ = (e) => e.kind === "member" ? `member:${e.id}` : e.kind, go = "0.26.0";
function _o(e) {
	let t = { kind: "unknown" }, n = 0, r = 0, i = 0, a = so({
		...e,
		account: () => t,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	}), o = wa({
		...e,
		account: () => t,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	}), s = ja({
		...e,
		account: () => t,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	}), c = da({
		...e,
		account: () => t,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	}), l = ao({
		...e,
		account: () => t,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	}), u = pi({
		...e,
		account: () => t,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	}), d = li({
		...e,
		generation: () => n,
		observe: (e) => {
			$(e) !== $(t) && (t = e, n++);
		}
	});
	return {
		prepareReport: d.prepare,
		submitReport: d.submit,
		prepareRating: u.prepare,
		submitRating: u.submit,
		sendPrivateMessage: a.send,
		checkPrivateMessage: a.check,
		preparePrivateWriting: a.prepare,
		preparePrivateReview: a.review,
		removeUploadedAttachment: Ii({
			...e,
			generation: () => n,
			observe: (e) => {
				$(e) !== $(t) && (t = e, n++);
			}
		}),
		checkReplyAttachments: Pi({
			...e,
			generation: () => n,
			observe: (e) => {
				$(e) !== $(t) && (t = e, n++);
			}
		}),
		uploadAttachment: Fi({
			...e,
			generation: () => n,
			observe: (e) => {
				$(e) !== $(t) && (t = e, n++);
			}
		}),
		findMention: (r, i) => Li({
			...e,
			account: () => t,
			generation: () => n,
			observe: (e) => {
				$(e) !== $(t) && (t = e, n++);
			}
		}, r, i),
		preparePostEdit: l.load,
		prepareEditPublication: l.prepare,
		savePostEdit: l.save,
		checkEditResult: l.check,
		resumeDraft: o.resume,
		prepareDraftSave: o.prepareSave,
		saveDraft: o.save,
		publishDraft: o.publish,
		checkDraft: o.check,
		async readDrafts(i = new URL(fa, e.origin).href, a, o) {
			let s = ++r, c = (e, r) => ({
				kind: e,
				message: r,
				account: t,
				generation: n,
				sourceURL: i
			}), l = pa(i, e.origin);
			if (!l || a && ![a.url, ...a.pages.links.map((e) => e.url)].includes(l.href)) return c("invalid", "This draft page was not offered by the current list.");
			l.searchParams.set("tsdmapp", "json");
			try {
				let a = await e.transport.request(l.href, { fresh: !0 });
				if (s !== r) return c("stale", "A newer request replaced this draft list.");
				let u = ma(a, i);
				return $(u.account) !== $(t) && (t = u.account, n++), o && $(u.account) !== $(o) ? c("stale", "The account changed while loading drafts. Load the current account's list explicitly.") : u.kind === "drafts" && u.drafts ? {
					kind: "drafts",
					drafts: u.drafts,
					account: t,
					generation: n,
					sourceURL: i
				} : {
					kind: u.kind === "drafts" ? "invalid" : u.kind,
					message: "message" in u ? String(u.message) : "The draft list is incomplete.",
					account: t,
					generation: n,
					sourceURL: i
				};
			} catch {
				return c(s === r ? "network" : "stale", "The forum draft list could not be reached.");
			}
		},
		prepareFavorite: s.prepare,
		changeFavorite: s.execute,
		checkFavoriteResult: s.check,
		prepareThreadPublication: c.prepare,
		publishThread: c.publish,
		checkThreadResult: c.check,
		async readPrivateConversation(i, a, o) {
			let s = ++r, c = n, l = o ?? (t.kind === "member" ? t : void 0), u = J(i), d = (e, r = "invalid") => ({
				kind: r,
				message: e,
				account: t,
				generation: n,
				sourceURL: i
			});
			if (u?.kind !== "private-conversation" || u.url.origin !== e.origin) return d("This is not a supported private-conversation destination.");
			if (a && ![a.url, ...a.pages.links.map((e) => e.url)].includes(i)) return d("This page was not offered by the current private conversation.");
			u.url.searchParams.set("tsdmapp", "json");
			try {
				let a = await e.transport.request(u.url.href, { fresh: !0 });
				if (s !== r || n !== c) return d("A newer request replaced this private-conversation load. It may still have marked the private conversation read.", "stale");
				let o = mi(a, i);
				return $(o.account) !== $(t) && (t = o.account, n++), o.kind === "private-conversation" && l && $(o.account) !== $(l) ? d("The account changed while reading a private conversation. Previous private conversations were cleared. This request may still have had read effects.") : {
					...o,
					generation: n
				};
			} catch {
				return d("The private-conversation request failed. It may still have marked the private conversation read. Retry only deliberately.", s === r ? "network" : "stale");
			}
		},
		async readMessages(i, a, o) {
			let s = ++r, c = n, l = o ?? (t.kind === "member" ? t : void 0), u = J(i), d = (e, r = "invalid") => ({
				kind: r,
				message: e,
				account: t,
				generation: n,
				sourceURL: i
			});
			if (u?.kind !== "messages" || u.url.origin !== e.origin) return d("This is not a supported message destination.");
			if (a && ![a.url, ...a.pages.links.map((e) => e.url)].includes(i)) return d("This page was not offered by the current message list.");
			u.url.searchParams.set("tsdmapp", "json");
			try {
				let a = await e.transport.request(u.url.href, { fresh: !0 });
				if (s !== r || n !== c) return d("A newer request replaced this message load. It may still have cleared the new-private-message prompt.", "stale");
				let o = Na(a, i);
				return $(o.account) !== $(t) && (t = o.account, n++), o.kind === "messages" && l && $(o.account) !== $(l) ? d("The account changed while loading messages. Previous messages were cleared. This request may still have had read effects.") : {
					...o,
					generation: n
				};
			} catch {
				return d("The message request failed. It may still have cleared the new-private-message prompt. Retry only deliberately.", s === r ? "network" : "stale");
			}
		},
		async readNotices(i, a, o) {
			let s = ++r, c = J(i), l = (e, r = "invalid") => ({
				kind: r,
				message: e,
				account: t,
				generation: n,
				sourceURL: i
			});
			if (c?.kind !== "notices" || c.url.origin !== e.origin) return l("This is not a supported notice destination.");
			if (a && ![
				a.url,
				...a.categories.map((e) => e.url),
				...a.pages.links.map((e) => e.url)
			].includes(i)) return l("This category or page was not offered by the current notice list.");
			c.url.searchParams.set("tsdmapp", "json");
			try {
				let a = await e.transport.request(c.url.href, { fresh: !0 });
				if (s !== r) return l("A newer request replaced this notice load. It may still have marked notices read.", "stale");
				let u = Ra(a, i);
				return $(u.account) !== $(t) && (t = u.account, n++), u.kind === "notices" && o && $(u.account) !== $(o) ? l("The account changed while loading notices. Previous notices were cleared. This request may still have had read effects.") : {
					...u,
					generation: n
				};
			} catch {
				return l("The notice request failed. It may still have marked notices read. Retry only deliberately.", s === r ? "network" : "stale");
			}
		},
		async prepareReply(i, a) {
			let o = ++r, s = new URL("/forum.php", e.origin);
			for (let [e, t] of Object.entries({
				mod: "post",
				action: "reply",
				fid: i,
				tid: a.threadId,
				tsdmapp: "json"
			})) s.searchParams.set(e, t);
			if (!/^[1-9]\d*$/.test(i) || !/^[1-9]\d*$/.test(a.threadId) || a.postId !== null && !/^[1-9]\d*$/.test(a.postId)) return {
				kind: "invalid",
				message: "A supported ordinary thread target is required.",
				account: t,
				generation: n,
				sourceURL: s.href
			};
			a.postId && s.searchParams.set("reppost", a.postId);
			try {
				let c = await e.transport.request(s.href, { fresh: !0 });
				if (o !== r) return {
					kind: "stale",
					message: "A newer action replaced reply preparation.",
					account: t,
					generation: n,
					sourceURL: s.href
				};
				let l = Z(c, s.href, i, void 0, a);
				return $(l.account) !== $(t) && (t = l.account, n++), {
					...l,
					generation: n
				};
			} catch {
				return {
					kind: "network",
					message: "The reply form could not be reached. Your writing is retained.",
					account: t,
					generation: n,
					sourceURL: s.href
				};
			}
		},
		async prepareNewThread(i, a = !1) {
			let o = ++r, s = new URL("/forum.php", e.origin);
			if (s.searchParams.set("mod", "post"), s.searchParams.set("action", "newthread"), s.searchParams.set("fid", i), a && s.searchParams.set("specialextra", "hongbao"), s.searchParams.set("tsdmapp", "json"), !/^[1-9]\d*$/.test(i)) return {
				kind: "invalid",
				message: "A valid board is required.",
				account: t,
				generation: n,
				sourceURL: s.href
			};
			try {
				let a = await e.transport.request(s.href);
				if (o !== r) return {
					kind: "stale",
					message: "A newer account request replaced this preparation.",
					account: t,
					generation: n,
					sourceURL: s.href
				};
				let c = Z(a, s.href, i);
				return JSON.stringify(c.account) !== JSON.stringify(t) && (t = c.account, n++), {
					...c,
					generation: n
				};
			} catch {
				return {
					kind: o === r ? "network" : "stale",
					message: "The form could not be reached. Your writing is retained.",
					account: t,
					generation: n,
					sourceURL: s.href
				};
			}
		},
		get account() {
			return t;
		},
		get generation() {
			return n;
		},
		cancelDownload() {
			i++;
		},
		async downloadAttachment(t) {
			let r = ++i, a = () => ({
				kind: "stale",
				message: "This download attempt was replaced or cancelled."
			});
			if (!e.transport.requestFile) return {
				kind: "invalid",
				message: "File downloads are unavailable in this host."
			};
			let o = await this.readPage(t.threadURL, { fresh: !0 });
			if (o.kind !== "thread") return {
				kind: "invalid",
				message: "Current attachment access could not be confirmed. Refresh the thread or continue in the native forum."
			};
			if (r !== i) return a();
			let s = (e) => e.kind === "member" ? `member:${e.id}` : e.kind;
			if (o.account.kind === "unknown" || s(o.account) !== s(t.account)) return {
				kind: "stale",
				message: "The forum account changed or could not be confirmed. Refresh the thread before downloading."
			};
			let c = o.thread.posts.find((e) => e.id === t.postId)?.attachments?.filter((e) => e.id === t.attachmentId);
			if (c?.length !== 1) return {
				kind: "permission",
				message: "The forum no longer offers this attachment for direct download. No purchase was attempted."
			};
			let l = c[0], u = n;
			try {
				let t = await e.transport.requestFile(l.url);
				return r === i ? n === u ? Ma(t) || (t.url === l.url ? {
					kind: "file",
					name: l.name,
					contentType: t.contentType,
					bytes: t.bytes,
					generation: u
				} : {
					kind: "invalid",
					message: "The forum returned a different file destination. Nothing is ready to save."
				}) : {
					kind: "stale",
					message: "The forum account changed while receiving the file. Refresh the thread before downloading."
				} : a();
			} catch {
				return {
					kind: "network",
					message: "The file transfer failed or was interrupted. Nothing is ready to save."
				};
			}
		},
		async readSearchPage(i, a, o) {
			let s = ++r, c = (e, r) => ({
				kind: e,
				message: r,
				account: t,
				generation: n,
				sourceURL: i
			});
			if (!a.results || !a.effective || !a.results.pages.links.some((e) => e.url === i)) return c("invalid", "This page was not offered by the current search results.");
			let l = new URL(i);
			l.searchParams.set("tsdmapp", "json");
			try {
				let u = await e.transport.request(l.href);
				if (s !== r) return c("stale", "A newer request replaced this search page.");
				let d = $a(u, i, a.form, a.effective);
				if ($(d.account) !== $(t) && (t = d.account, n++), d.kind === "search") {
					if (d.account.kind === "unknown") return c("invalid", "The current account could not be established from this search page. Review the current account before searching again deliberately.");
					if ($(d.account) !== $(o)) return c("invalid", "The account changed while reading search results. Review the current account before searching again deliberately.");
					if (d.search.results?.id !== a.results.id) return c("invalid", "The returned page belongs to a different search.");
					d.search.edited = a.edited, d.search.submitted = a.submitted;
				}
				return {
					...d,
					generation: n
				};
			} catch {
				return c(s === r ? "network" : "stale", "The search page could not be loaded. It has not been requested again automatically.");
			}
		},
		async search(i, a, o) {
			let s = ++r, c = n, l = (e, r) => ({
				kind: e,
				message: r,
				account: t,
				generation: n,
				sourceURL: a.url
			}), u = new URL(a.url);
			if (u.origin !== e.origin || u.pathname !== "/search.php") return l("invalid", "The search form is not from this forum.");
			u.searchParams.set("tsdmapp", "json");
			try {
				let d = await e.transport.request(u.href);
				if (s !== r || n !== c) return l("stale", "A newer action replaced this search.");
				let f = Za(d, a.url, i);
				if (f.kind !== "prepared") return {
					...f,
					generation: n
				};
				if (f.account.kind === "unknown" || o.kind === "unknown") return l("invalid", "The current account could not be established. Search has not been submitted.");
				if ($(f.account) !== $(o)) return t = f.account, n++, l("invalid", "The account changed while preparing search. Review the current form and submit again deliberately.");
				let p = await e.transport.request(f.url, {
					method: "POST",
					body: f.body
				});
				if (s !== r || n !== c) return l("stale", "A newer action replaced this search. The earlier request may still have had effects.");
				let m = Qa(p, f.url);
				if (m) {
					if ($(m.account) !== $(o)) return $(m.account) !== $(t) && (t = m.account, n++), l("invalid", "The account changed during search. Its effects are not isolated; review the current account before another deliberate search.");
					if (m.url.searchParams.set("tsdmapp", "json"), p = await e.transport.request(m.url.href), s !== r || n !== c) return l("stale", "A newer action replaced this search. The earlier request may still have had effects.");
					let i = J(p.url);
					if (i?.kind !== "search" || i.url.origin !== e.origin || i.url.searchParams.get("searchid") !== m.id) return l("invalid", "The returned page belongs to a different search.");
				}
				let h = $a(p, a.url, f.form, i);
				return $(h.account) !== $(t) && (t = h.account, n++), h.kind === "search" && h.account.kind === "unknown" ? l("invalid", "The current account could not be established from the search response. The request may still have used credits or quota.") : h.kind === "search" && $(h.account) !== $(o) ? l("invalid", "The account changed during search. Its effects are not isolated; review the current account before another deliberate search.") : m && h.kind === "search" && h.search.results?.id !== m.id ? l("invalid", "The returned page belongs to a different search.") : {
					...h,
					generation: n
				};
			} catch {
				return l(s !== r || n !== c ? "stale" : "network", "Search could not be completed. It may have used credits or quota. Submit again only deliberately.");
			}
		},
		readThread(e) {
			return this.readPage(e);
		},
		async readPage(i, a) {
			let o = ++r, s = J(i), c = s?.url;
			if (s?.kind === "private-conversation") return {
				kind: "invalid",
				message: "Private conversations must be opened deliberately. Opening may mark the conversation read.",
				account: t,
				generation: n,
				sourceURL: i
			};
			if (s?.kind === "messages") return {
				kind: "invalid",
				message: "Messages must be loaded deliberately. Loading may clear the new-private-message prompt.",
				account: t,
				generation: n,
				sourceURL: i
			};
			if (s?.kind === "notices") return {
				kind: "invalid",
				message: "Notices must be loaded deliberately. Each load may mark notices read.",
				account: t,
				generation: n,
				sourceURL: i
			};
			if (s?.kind === "search" && c?.searchParams.has("searchid")) return {
				kind: "invalid",
				message: "An existing search page must be opened deliberately from its returned results. Open Search to prepare a new search.",
				account: t,
				generation: n,
				sourceURL: i
			};
			if (!c || c.origin !== e.origin) return {
				kind: "invalid",
				message: "This is not a supported thread destination.",
				account: t,
				generation: n,
				sourceURL: i
			};
			c.searchParams.set("tsdmapp", "json");
			try {
				let l = await e.transport.request(c.href, a);
				if (o !== r) return {
					kind: "stale",
					message: "A newer request has replaced this result.",
					account: t,
					generation: n,
					sourceURL: i
				};
				if (s?.kind === "redirect" && l.redirect === "opaque") return {
					kind: "document-navigation",
					message: "The forum redirect requires a document navigation.",
					destination: i,
					account: t,
					generation: n,
					sourceURL: i
				};
				let u = s?.kind === "favorites" ? Ta(l, i) : s?.kind === "search" ? Xa(l, i) : s?.kind === "thread" ? oi(l, i) : Qr(l, i);
				return $(u.account) !== $(t) && (t = u.account, n++), {
					...u,
					generation: n
				};
			} catch {
				return {
					kind: o === r ? "network" : "stale",
					message: "The forum could not be reached. Retry or continue in the native forum.",
					account: t,
					generation: n,
					sourceURL: i
				};
			}
		}
	};
}
//#endregion
export { go as FORUM_CLIENT_VERSION, _o as createForumClient, ho as describeDestination, io as editBaseline, bi as unresolvedWritingAttachments };
