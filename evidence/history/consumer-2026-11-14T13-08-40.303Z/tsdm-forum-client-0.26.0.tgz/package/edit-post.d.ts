import type { Account, ForumTransport, PreparedWriting, PrepareWritingResult, PublicationPreparationResult, ThreadAttempt, ThreadSubmission, WritingBaseline } from "./types.js";
export declare const editBaseline: (v: PreparedWriting) => WritingBaseline;
export declare function createPostEditor(config: {
    origin: string;
    transport: ForumTransport;
    account: () => Account;
    generation: () => number;
    observe: (a: Account) => void;
}): {
    load: (threadURL: string, postId: string) => Promise<PrepareWritingResult>;
    prepare: (submission: ThreadSubmission) => Promise<PublicationPreparationResult>;
    save: (attempt: ThreadAttempt) => Promise<ThreadAttempt>;
    check: (attempt: ThreadAttempt) => Promise<ThreadAttempt>;
};
