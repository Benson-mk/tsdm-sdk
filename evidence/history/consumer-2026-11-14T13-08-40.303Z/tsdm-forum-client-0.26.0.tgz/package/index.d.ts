export { editBaseline } from "./edit-post.js";
export { unresolvedWritingAttachments } from "./prepare-writing.js";
export declare function describeDestination(value: string): {
    kind: "directory" | "board" | "thread" | "redirect" | "search" | "private-conversation" | "messages" | "notices" | "favorites";
    url: string;
} | null;
import type { ForumClient, ForumTransport } from "./types.js";
export type * from "./types.js";
export declare const FORUM_CLIENT_VERSION = "0.26.0";
export declare function createForumClient(options: {
    origin: string;
    transport: ForumTransport;
}): ForumClient;
